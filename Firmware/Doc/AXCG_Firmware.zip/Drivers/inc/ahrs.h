/*
 * ahrs.h
 *
 *  Created on: Feb 27, 2011
 *      Author: Alex
 */
/* Includes */
#include "stm32f10x.h"
/* Structures */
typedef struct {
	char Message[256];
	bool New_Message;
} AHRS_Message_Type;
typedef struct {
	int Yaw;
	int Pitch;
	int Roll;
	int MagX;
	int MagY;
	int MagZ;
	int AccX;
	int AccY;
	int AccZ;
	int GyroX;
	int GyroY;
	int GyroZ;
	u8 Data_Mode;
} AHRS_Data_Type;
/* Function Prototypes */
void AHRS_USART_Initialize(u32);
void AHRS_DMA_Initialize(u32*, u32*);
void AHRS_Enable(FunctionalState);
void AHRS_Reset(FunctionalState);
void AHRS_Tare(void);
void AHRS_Read_Buffer(char*,AHRS_Message_Type*);
void AHRS_Message_Parse(AHRS_Message_Type*,AHRS_Data_Type*);
void AHRS_Send_Message(char*);
void AHRS_Set_Baud_Rate(u32);

