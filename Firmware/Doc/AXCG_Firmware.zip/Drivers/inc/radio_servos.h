/*
 * radio_servos.h
 *
 *  Created on: Mar 9, 2011
 *      Author: Alex
 */

typedef struct {
	s16 Max;
	s16 Min;
} Servo_Endpoint_Type;

void Spektrum_USART_Initialize(void);
void Servo_PWM_Initialize(u32);
void Servo_Set_Position(u8,s16);
s16 Servo_Get_Position(u8 Channel);
