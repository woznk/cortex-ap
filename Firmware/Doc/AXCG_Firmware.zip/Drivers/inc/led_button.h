/*
 * led_button.h
 *
 *  Created on: Feb 28, 2011
 *      Author: Alex
 */
void Led_Set(u8);
void Led_Reset(u8);
void Led_Toggle(u8);
bool Button1_Rising_Edge(void);
bool Button2_Rising_Edge(void);
