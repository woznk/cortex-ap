/*
 * board.h
 *
 *  Created on: Jan 18, 2011
 *      Author: Alex
 */
// *** Prototypes ***
void GPIO_Configuration(void);

// *** Defines ***
//PA
#define PWM_7 GPIO_Pin_0
#define PWM_6 GPIO_Pin_1
#define PWM_5 GPIO_Pin_2
#define PWM_1 GPIO_Pin_3
#define USB_DISC GPIO_Pin_4
#define PAD2 GPIO_Pin_5
#define PWM_2 GPIO_Pin_6
#define PWM_3 GPIO_Pin_7
#define PAD1 GPIO_Pin_8
#define GPS_RX GPIO_Pin_9
#define GPS_TX GPIO_Pin_10
#define USBDM GPIO_Pin_11
#define USBDP GPIO_Pin_12
#define JTMS GPIO_Pin_13
#define JTCK GPIO_Pin_14
#define JTDI GPIO_Pin_15
//PB
#define PWM_4 GPIO_Pin_0
#define PAD6 GPIO_Pin_1
#define LED_1 GPIO_Pin_2
#define JTDO GPIO_Pin_3
#define JTRST_N GPIO_Pin_4
#define THERM_WD GPIO_Pin_5
#define I2C_SCL GPIO_Pin_6
#define I2C_SDA GPIO_Pin_7
#define AHRS_RST_N GPIO_Pin_8
#define AHRS_FW GPIO_Pin_9
#define PAD7 GPIO_Pin_10
#define SAT_TX GPIO_Pin_11
#define MSD_CS GPIO_Pin_12
#define SPI_CLK GPIO_Pin_13
#define MSD_MISO GPIO_Pin_14
#define MSD_MOSI GPIO_Pin_15
//PC
#define DPRES GPIO_Pin_0
#define PRES GPIO_Pin_1
#define LED_3 GPIO_Pin_2
#define LED_2 GPIO_Pin_3
#define AHRS_EN GPIO_Pin_4
#define PAD9 GPIO_Pin_5
#define GPS_FIX GPIO_Pin_6
#define GPS_EN GPIO_Pin_7
#define BUTTON_2 GPIO_Pin_8
#define AHRS_TARE GPIO_Pin_9
#define AHRS_RX GPIO_Pin_10
#define AHRS_TX GPIO_Pin_11
#define PAD10 GPIO_Pin_12
#define PAD11 GPIO_Pin_13
#define AHRS_REPGRM GPIO_Pin_14
#define BUTTON_1 GPIO_Pin_15
//PD
#define OSC_IN GPIO_Pin_0
#define OSC_OUT GPIO_Pin_1
#define PAD8 GPIO_Pin_2
