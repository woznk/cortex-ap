/*
 * sdcard.h
 *
 *  Created on: Mar 9, 2011
 *      Author: Alex
 */
FRESULT SD_Mount(void);
FRESULT SD_Sync(void);
void SD_Create_New_File(void);
void SD_Close_File(void);
void SD_Record_Data(AHRS_Data_Type* AHRS_Data, GPS_Data_Type* GPS_Data,u16* Servo_Outputs,
		u16 Pres_Voltage, u16 DPres_Voltage, float Roll_Setpoint, float Pitch_Setpoint,
		u8 Flight_Mode, u8 Current_Waypoint, s16 Throttle, s16 Aileron, s16 Elevator);
