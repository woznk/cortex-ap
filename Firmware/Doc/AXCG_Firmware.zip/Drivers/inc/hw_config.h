/*
 * hw_config.h
 *
 *  Created on: Mar 9, 2011
 *      Author: Alex
 */
void SysTick_Initialize(u32);
void RCC_Configuration(void);
void NVIC_Configuration(void);
void GPIO_Configuration(void);
