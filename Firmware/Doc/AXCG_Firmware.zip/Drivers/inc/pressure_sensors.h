/*
 * pressure_sensors.h
 *
 *  Created on: Mar 9, 2011
 *      Author: Alex
 */
void Pressure_Get_Data(u32*, u32*);
void Pressure_Filter_Initialize(void);
float Pressure_Abs_Filter(float);
float Pressure_Dif_Filter(float);
void Pressure_ADC_Initialize(void);
void Pressure_Read_Data(u32*,u32*);
void Pressure_ADC_DMA_Initialize(void);
