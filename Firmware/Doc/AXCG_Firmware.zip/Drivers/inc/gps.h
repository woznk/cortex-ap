/*
 * gps.h
 *
 *  Created on: Feb 27, 2011
 *      Author: Alex
 */
#include "stm32f10x.h"

// GPS Data Structures
typedef struct{
	// ddmm'mmmm
	u32 Latitude;
	char NS;
	// ddmm'mmmm
	u32 Longitude;
	char EW;
} GPS_Position;
typedef struct {
	u8 Hours;
	u8 Minutes;
	u8 Seconds;
	u16 Milliseconds;
}GPS_UTC_Time;
typedef struct{
	u8 Day;
	u8 Month;
	u8 Year;
}GPS_Date;

typedef struct{
	GPS_Position Position;
	u32 Altitude;
	u32 Ground_Speed;
	u32 Heading;
	u8 Sattelites_Used;
	u8 Fix_Type;
	GPS_Date Date;
	GPS_UTC_Time UTC_Time;
	u16 HDOP;
} GPS_Data_Type;

typedef struct {
	char Message[256];
	bool New_Message;
}GPS_Message_Type;

// Public functions
void GPS_DMA_Initialize(void);
void GPS_USART_Initialize(u32);
void GPS_Read_Buffer(char*, GPS_Message_Type*);
bool GPS_Message_Parse(GPS_Message_Type*,GPS_Data_Type*);
void GPS_Send_Message(char*);
void GPS_Enable(FunctionalState);
void GPS_Initialize(void);
