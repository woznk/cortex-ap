/*
 * ahrs.c
 *
 *  Created on: Feb 27, 2011
 *      Author: Alex
 */
/* Includes */
#include "main.h"

/* Defines */
#define UART4_DR_Address ((u32)0x40004C04)
#define YPR 0
#define YMR 27

/*******************************************************************************
* Function Name  : AHRS_USART_Initialize
* Description    : Initialize AHRS USART4 Rx.
*				 : 8 bit, 9600 baud rate, 1 stop bit, no parity
* Input          : u32 Baud_Rate
* Output         : None
* Return         : None
*******************************************************************************/
void AHRS_USART_Initialize(u32 Baud_Rate)
{
	USART_InitTypeDef USART_InitStructure;
	USART_Cmd(UART4, DISABLE);
	// Set Bus Parameters
	USART_InitStructure.USART_BaudRate = Baud_Rate;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(UART4, &USART_InitStructure);

	// Enable Rx Interrupts
	//USART_ITConfig(UART4, USART_IT_RXNE, ENABLE);
	// Enable Rx/Tx DMA Request
	USART_DMACmd(UART4, USART_DMAReq_Tx|USART_DMAReq_Rx, ENABLE);
	// Enable USART4
	USART_Cmd(UART4, ENABLE);
}
/*******************************************************************************
* Function Name  : AHRS_DMA_Initialize
* Description    : Initialize AHRS DMA (Tx and Rx) DMA2_Channel5 / DMA2_Channe3
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void AHRS_DMA_Initialize(u32* TxBuffer, u32* RxBuffer)
{
	DMA_InitTypeDef DMA_InitStructure;

	// DMA2 Channel5 (triggered by USART4 Tx event) Configuration
	DMA_DeInit(DMA2_Channel5);
	DMA_InitStructure.DMA_PeripheralBaseAddr = UART4_DR_Address;
	DMA_InitStructure.DMA_MemoryBaseAddr = (u32)TxBuffer;
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
	DMA_InitStructure.DMA_BufferSize = 0;
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
	DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
	DMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;
	DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
	DMA_Init(DMA2_Channel5, &DMA_InitStructure);
	// Enable is in AHRS_Send_Message()

	// DMA2 Channel3 (triggered by USART4 Rx event) Configuration
	DMA_DeInit(DMA2_Channel3);
	DMA_InitStructure.DMA_PeripheralBaseAddr = UART4_DR_Address;
	DMA_InitStructure.DMA_MemoryBaseAddr = (u32)RxBuffer;
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;
	DMA_InitStructure.DMA_BufferSize = 256;
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
	DMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;
	DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
	DMA_Init(DMA2_Channel3, &DMA_InitStructure);
	//Enable
	DMA_Cmd(DMA2_Channel3, ENABLE);
}
/*******************************************************************************
* Function Name  : AHRS_Enable
* Description    : Enable / Disable AHRS
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void AHRS_Enable(FunctionalState Command)
{
	if (Command == ENABLE)
	{
		GPIO_SetBits(GPIOC,AHRS_EN);
	}
	if (Command == DISABLE)
	{
		GPIO_ResetBits(GPIOC,AHRS_EN);
	}
}
/*******************************************************************************
* Function Name  : AHRS_Reset
* Description    : AHRS_RST_N Pin Command
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void AHRS_Reset(FunctionalState Command)
{
	if (Command == ENABLE)
	{

		GPIO_ResetBits(GPIOB,AHRS_RST_N);
	}
	if (Command == DISABLE)
	{
		GPIO_SetBits(GPIOB,AHRS_RST_N);
	}
}
/*******************************************************************************
* Function Name  : AHRS_Tare
* Description    : Establish AHRS reference vectors
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void AHRS_Tare(void)
{
	AHRS_Send_Message("$VNTAR*5F\n");
}
/*******************************************************************************
* Function Name  : AHRS_Read_Buffer
* Description    : Reads and sorts data in AHRS Rx circle buffer.
* 				 : Rights to AHRS_Message string
* Input          : None
* Output         : None
* Return         : None
* TODO: Create work string and transfer when done, allow overwrite if new complete string
*******************************************************************************/
void AHRS_Read_Buffer(char* AHRS_RxBuffer,AHRS_Message_Type* AHRS_Message)
{
	static u8 Buffer_Position = 0;
	static u8 String_Position;
	static u8 state = 0;
	u8 DMA_Data_Counter = DMA_GetCurrDataCounter(DMA2_Channel3);

	while (Buffer_Position != (255-DMA_Data_Counter))
	{
		switch(state){
		case 0:
			if (AHRS_RxBuffer[Buffer_Position] =='$')
			{
				state = 1;
				AHRS_Message->Message[String_Position++]='$';
			}
			break;
		case 1:
			if(AHRS_RxBuffer[Buffer_Position] != '\n')
			{
				AHRS_Message->Message[String_Position++]=AHRS_RxBuffer[Buffer_Position];
			}
			else
			{
				// String done -> end with \n and \0
				AHRS_Message->Message[String_Position]='\n';
				AHRS_Message->Message[String_Position+1]='\0';
				String_Position = 0;
				AHRS_Message->New_Message = TRUE;
				state = 0;
			}
			break;
		}
		Buffer_Position++;
		if(AHRS_Message->New_Message == TRUE)
			break;
	}
}
/*******************************************************************************
* Function Name  : AHRS_Message_Parse
* Description    : Decode AHRS String message
* Input          : None
* Output         : None
* Return         : None
* TODO: complete message possibilities and add checksum.
* TODO: Replace bad parsing with function Cut and convert.
*******************************************************************************/
void AHRS_Message_Parse(AHRS_Message_Type* AHRS_Message, AHRS_Data_Type* AHRS_Data)
{
	int Temp_MagZ;
	int Temp_AccX;
	int Temp_AccY;
	int Temp_AccZ;
	int Temp_GyroX;
	int Temp_GyroY;
	int Temp_GyroZ;
	// YPR or YMR
	if (((AHRS_Message->Message[3] == 'Y') && (AHRS_Message->Message[4] == 'M') && (AHRS_Message->Message[5] == 'R')) ||
			((AHRS_Message->Message[3] == 'Y') && (AHRS_Message->Message[4] == 'P') && (AHRS_Message->Message[5] == 'R')) )
	{
		//Yaw
		AHRS_Data->Yaw = String_To_Int(&AHRS_Message->Message[7],7)*10;
		//Pitch
		AHRS_Data->Pitch = String_To_Int(&AHRS_Message->Message[15],7)*10;
		//Roll
		AHRS_Data->Roll = String_To_Int(&AHRS_Message->Message[23],7)*10;
		// Mode
		AHRS_Data->Data_Mode = YPR;
	}
	//YMR
	if ((AHRS_Message->Message[3] == 'Y') && (AHRS_Message->Message[4] == 'M') && (AHRS_Message->Message[5] == 'R'))
	{
		// MagX
		AHRS_Data->MagX= String_To_Int(&AHRS_Message->Message[31],6);
		// MagY
		AHRS_Data->MagY= String_To_Int(&AHRS_Message->Message[39],6);
		// MagZ
		Temp_MagZ = (AHRS_Message->Message[53]-48)+(AHRS_Message->Message[52]-48)*10+
				(AHRS_Message->Message[51]-48)*100+ (AHRS_Message->Message[50]-48)*1000+
				(AHRS_Message->Message[48]-48)*10000;
		if( AHRS_Message->Message[47]=='-')
			Temp_MagZ = 0-Temp_MagZ;
		AHRS_Data->MagZ= Temp_MagZ;
		//AccX
		Temp_AccX = (AHRS_Message->Message[61]-48)+(AHRS_Message->Message[60]-48)*10+
				(AHRS_Message->Message[59]-48)*100+ (AHRS_Message->Message[57]-48)*1000+
				(AHRS_Message->Message[56]-48)*10000;
		if( AHRS_Message->Message[55]=='-')
			Temp_AccX = 0-Temp_AccX;
		AHRS_Data->AccX= Temp_AccX;
		// AccY
		Temp_AccY = (AHRS_Message->Message[69]-48)+(AHRS_Message->Message[68]-48)*10+
				(AHRS_Message->Message[67]-48)*100+ (AHRS_Message->Message[65]-48)*1000+
				(AHRS_Message->Message[64]-48)*10000;
		if( AHRS_Message->Message[63]=='-')
			Temp_AccY = 0-Temp_AccY;
		AHRS_Data->AccY = Temp_AccY;
		// AccZ
		Temp_AccZ = (AHRS_Message->Message[77]-48)+(AHRS_Message->Message[76]-48)*10+
				(AHRS_Message->Message[75]-48)*100+ (AHRS_Message->Message[73]-48)*1000+
				(AHRS_Message->Message[72]-48)*10000;
		if( AHRS_Message->Message[71]=='-')
			Temp_AccZ = 0-Temp_AccZ;
		AHRS_Data->AccZ = Temp_AccZ;
		// GyroX
		Temp_GyroX = (AHRS_Message->Message[86]-48)+(AHRS_Message->Message[85]-48)*10+
				(AHRS_Message->Message[84]-48)*100+(AHRS_Message->Message[83]-48)*1000+
				(AHRS_Message->Message[81]-48)*10000+(AHRS_Message->Message[80]-48)*100000;
		if( AHRS_Message->Message[79]=='-')
			Temp_GyroX = 0-Temp_GyroX;
		AHRS_Data->GyroX = Temp_GyroX;
		//GyroY
		Temp_GyroY = (AHRS_Message->Message[95]-48)+(AHRS_Message->Message[94]-48)*10+
				(AHRS_Message->Message[93]-48)*100+(AHRS_Message->Message[92]-48)*1000+
				(AHRS_Message->Message[90]-48)*10000+(AHRS_Message->Message[89]-48)*100000;
		if( AHRS_Message->Message[88]=='-')
			Temp_GyroY = 0-Temp_GyroY;
		AHRS_Data->GyroY = Temp_GyroY;
		//GyroZ
		Temp_GyroZ = (AHRS_Message->Message[104]-48)+(AHRS_Message->Message[103]-48)*10+
				(AHRS_Message->Message[102]-48)*100+(AHRS_Message->Message[101]-48)*1000+
				(AHRS_Message->Message[99]-48)*10000+(AHRS_Message->Message[98]-48)*100000;
		if( AHRS_Message->Message[97]=='-')
			Temp_GyroZ = 0-Temp_GyroZ;
		AHRS_Data->GyroZ = Temp_GyroZ;
		// Data Mode = YMR
		AHRS_Data->Data_Mode = YMR;
	}
}
/*******************************************************************************
* Function Name  : AHRS_Send_Message
* Description    : Send String to AHRS
* Input          : *Char
* Output         : None
* Return         : None
* TODO: Find alternative to infite loop while waiting
*******************************************************************************/
void AHRS_Send_Message(char* Message)
{
	u16 length = 0;
	// Wait until is done
	while(DMA2_Channel5->CNDTR!=0);
	//Copy message to new memory location
	DMA_Cmd(DMA2_Channel5, DISABLE);
	DMA2_Channel5->CMAR = (u32)Message;
	// Find length
	while(Message[length++]!=0);
	// Set DMA counter size
	DMA2_Channel5->CNDTR = length-1;
	DMA_Cmd(DMA2_Channel5,ENABLE);
}
/*******************************************************************************
* Function Name  : AHRS_Set_Baud_Rate
* Description    : Set AHRS Baud Rate
* Input          : u32
* Output         : None
* Return         : None
*******************************************************************************/
void AHRS_Set_Baud_Rate(u32 Baud_Rate)
{
	char AHRS_Final_String[30];
	char Baud_Rate_String[7];
	char Checksum_String[3];
	u16 String_Position = 0;
	u8 Checksum_Value;

	// Clear string
	AHRS_Final_String[0] = '\0';
	// VN Write to register 05
	String_Position = String_Append(AHRS_Final_String,"$VNWRG,05,",0);
	// Generate baud rate string
	Int_To_Dec_String(Baud_Rate,Baud_Rate_String,0,FALSE);
	// Add baud rate to base string
	String_Position = String_Append(AHRS_Final_String,Baud_Rate_String,String_Position);
	// Calculate checksum and convert to string
	Checksum_Value = Checksum_Calculate(&AHRS_Final_String[1]);
	Int_To_Hex_String(Checksum_Value,Checksum_String);
	// Add checksum star
	String_Position = String_Append(AHRS_Final_String,"*",String_Position);
	// Add checksum to base string
	String_Position = String_Append(AHRS_Final_String,Checksum_String,String_Position);
	// Finish string off with '\n'
	AHRS_Final_String[String_Position]='\n';
	AHRS_Final_String[String_Position+1]='\0';
	// Send string to AHRS
	AHRS_Send_Message(AHRS_Final_String);
	while(DMA2_Channel5->CNDTR!=0);
	//Delay_us(100000);
	//AHRS_Enable(DISABLE);
	AHRS_USART_Initialize(Baud_Rate);
	//AHRS_Enable(ENABLE);
	//Delay_us(100000);
}
