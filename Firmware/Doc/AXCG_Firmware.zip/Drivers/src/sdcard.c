/*
 * sdcard.c
 *
 *  Created on: Mar 9, 2011
 *      Author: Alex
 */
#include "main.h"

/* Private defines */
#define Header_Length 854
/* Private variables */
FATFS Fs;
FIL File;
bool Recording = FALSE;
char Data_Log_Header[]="Yaw      Pitch      Roll      GyroX      GyroY      GryoZ      "
		"AccelX      AccelY      AccelZ      Lat      Long      Alt      GPS_Fix#      "
		"Sattelites      GPS_Heading      Ground_Speed      Abs_Pressure      Dif_Press"
		"ure      Radio1      Radio2      Radio3      Radio4      Radio5      Radio6   "
		"   Radio7      Roll_Setpoint      Pitch_Setpoint      Flight_Mode      Current"
		"_Waypoint      Throttle      Aileron      Elevator\r\n------------------------"
		"------------------------------------------------------------------------------"
		"------------------------------------------------------------------------------"
		"------------------------------------------------------------------------------"
		"------------------------------------------------------------------------------"
		"------------------------------------------------------------------------------"
		"-----------\r\n";

/*******************************************************************************
* Function Name  : SD_Mount
* Description    : Mount drive to work space
* Input          : None
* Output         : None
* Return         : FRESULT
*******************************************************************************/
FRESULT SD_Mount(void)
{
	FRESULT FAT_Result;
	FAT_Result = f_mount(0,&Fs);
	return FAT_Result;
}
/*******************************************************************************
* Function Name  : SD_Sync
* Description    : Flusges cached information in write file ->
* 					if black out, file is safe
* Input          : None
* Output         : None
* Return         : FRESULT
*******************************************************************************/
FRESULT SD_Sync(void)
{
	FRESULT FAT_Result;
	FAT_Result = f_sync(&File);
	return FAT_Result;
}
/*******************************************************************************
* Function Name  : SD_Create_New
* Description    : Create new data log file
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SD_Create_New_File(void)
{
	char File_Name[] = "DATALOG#001.txt";
	static u8 File_Number = 1;
	char Number_String[3] = "000";
	u16 String_Position;
	UINT Number;
	// While file doesn't open keep trying different file names
	while(f_open(&File,File_Name,FA_CREATE_NEW | FA_WRITE )==FR_EXIST)
	{
		//Erase Numbers at end
		File_Name[8]='\0';
		// Change File number and add to file name
		Int_To_Dec_String(File_Number++,Number_String,3,FALSE);
		String_Position = String_Append(File_Name,Number_String,8);
		String_Append(File_Name,".txt",String_Position);
	}
	//Write header
	f_write(&File,Data_Log_Header,Header_Length,&Number);
}
/*******************************************************************************
* Function Name  : SD_Close_File
* Description    : Close current file
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SD_Close_File(void)
{
	f_close(&File);
}
/*******************************************************************************
* Function Name  : SD_Record_Data
* Description    : Record all data to SD card
* Input          : AHRS, GPS, Servo, and Pressure data
* Output         : None
* Return         : None
*******************************************************************************/
void SD_Record_Data(AHRS_Data_Type* AHRS_Data, GPS_Data_Type* GPS_Data,u16* Servo_Outputs,
		u16 Pres_Voltage, u16 DPres_Voltage, float Roll_Setpoint, float Pitch_Setpoint,
		u8 Flight_Mode, u8 Current_Waypoint, s16 Throttle, s16 Aileron, s16 Elevator)
{
	char Final_String[512];
	char Work_String[128];
	u16 String_Position = 0;
	UINT Number;

	//Clear strings
	Final_String[0]='\0';
	Work_String[0]='\0';
	// Yaw
	Int_To_Dec_String(AHRS_Data->Yaw,Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,NULL);
	String_Position = String_Append(Final_String,"    ",String_Position);
	// Pitch
	Int_To_Dec_String(AHRS_Data->Pitch,Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,"    ",String_Position);
	// Roll
	Int_To_Dec_String(AHRS_Data->Roll,Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,"    ",String_Position);
	//GyroX
	Int_To_Dec_String(AHRS_Data->GyroX,Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,"    ",String_Position);
	//GyroY
	Int_To_Dec_String(AHRS_Data->GyroY,Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,"    ",String_Position);
	//GyroZ
	Int_To_Dec_String(AHRS_Data->GyroZ,Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,"    ",String_Position);
	//AccelX
	Int_To_Dec_String(AHRS_Data->AccX,Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,"    ",String_Position);
	//AccelY
	Int_To_Dec_String(AHRS_Data->AccY,Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,"    ",String_Position);
	//AccelZ
	Int_To_Dec_String(AHRS_Data->AccZ,Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,"    ",String_Position);
	// Latitude
	Int_To_Dec_String(GPS_Data->Position.Latitude,Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,"    ",String_Position);
	// Longitude
	Int_To_Dec_String(GPS_Data->Position.Longitude,Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,"    ",String_Position);
	// Altitude
	Int_To_Dec_String(GPS_Data->Altitude,Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,"    ",String_Position);
	// GPS Fix
	Int_To_Dec_String(GPS_Data->Fix_Type,Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,"    ",String_Position);
	// GPS Satellites
	Int_To_Dec_String(GPS_Data->Sattelites_Used,Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,"    ",String_Position);
	// GPS Heading
	Int_To_Dec_String(GPS_Data->Heading,Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,"    ",String_Position);
	// GPS Ground Speed
	Int_To_Dec_String(GPS_Data->Ground_Speed,Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,"    ",String_Position);
	// Absolute Pressure
	Int_To_Dec_String(Pres_Voltage,Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,"    ",String_Position);
	// Differential Pressure
	Int_To_Dec_String(DPres_Voltage,Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,"    ",String_Position);
	// Radio1
	Int_To_Dec_String(Servo_Outputs[0],Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,"    ",String_Position);
	// Radio2
	Int_To_Dec_String(Servo_Outputs[1],Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,"    ",String_Position);
	// Radio3
	Int_To_Dec_String(Servo_Outputs[2],Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,"    ",String_Position);
	// Radio4
	Int_To_Dec_String(Servo_Outputs[3],Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,"    ",String_Position);
	// Radio5
	Int_To_Dec_String(Servo_Outputs[4],Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,"    ",String_Position);
	// Radio6
	Int_To_Dec_String(Servo_Outputs[5],Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,"    ",String_Position);
	// Radio7
	Int_To_Dec_String(Servo_Outputs[6],Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,"    ",String_Position);
	// Roll Setpoint
	Int_To_Dec_String((int)(Roll_Setpoint*1000),Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,"    ",String_Position);
	// Pitch Setpoint
	Int_To_Dec_String((int)(Pitch_Setpoint*1000),Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,"    ",String_Position);
	// Flight Mode
	Int_To_Dec_String(Flight_Mode,Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,"    ",String_Position);
	// Current Waypoint
	Int_To_Dec_String(Current_Waypoint,Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,"    ",String_Position);
	// Throttle
	Int_To_Dec_String(Throttle,Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,"    ",String_Position);
	// Aileron
	Int_To_Dec_String(Aileron,Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,"    ",String_Position);
	// Elevator
	Int_To_Dec_String(Elevator,Work_String,NULL,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,"    ",String_Position);


	// Finish string
	String_Position = String_Append(Final_String,"\r\n",String_Position);
	//Write string to SD card
	f_write(&File,Final_String,String_Position,&Number);
}
