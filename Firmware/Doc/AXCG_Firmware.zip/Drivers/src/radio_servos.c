/*
 * radio_servos.c
 *
 *  Created on: Mar 9, 2011
 *      Author: Alex
 */
#include "main.h"

// Servo endpoitns register
extern Servo_Endpoint_Type Servo_Endpoints[7];

extern float Pitch_Setpoint;
extern float Roll_Setpoint;

/*******************************************************************************
* Function Name  : Spektrum_USART_Initialize
* Description    : Initialize Spektrum USART1 Rx.
*				 : 8 bit, 115200 baud rate, 1 stop bit, no parity
* Input          : None
* Output         : None
* Return         : None
* TODO: Replace Interrupt with DMA buffer like AHRS
*******************************************************************************/
void Spektrum_USART_Initialize(void)
{
	USART_InitTypeDef USART_InitStructure;

	// Set Bus Parameters
	USART_InitStructure.USART_BaudRate = 115200;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx;
	USART_Init(USART3, &USART_InitStructure);

	// Enable Rx Interrupts
	USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);

	// Enable USART3
	USART_Cmd(USART3, ENABLE);

}
/*******************************************************************************
* Function Name  : Servo_PWM_Initialize
* Description    : Configure and Initialize PWM Timers
* 				 : Timer Clock set to 1MHz (1us).
* 				 : Refresh rate = 1MHz/(ARR+1)
* Input          : Servo refresh rate
* Output         : None
* Return         : None
*   Servo #	| Timer+Channel
*   	1	| TIM5 Channel 4
*   	2	| TIM3 Channel 1
*   	3	| TIM3 Channel 2
*   	4	| TIM3 Channel 3
*   	5	| TIM5 Channel 3
*   	6	| TIM5 Channel 2
*   	7	| TIM5 Channel 1
*******************************************************************************/
void Servo_PWM_Initialize(u32 Refresh_Rate)
{
	int ARR = 1000000/(Refresh_Rate)-1;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;
	// Time base configuration
	TIM_TimeBaseStructure.TIM_Period = ARR;
	TIM_TimeBaseStructure.TIM_Prescaler = TIMER_PRESCALER;
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;

	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);
	TIM_TimeBaseInit(TIM5, &TIM_TimeBaseStructure);

	// PWM Configuration
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OCInitStructure.TIM_Pulse = 1500;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;

	// TIM5 CH4 - PWM1
	TIM_OC4Init(TIM5, &TIM_OCInitStructure);
	TIM_OC4PreloadConfig(TIM5, TIM_OCPreload_Enable);
	// TIM3 CH1 - PWM2
	TIM_OC1Init(TIM3, &TIM_OCInitStructure);
	TIM_OC1PreloadConfig(TIM3, TIM_OCPreload_Enable);
	// TIM3 CH2 - PWM3
	TIM_OC2Init(TIM3, &TIM_OCInitStructure);
	TIM_OC2PreloadConfig(TIM3, TIM_OCPreload_Enable);
	// TIM3 CH3 - PWM4
	TIM_OC3Init(TIM3, &TIM_OCInitStructure);
	TIM_OC3PreloadConfig(TIM3, TIM_OCPreload_Enable);
	// TIM5 CH3 - PWM5
	TIM_OC3Init(TIM5, &TIM_OCInitStructure);
	TIM_OC3PreloadConfig(TIM5, TIM_OCPreload_Enable);
	// TIM5 CH2 - PWM6
	TIM_OC2Init(TIM5, &TIM_OCInitStructure);
	TIM_OC2PreloadConfig(TIM5, TIM_OCPreload_Enable);
	// TIM5 CH1 - PWM7
	TIM_OC1Init(TIM5, &TIM_OCInitStructure);
	TIM_OC1PreloadConfig(TIM5, TIM_OCPreload_Enable);

	// Enable Counters
	TIM_Cmd(TIM3, ENABLE);
	TIM_Cmd(TIM5, ENABLE);
}
/*******************************************************************************
* Function Name  : Servo_Set_Position
* Description    : Set Servo to certain position
* Input          : u8 Channel(1-7). s8 Position (-500us to 500us)
* Output         : None
* Return         : None
*******************************************************************************/
void Servo_Set_Position(u8 Channel,s16 Position)
{
	if (Position < Servo_Endpoints[Channel].Min)
		Position = Servo_Endpoints[Channel].Min;
	if (Position > Servo_Endpoints[Channel].Max)
		Position = Servo_Endpoints[Channel].Max;

	switch(Channel){
	case 0:
		TIM5->CCR4 = 1500+Position;
		break;
	case 1:
		TIM3->CCR1 = 1500+Position;
		break;
	case 2:
		TIM3->CCR2 = 1500+Position;
		break;
	case 3:
		TIM3->CCR3 = 1500+Position;
		break;
	case 4:
		TIM5->CCR3 = 1500+Position;
		break;
	case 5:
		TIM5->CCR2 = 1500+Position;
		break;
	case 6:
		TIM5->CCR1 = 1500+Position;
		break;
	}
}
/*******************************************************************************
* Function Name  : Servo_Get_Position
* Description    : Get Servo position
* Input          : u8 Channel(0-6)
* Output         : None
* Return         : Position (-500 to 500)
*******************************************************************************/
s16 Servo_Get_Position(u8 Channel)
{
	s16 Position = 0;
	switch(Channel){
	case 0:
		Position = TIM5->CCR4;
		break;
	case 1:
		Position = TIM3->CCR1;
		break;
	case 2:
		Position = TIM3->CCR2;
		break;
	case 3:
		Position = TIM3->CCR3;
		break;
	case 4:
		Position = TIM5->CCR3;
		break;
	case 5:
		Position = TIM5->CCR2;
		break;
	case 6:
		Position = TIM5->CCR1;
		break;
	}
	return (Position-1500);
}
