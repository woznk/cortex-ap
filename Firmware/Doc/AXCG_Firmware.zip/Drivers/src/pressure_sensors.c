/*
 * pressure_sensors.c
 *
 *  Created on: Mar 9, 2011
 *      Author: Alex
 */
/* Includes */
#include "main.h"
#include "arm_math.h"
#include "math_helper.h"

#define BLOCK_SIZE	1
#define NUM_TAPS	46

/* Private Variables */
u16 ADC_Converted_Values[256];

/* Filter */
arm_fir_instance_q31 Filter_Abs;
arm_fir_instance_q31 Filter_Dif;

const q31_t pCoeffs[NUM_TAPS] = {2384473,4083124,6616266,9066143,10603884,
		10241301,7043911,424278,-9560401,-21987288,-34977006,-45809583,
		-51264172,-48139271,-33880681,-7201119,31448328,79672346,133267547,
		186705738,233898901,269125622,287949349,287949349,269125622,233898901,
		186705738,133267547,79672346,31448328,-7201119,-33880681,-48139271,
		-51264172,-45809583,-34977006,-21987288,-9560401,424278,7043911,
		10241301,10603884,9066143,6616266,4083124,2384473};
q31_t pStates_Abs[NUM_TAPS+BLOCK_SIZE-1];
q31_t pStates_Dif[NUM_TAPS+BLOCK_SIZE-1];

/*******************************************************************************
* Function Name  : Pressure_Get_Data
* Description    : Get pressure sensor data and filter
* Input          : float* DPres_Voltage, float* Pres_Voltage
* Output         : None
* Return         : None
*******************************************************************************/
void Pressure_Get_Data(u32* DPres_Voltage, u32* Pres_Voltage)
{
	q31_t DPres_Temp = 0;
	q31_t Pres_Temp = 0;
	q31_t DPres_Filtered = 0;
	q31_t Pres_Filtered = 0;
	u16 i;

	// Sum data
	for(i=0;i<=127;i++)
	{
		DPres_Temp+=ADC_Converted_Values[2*i];
		Pres_Temp+=ADC_Converted_Values[2*i+1];
	}
	// Filter Data
	arm_fir_q31(&Filter_Dif,&DPres_Temp,&DPres_Filtered,1);
	arm_fir_q31(&Filter_Abs,&Pres_Temp,&Pres_Filtered,1);
	// Return values
	*DPres_Voltage = (DPres_Filtered*3300)>>19;
	*Pres_Voltage = (Pres_Filtered*3300)>>19;

}
/*******************************************************************************
* Function Name  : Pressure_Filter_Initialize
* Description    : Create Filter using DSP Library
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void Pressure_Filter_Initialize(void)
{
	arm_fir_init_q31(&Filter_Abs,NUM_TAPS,pCoeffs,pStates_Abs,BLOCK_SIZE);
	arm_fir_init_q31(&Filter_Dif,NUM_TAPS,pCoeffs,pStates_Dif,BLOCK_SIZE);
}
/*******************************************************************************
* Function Name  : Pressure_ADC_Initialize
* Description    : Initialize ADC Conversion for differential pressure sensor.
* 				 : ADC clock Set at 9MHz. 239.5 Cycles
* 				 : Conversion Time = (239.5 + 12.5)/9Mhz = 31.5us
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void Pressure_ADC_Initialize(void)
{
	ADC_InitTypeDef ADC_InitStructure;

	//ADC1 Configuration
	ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
	ADC_InitStructure.ADC_ScanConvMode = ENABLE;
	ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
	ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
	ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
	ADC_InitStructure.ADC_NbrOfChannel = 2;
	ADC_Init(ADC1, &ADC_InitStructure);

	//ADC1 Channel 10 @ 239.5 cycles
	ADC_RegularChannelConfig(ADC1, ADC_Channel_10, 1, ADC_SampleTime_239Cycles5);
	ADC_RegularChannelConfig(ADC1, ADC_Channel_11, 2, ADC_SampleTime_239Cycles5);

	// Enable ADC1 DMA
	ADC_DMACmd(ADC1, ENABLE);

	// Enable ADC1
	ADC_Cmd(ADC1, ENABLE);

	// Enable ADC1 reset calibration register
	ADC_ResetCalibration(ADC1);

	// Check the end of ADC1 reset calibration register
	while(ADC_GetResetCalibrationStatus(ADC1));

	// Start ADC1 calibration
	ADC_StartCalibration(ADC1);

	// Check the end of ADC1 calibration
	while(ADC_GetCalibrationStatus(ADC1));

	// Start ADC1 Software Conversion
	ADC_SoftwareStartConvCmd(ADC1, ENABLE);
}
/*******************************************************************************
* Function Name  : Pressure_Read_Data
* Description    : Reads ADC Codes from absolute and differential pressure sensors
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void Pressure_Read_Data(u32* DPres_Voltage,u32* Pres_Voltage)
{
	u32 DPres_Temp = 0;
	u32 Pres_Temp = 0;
	u16 i;
	for(i=0;i<=256;i++)
	{
		DPres_Temp+=ADC_Converted_Values[2*i];
		Pres_Temp+=ADC_Converted_Values[2*i+1];
	}
	//Average Code = Sum / 2^8
	//Voltage [mV] = 3300[mV] * Average Code / 2^12
	//Voltage = 3300*Sum/2^20
	*DPres_Voltage = (3300*DPres_Temp)>>20;
	*Pres_Voltage = ((3300*Pres_Temp)>>20);
}
/*******************************************************************************
* Function Name  : ADC_DMA_Initialize
* Description    : Configure and Initialize DMA controller for ADC1 - DPres + Pres
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void Pressure_ADC_DMA_Initialize(void)
{
	DMA_InitTypeDef DMA_InitStructure;
	DMA_DeInit(DMA1_Channel1);
	DMA_InitStructure.DMA_PeripheralBaseAddr = ADC1_DR_Address;
	DMA_InitStructure.DMA_MemoryBaseAddr = (u32)ADC_Converted_Values;
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;
	DMA_InitStructure.DMA_BufferSize = 256;
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
	DMA_InitStructure.DMA_Priority = DMA_Priority_High;
	DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
	DMA_Init(DMA1_Channel1, &DMA_InitStructure);

	/* Enable DMA1 channel1 */
	DMA_Cmd(DMA1_Channel1, ENABLE);
}
