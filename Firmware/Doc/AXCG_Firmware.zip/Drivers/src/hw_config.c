/*
 * board.c
 *
 *  Created on: Jan 18, 2011
 *      Author: Alex
 */
/* Includes */
#include "board.h"
#include "stm32f10x.h"

/*******************************************************************************
* Function Name  : SysTick_Init
* Description    : Initialise SysTick to X Hz
* Input          : X Hertz
* Return         : None
*******************************************************************************/
void SysTick_Initialize(u32 Tick_Frequency)
{
	//Set Reload Counter
	SysTick->LOAD = SystemCoreClock/Tick_Frequency-1;
	//Start SysTick counter
	SysTick->CTRL |= 7;
}
/*******************************************************************************
* Function Name  : RCC_Configuration
* Description    : Enable Perpheral Bus Clocks
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void RCC_Configuration(void)
{
	//Enable RCC Peripheral Bus Clocks
	// APB2
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB
							|RCC_APB2Periph_GPIOC | RCC_APB2Periph_ADC1
							|RCC_APB2Periph_USART1 | RCC_APB2Periph_ADC3,ENABLE);
	// APB1
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USB | RCC_APB1Periph_TIM3
							|RCC_APB1Periph_I2C1 | RCC_APB1Periph_USART3
							|RCC_APB1Periph_SPI2 | RCC_APB1Periph_UART4
							|RCC_APB1Periph_TIM5 | RCC_APB1Periph_TIM2
							|RCC_APB1Periph_TIM6,ENABLE);
	// APB
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1 | RCC_AHBPeriph_DMA2, ENABLE);

	// Set ADC clock to 72/8 = 9MHz
	RCC_ADCCLKConfig(RCC_PCLK2_Div8);
	// Select USB Clock source
	RCC_USBCLKConfig(RCC_USBCLKSource_PLLCLK_1Div5);
	// Enable the USB clock
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USB, ENABLE);
}
/*******************************************************************************
* Function Name  : NVIC_Configuration
* Description    : Configures the nested vectored interrupt controller.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void NVIC_Configuration(void)
{
	NVIC_InitTypeDef NVIC_InitStructure;

	// USB Interrupt
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
	NVIC_InitStructure.NVIC_IRQChannel = USB_LP_CAN1_RX0_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	// USART4 Interrupt Setup
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
	NVIC_InitStructure.NVIC_IRQChannel = UART4_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	// USART1 Interrupt Setup
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	// USART3 Interrupt Setup
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
	NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	// TIM6 Interrupt Setup
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
	NVIC_InitStructure.NVIC_IRQChannel = TIM6_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

}
/*******************************************************************************
* Function Name  : GPIO_Configuration
* Description    : Configure all used pins
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void GPIO_Configuration(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	// *** PA ***
	// Special Outputs
	GPIO_InitStructure.GPIO_Pin = PWM_7 | PWM_6 | PWM_5 | PWM_1 | PWM_2 | PWM_3 | GPS_RX;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	// Inputs
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin = GPS_TX | PAD2 | PAD1;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	// GPIO Outputs
	GPIO_InitStructure.GPIO_Pin =  USB_DISC;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	// *** PB ***
	// Special Outputs
	GPIO_InitStructure.GPIO_Pin = PWM_4 | MSD_CS | SPI_CLK | MSD_MOSI;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	// GPIO Outputs
	GPIO_InitStructure.GPIO_Pin = LED_1 | AHRS_RST_N | AHRS_FW;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	// Inputs
	GPIO_InitStructure.GPIO_Pin = PAD6 | THERM_WD | SAT_TX | MSD_MISO;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	// Open Drain (I2C)
	GPIO_InitStructure.GPIO_Pin = I2C_SCL | I2C_SDA;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	// *** PC ***
	// GPIO Outputs
	GPIO_InitStructure.GPIO_Pin = LED_3 | LED_2 | AHRS_EN | GPS_EN | AHRS_TARE | AHRS_REPGRM;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &GPIO_InitStructure);

	// Special Outputs
	GPIO_InitStructure.GPIO_Pin = AHRS_RX;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init(GPIOC, &GPIO_InitStructure);

	// Inputs
	GPIO_InitStructure.GPIO_Pin = GPS_FIX | PAD9 | BUTTON_2 | AHRS_TX | PAD10 | PAD11 | BUTTON_1;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOC, &GPIO_InitStructure);

	// Analog Inputs
	GPIO_InitStructure.GPIO_Pin = DPRES | PRES;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
}
