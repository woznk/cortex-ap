/*
 * gps.c
 *
 *  Created on: Feb 27, 2011
 *      Author: Alex
 */
/* Includes */
#include "main.h"


/* Build Configurations */
//#define GPS_DMA_ENABLE

/* Private define  */
#define NMEA_MODE 0
#define BINARY_MODE 1

/* Private variables */
u8 GPS_Rx_Counter = 0;
u8 GPS_Tx_Counter = 0;
u8 GPS_Tx_Length = 0;
bool USART_Ready = TRUE;
extern u8 GPS_Mode;
extern char GPS_RxBuffer[256];
extern char GPS_TxBuffer[256];


/*******************************************************************************
* Function Name  : GPS_DMA_Initialize
* Description    : Initialize GPS DMA (Rx/Tx) DMA1_Channel5
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
#ifdef GPS_DMA
void GPS_DMA_Initialize(void)
{
	DMA_InitTypeDef DMA_InitStructure;

	// DMA1 Channel4 (triggered by USART1 Tx event) Configuration
	DMA_DeInit(DMA1_Channel4);
	DMA_InitStructure.DMA_PeripheralBaseAddr = USART1_DR_Address;
	DMA_InitStructure.DMA_MemoryBaseAddr = (u32)GPS_TxBuffer;
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
	DMA_InitStructure.DMA_BufferSize = 0;
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
	DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
	DMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;
	DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
	DMA_Init(DMA1_Channel4, &DMA_InitStructure);
	// Enable is in GPS_Send_Message()

	// DMA1 Channel5 (triggered by USART1 Rx event) Configuration
	DMA_DeInit(DMA1_Channel5);
	DMA_InitStructure.DMA_PeripheralBaseAddr = USART1_DR_Address;
	DMA_InitStructure.DMA_MemoryBaseAddr = (u32)GPS_RxBuffer;
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;
	DMA_InitStructure.DMA_BufferSize = 256;
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
	DMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;
	DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
	DMA_Init(DMA1_Channel5, &DMA_InitStructure);
	//Enable
	DMA_Cmd(DMA1_Channel5, ENABLE);

	// Enable Rx/Tx DMA Request
	USART_DMACmd(USART1, USART_DMAReq_Tx|USART_DMAReq_Rx, ENABLE);
}
#endif
/*******************************************************************************
* Function Name  : GPS_Initialize
* Description    : Initialize GPS as Binary and 10hz
* Input          : None
* Output         : None
* Return         : None
* TODO: Add input for different initialize modes. And fix Refresh rate :(
*******************************************************************************/
void GPS_Initialize(void)
{
	Delay_us(1000000);
	GPS_Send_Message("$PMTK220,200*2C\r\n");
	Delay_us(500000);
	GPS_Send_Message("$PGCMD,16,0,0,0,0,0*6A\r\n");
	Delay_us(500000);
	GPS_Send_Message("$PMTK220,200*2C\r\n");
	Delay_us(500000);
	GPS_Send_Message("$PMTK220,200*2C\r\n");
	Delay_us(500000);
	GPS_Mode = BINARY_MODE;
}
/*******************************************************************************
* Function Name  : GPS_USART_Initialize
* Description    : Initialize GPS USART1 as Tx/Rx with default parameters
* 				 : 8 bit, 9600 baud rate, 1 stop bit, no parity
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void GPS_USART_Initialize(u32 Baud_Rate)
{
	USART_InitTypeDef USART_InitStructure;

	// Set Bus Parameters
	USART_InitStructure.USART_BaudRate = Baud_Rate;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(USART1, &USART_InitStructure);

	// Enable Rx and Tx Interrupts
#ifndef GPS_DMA
	USART_ITConfig(USART1, USART_IT_RXNE , ENABLE);
	USART_ITConfig(USART1, USART_IT_TC , ENABLE);
#endif
	// Enable USART1
	USART_Cmd(USART1, ENABLE);

}

/*******************************************************************************
* Function Name  : GPS_Read_Buffer
* Description    : Reads and sorts data in GPS Rx circle buffer.
* 				 : Rights to GPS_Message string
* Input          : None
* Output         : None
* Return         : None
* TODO: Create work string and transfer when done, allow overwrite if new complete string
*******************************************************************************/
void GPS_Read_Buffer(char* GPS_RxBuffer, GPS_Message_Type* GPS_Message)
{
	static u8 Buffer_Position = 0;
	static u8 String_Position;
	static u8 state = 0;
	static u16 Byte_Count = 0;
	u8 GPS_Rx_Position = GPS_Rx_Counter;

	while (Buffer_Position != GPS_Rx_Position)
	{
		// NMEA Message Mode
		if (GPS_Mode == NMEA_MODE)
		{
			switch(state){
			case 0:
				if (GPS_RxBuffer[Buffer_Position] =='$')
				{
					state = 1;
					GPS_Message->Message[String_Position++]='$';
				}
				break;
			case 1:
				if(GPS_RxBuffer[Buffer_Position] != '\n')
				{
					GPS_Message->Message[String_Position++]=GPS_RxBuffer[Buffer_Position];
				}
				else
				{
					// String done -> end with \n and \0
					GPS_Message->Message[String_Position]='\n';
					GPS_Message->Message[String_Position+1]='\0';
					String_Position = 0;
					GPS_Message->New_Message = TRUE;
					state = 0;
				}
				break;
			}
			Buffer_Position++;
		}
		// Binary Mode
		if (GPS_Mode == BINARY_MODE)
		{
			switch(state){
			// 0xD0
			case 0:
				if (GPS_RxBuffer[Buffer_Position] == 0xD0)
				{
					state = 1;
					GPS_Message->Message[String_Position++]=0xD0;
					Byte_Count++;
				}
				break;
			// 0xDD
			case 1:
				if (GPS_RxBuffer[Buffer_Position] == 0xDD)
				{
					state = 2;
					GPS_Message->Message[String_Position++]=0xDD;
					Byte_Count++;
				}
				break;
			case 2:
				GPS_Message->Message[String_Position++]=GPS_RxBuffer[Buffer_Position];
				Byte_Count++;
				if(Byte_Count == 37)
				{
					// String done -> end with \n and \0
					GPS_Message->Message[String_Position]='\0';
					GPS_Message->New_Message = TRUE;
					String_Position = 0;
					state = 0;
					Byte_Count = 0;
				}
				break;
			}
			Buffer_Position++;
		}
	}
}
/*******************************************************************************
* Function Name  : GPS_Message_Parse
* Description    : Decode GPS String message
* Input          : None
* Output         : None
* Return         : bool, If completed without error returns TRUE, else FALSE
* TODO: Add checksum verification on binary and complete NMEA
*******************************************************************************/
bool GPS_Message_Parse(GPS_Message_Type* GPS_Message, GPS_Data_Type* GPS_Data)
{
	u8 Message_ID_Sum = 0;
	u8 Checksum = 0;
	u8 i = 0;
	u32 Time_Grouped = 0;
	u32 Date_Grouped = 0;

	if (GPS_Mode == BINARY_MODE)
	{
		// Latitude
		GPS_Data->Position.Latitude = (GPS_Message->Message[3]<<0) +
				(GPS_Message->Message[4]<<8) + (GPS_Message->Message[5]<<16) +
				(GPS_Message->Message[6]<<24);

		// Longitude
		GPS_Data->Position.Longitude = (GPS_Message->Message[7]<<0) +
				(GPS_Message->Message[8]<<8) + (GPS_Message->Message[9]<<16) +
				(GPS_Message->Message[10]<<24);

		// Altitude in cm
		GPS_Data->Altitude = (GPS_Message->Message[11]<<0) +
				(GPS_Message->Message[12]<<8) + (GPS_Message->Message[13]<<16) +
				(GPS_Message->Message[14]<<24);

		//Ground Speed
		GPS_Data->Ground_Speed = (GPS_Message->Message[15]<<0) +
				(GPS_Message->Message[16]<<8) + (GPS_Message->Message[17]<<16) +
				(GPS_Message->Message[18]<<24);

		//Heading in millidegrees
		GPS_Data->Heading = ((GPS_Message->Message[19]<<0) +
				(GPS_Message->Message[20]<<8) + (GPS_Message->Message[21]<<16) +
				(GPS_Message->Message[22]<<24))*10;

		// Number of satellites viewed
		GPS_Data->Sattelites_Used = GPS_Message->Message[23];

		// Fix type: 1 =  No Fix, 2 = 2D Fix, 3 = 3D Fix
		GPS_Data->Fix_Type = GPS_Message->Message[24];

		// Date
		Date_Grouped = (GPS_Message->Message[25]<<0) +
				(GPS_Message->Message[26]<<8) + (GPS_Message->Message[27]<<16) +
				(GPS_Message->Message[28]<<24);
		//split date
		GPS_Data->Date.Day = Date_Grouped%10000;
		Date_Grouped -= GPS_Data->Date.Day*10000;
		GPS_Data->Date.Month = Date_Grouped%100;
		Date_Grouped -= Date_Grouped*100;
		GPS_Data->Date.Year = 2000+Date_Grouped;

		// Grouped Time
		Time_Grouped = (GPS_Message->Message[29]<<0) +
				(GPS_Message->Message[30]<<8) + (GPS_Message->Message[31]<<16) +
				(GPS_Message->Message[32]<<24);
		//Split time
		GPS_Data->UTC_Time.Hours = Time_Grouped%10000;
		Time_Grouped -= GPS_Data->UTC_Time.Hours*10000;
		GPS_Data->UTC_Time.Minutes = Time_Grouped%100;
		Time_Grouped -= GPS_Data->UTC_Time.Minutes*100;
		GPS_Data->UTC_Time.Seconds = Time_Grouped;

		//HDOP
		GPS_Data->HDOP = (GPS_Message->Message[33]<<0) + (GPS_Message->Message[34]<<8);

		return TRUE;
	}
	else if (GPS_Mode == NMEA_MODE)
	{
		//Find checksum position
		while(GPS_Message->Message[i++] != '*');
		//Read Checksum
		if(GPS_Message->Message[i]>='A')
			Checksum = GPS_Message->Message[i++]-55;
		else
			Checksum = GPS_Message->Message[i++]-'0';
		Checksum=Checksum<<4;
		if(GPS_Message->Message[i]>='A')
			Checksum += GPS_Message->Message[i]-55;
		else
			Checksum += GPS_Message->Message[i]-'0';
		//Compare Checksum
		if (Checksum == Checksum_Calculate(&GPS_Message->Message[1]))
		{
			//Read GPS message header and add characters:
			/* GGA : 207
			 * GSA : 219
			 * GSV : 240
			 * RMC : 226
			 * VTG : 241
			 */
			for(i=3;i<6;i++)
				Message_ID_Sum += GPS_Message->Message[i];

			// Parse corresponding data string
			switch (Message_ID_Sum) {
			//GGA
			case 207:
				break;
			//GSA
			case 219:
				break;
			//GSV
			case 240:
				break;
			//RMC
			case 226:
				break;
			//VTG
			case 241:
				break;
			default:
				break;
			}
			// If got to end
			return TRUE;
		}
	}
	return FALSE;
}
/*******************************************************************************
* Function Name  : GPS_Send_Message
* Description    : Send String to GPS
* Input          : *Char
* Output         : None
* Return         : None
* TODO: Find alternative to infite loop while waiting
*******************************************************************************/
void GPS_Send_Message(char* Message)
{
	u8 Length = 0;
	// Wait until is done
#ifndef GPS_DMA
	while(USART_Ready != TRUE);
#else
	while(DMA1_Channel4->CNDTR!=0);
	DMA_Cmd(DMA1_Channel4, DISABLE);
#endif
	// Copy message to GPS_Tx_Buffer
	while(Message[Length]!=0)
	{
		GPS_TxBuffer[Length]=Message[Length];
		Length++;
	}
#ifndef GPS_DMA
	GPS_Tx_Length = Length;
	GPS_Tx_Counter = 1;
	// Enable Tx Interrupt and send first byte
	USART_ITConfig(USART1, USART_IT_TC, ENABLE);
	USART_SendData(USART1, GPS_TxBuffer[0]);
	USART_Ready = FALSE;
#else
	DMA1_Channel4->CNDTR = Length-1;
	DMA_Cmd(DMA1_Channel4,ENABLE);
#endif

}
/*******************************************************************************
* Function Name  : GPS_Enable
* Description    : Enable / Disable GPS Pin
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void GPS_Enable(FunctionalState Command)
{
	if (Command == ENABLE)
		GPIO_SetBits(GPIOC,GPS_EN);
	if (Command == DISABLE)
		GPIO_ResetBits(GPIOC,GPS_EN);
}
