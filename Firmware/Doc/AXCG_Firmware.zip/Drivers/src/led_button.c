/*
 * led_button.c
 *
 *  Created on: Feb 28, 2011
 *      Author: Alex
 */
#include "stm32f10x.h"
#include "board.h"

/*******************************************************************************
* Function Name  : Led_Set
* Description    : Turn Led X ON
* Input          : Led number
* Output         : None
* Return         : None
*******************************************************************************/
void Led_Set(u8 Led)
{
	switch(Led){
	case 1:
		GPIO_SetBits(GPIOB,LED_1);
		break;
	case 2:
		GPIO_SetBits(GPIOC,LED_2);
		break;
	case 3:
		GPIO_SetBits(GPIOC,LED_3);
		break;
	case 0:
		GPIO_SetBits(GPIOB,LED_1);
		GPIO_SetBits(GPIOC,LED_2);
		GPIO_SetBits(GPIOC,LED_3);
	default : break;
	}
}
/*******************************************************************************
* Function Name  : Led_Set
* Description    : Toggle Led X ON
* Input          : Led number
* Output         : None
* Return         : None
*******************************************************************************/
void Led_Toggle(u8 Led)
{
	switch(Led){
	case 1 :
		if (GPIO_ReadInputDataBit(GPIOB,LED_1) == 1)
			GPIO_ResetBits(GPIOB,LED_1);
		else
			GPIO_SetBits(GPIOB,LED_1);
		break;
	case 2 :
		if (GPIO_ReadInputDataBit(GPIOC,LED_2) == 1)
			GPIO_ResetBits(GPIOC,LED_2);
		else
			GPIO_SetBits(GPIOC,LED_2);
		break;
	case 3 :
		if (GPIO_ReadInputDataBit(GPIOC,LED_3) == 1)
			GPIO_ResetBits(GPIOC,LED_3);
		else
			GPIO_SetBits(GPIOC,LED_3);
		break;
	default :
		break;
	}
}
/*******************************************************************************
* Function Name  : Led_Reset
* Description    : Turn X Led OFF
* Input          : Led number
* Output         : None
* Return         : None
*******************************************************************************/
void Led_Reset(u8 Led)
{
	switch(Led){
	case 1:
		GPIO_ResetBits(GPIOB,LED_1);
		break;
	case 2:
		GPIO_ResetBits(GPIOC,LED_2);
		break;
	case 3:
		GPIO_ResetBits(GPIOC,LED_3);
		break;
	case 0:
		GPIO_ResetBits(GPIOB,LED_1);
		GPIO_ResetBits(GPIOC,LED_2);
		GPIO_ResetBits(GPIOC,LED_3);
		break;
	default:
		break;
	}
}
/*******************************************************************************
* Function Name  : Button1_Rising_Edge
* Description    : Check's for a rising edge on the two buttons
* Input          : button number
* Output         : None
* Return         : Boolean -> TRUE = Rising Edge
*******************************************************************************/
bool Button1_Rising_Edge(void)
{
	static u8 Button_Previous = 0;
	u8 Button_Status = 0;
	bool Result = FALSE;

	// Read GPIO Ports
	Button_Status = !GPIO_ReadInputDataBit(GPIOC,BUTTON_1);

	if (Button_Status == 1 && Button_Previous == 0)
			Result = TRUE;
	Button_Previous = Button_Status;
	return Result;
}
/*******************************************************************************
* Function Name  : Button2_Rising_Edge
* Description    : Check's for a rising edge on the two buttons
* Input          : button number
* Output         : None
* Return         : Boolean -> TRUE = Rising Edge
*******************************************************************************/
bool Button2_Rising_Edge(void)
{
	static u8 Button_Previous = 0;
	u8 Button_Status = 0;
	bool Result = FALSE;

	// Read GPIO Ports
	Button_Status = !GPIO_ReadInputDataBit(GPIOC,BUTTON_2);

	if (Button_Status == 1 && Button_Previous == 0)
			Result = TRUE;
	Button_Previous = Button_Status;
	return Result;
}
