/******************** (C) COPYRIGHT 2010 STMicroelectronics ********************
* File Name          : usb_endp.c
* Author             : MCD Application Team
* Version            : V3.2.1
* Date               : 07/05/2010
* Description        : Endpoint routines
********************************************************************************
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "usb_lib.h"
#include "usb_desc.h"
#include "usb_mem.h"
#include "usb.h"
#include "usb_istr.h"
#include "usb_pwr.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/

/* Interval between sending IN packets in frame number (1 frame = 1ms) */
#define VCOMPORT_IN_FRAME_INTERVAL             5

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
extern u8 USB_Rx_Buffer[256];
extern u8 USB_Rx_Head;
extern u8 USB_Rx_Tail;

extern uint8_t USART_Rx_Buffer[];
extern uint32_t USART_Rx_ptr_out;
extern uint32_t USART_Rx_length;
extern uint8_t  USB_Tx_State;
/*extern u8 USB_Tx_Buffer[256];
extern u8 USB_Tx_Head;
extern u8 USB_Tx_Tail;*/

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/*******************************************************************************
* Function Name  : EP1_IN_Callback
* Description    :
* Input          : None.
* Output         : None.
* Return         : None.
*******************************************************************************/
void EP1_IN_Callback (void)
{
	  uint16_t USB_Tx_ptr;
	  uint16_t USB_Tx_length;

	  if (USB_Tx_State == 1)
	  {
	    if (USART_Rx_length == 0)
	    {
	      USB_Tx_State = 0;
	    }
	    else
	    {
	      if (USART_Rx_length > VIRTUAL_COM_PORT_DATA_SIZE){
	        USB_Tx_ptr = USART_Rx_ptr_out;
	        USB_Tx_length = VIRTUAL_COM_PORT_DATA_SIZE;

	        USART_Rx_ptr_out += VIRTUAL_COM_PORT_DATA_SIZE;
	        USART_Rx_length -= VIRTUAL_COM_PORT_DATA_SIZE;
	      }
	      else
	      {
	        USB_Tx_ptr = USART_Rx_ptr_out;
	        USB_Tx_length = USART_Rx_length;

	        USART_Rx_ptr_out += USART_Rx_length;
	        USART_Rx_length = 0;
	      }
	      UserToPMABufferCopy(&USART_Rx_Buffer[USB_Tx_ptr], ENDP1_TXADDR, USB_Tx_length);
	      SetEPTxCount(ENDP1, USB_Tx_length);
	      SetEPTxValid(ENDP1);

	    }
	  }
	/*u8 charcount;
	u16 temp1;
	u16 *pdwVal;
	if(USB_Tx_Head != USB_Tx_Tail)
	{

	   charcount = 0;
	   temp1 = 0;
	   pdwVal = (u16 *)(ENDP1_TXADDR * 2 + PMAAddr);

	   while(USB_Tx_Head != USB_Tx_Tail && charcount < VIRTUAL_COM_PORT_DATA_SIZE)
	   {
	      charcount++;

	      if (!(charcount & 1))
	      {
	        *pdwVal++ = temp1 + (u16) (USB_Tx_Buffer[USB_Tx_Tail++] << 8);
	         pdwVal++;
	      }
	      else
	         temp1 = (u16) USB_Tx_Buffer[USB_Tx_Tail++];
	   }
	   if(charcount & 1)
	      *pdwVal = temp1;
	   SetEPTxCount(ENDP1, charcount);
	   SetEPTxValid(ENDP1);
	}*/

}
/*******************************************************************************
* Function Name  : EP3_OUT_Callback
* Description    :
* Input          : None.
* Output         : None.
* Return         : None.
*******************************************************************************/
void EP3_OUT_Callback(void)
{

	u8 bytes_stored_in_circ_buf = 0;
	u8 bytes_recvd = GetEPRxCount( ENDP3 );
	u8* pdwVal = (u8 *)(ENDP3_RXADDR * 2 + PMAAddr);

	while ( 1 ) {
	   /* Check if buffer id full */
	   if(USB_Rx_Head+1 == USB_Rx_Tail)
	   {
	      SetEPRxValid( ENDP3 );
	      return;
	   }

	   *(USB_Rx_Buffer + USB_Rx_Head) = (unsigned char)*pdwVal;
	   ++USB_Rx_Head;
	   ++pdwVal;

	   ++bytes_stored_in_circ_buf;
	   if(bytes_stored_in_circ_buf >= bytes_recvd)
	   {
	      break;
	   }

	   if(USB_Rx_Head+1 == USB_Rx_Tail)
	   {
	      SetEPRxValid( ENDP3 );
	      return;
	   }

	   *(USB_Rx_Buffer + USB_Rx_Head) = (unsigned char)*pdwVal;
	   ++USB_Rx_Head;
	   ++pdwVal;

	   ++bytes_stored_in_circ_buf;
	   if(bytes_stored_in_circ_buf >= bytes_recvd)
	   {
	      break;
	   }
	   pdwVal += 2;
	}
	SetEPRxValid( ENDP3 );
}

/*******************************************************************************
* Function Name  : SOF_Callback / INTR_SOFINTR_Callback
* Description    :
* Input          : None.
* Output         : None.
* Return         : None.
*******************************************************************************/
void SOF_Callback(void)
{
	static uint32_t FrameCount = 0;
	if(bDeviceState == CONFIGURED)
		if (FrameCount++ == VCOMPORT_IN_FRAME_INTERVAL)
	    {
	      /* Reset the frame counter */
	      FrameCount = 0;

	      /* Check the data to be sent through IN pipe */
	      Handle_USBAsynchXfer();
	    }
		//EP1_IN_Callback(); // TEST
}
/******************* (C) COPYRIGHT 2010 STMicroelectronics *****END OF FILE****/

