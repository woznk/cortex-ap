/*
 * controller.h
 *
 *  Created on: May 19, 2011
 *      Author: Alex
 */

typedef struct
{
	float B0;          /**< The derived gain, A0 = Kp + Ki + Kd . */
    float B1;          /**< The derived gain, A1 = -Kp - 2Kd. */
    float B2;          /**< The derived gain, A2 = Kd . */
    float State[3];    /**< The state array of length 3. */
    float Endpoint[2]; /**< Min and max saturation. */
    float Kp;          /**< The proportional gain. */
    float Ki;	       /**< The integral gain. */
    float Kd;		   /**< The derivative gain. */
} PID_Instance_f32_Sat;

void PID_Init_f32(PID_Instance_f32_Sat*, int Reset_State );
float PID_f32(PID_Instance_f32_Sat * S,float In);
