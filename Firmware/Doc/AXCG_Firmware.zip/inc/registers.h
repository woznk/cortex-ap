/*
 * registers.h
 *
 *  Created on: May 16, 2011
 *      Author: Alex
 */
#include "stm32f10x.h"
/****** Registers ******/
#define YPR_DATA_REG				1	//R
#define GPS_DATA_REG				2	//R
#define PRESSURE_DATA_REG			3	//R
#define CYCLE_READ_REG				4	//RW
#define CYCLE_READ_FREQ_REG			5	//RW
#define MODE_REG					6	//RW
#define SD_LOG_FREQ_REG				7	//RW
#define SERVO_POSITIONS_REG			8	//R
#define ATTITUDE_PID_FREQ_REG		9	//RW
#define AILERON_PID_REG				10	//RW
#define	ELEVATOR_PID_REG			11	//RW
#define NAVIGATION_PID_FREQ_REG		12	//RW
#define ROLL_PID_REG				13	//RW
#define PITCH_PID_REG				14	//RW
#define SERVO_EP_REG				15	//RW
#define MAX_BANK_REG				16	//RW
#define MAX_PITCH_REG				17	//RW
#define WAYPOINTS_REG				18	//RW
#define CRUISE_SPEED_REG			19	//RW
#define GPS_ALT_ERROR_REG			20	//RW
#define THROTTLE_ALT_THRESH_REG		21	//RW
#define PITCH_OFFSET_REG			22	//RW
#define RADIO_TIMEOUT_REG			23	//RW


/* Macros */
// Stringification
#define XSTR(a) STR(a)
#define STR(a) #a
// Register read header
#define READ_HEADER(x) ( "$AXRRG," XSTR(x) "," )
