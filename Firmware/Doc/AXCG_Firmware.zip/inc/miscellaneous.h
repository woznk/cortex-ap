/*
 * misc.h
 *
 *  Created on: Mar 9, 2011
 *      Author: Alex
 */

void Delay_us(u32);
void Demo_Routine(void);
