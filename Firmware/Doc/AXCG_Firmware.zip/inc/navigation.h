/*
 * navigation.h
 *
 *  Created on: May 26, 2011
 *      Author: Alex
 */
/* Macros */
//Degree/ Radian Conversions
#define D2R(x) ((x) * 0.0174532925)
#define R2D(x) ((x) * 57.29577951)
/* public defines */
/* public typedef */
#include "stm32f10x.h"
typedef struct {
	int Latitude;
	int Longitude;
	int Altitude;
	u16 Radius;
	u8 Next;
} Waypoint_Type;

typedef struct {
	int Latitude;
	int Longitude;
	int Altitude;
} Location_Type;

typedef enum {Manual,FBW,Auto_A,Auto_B} Flight_Mode_Type;

/* public functions */
float Get_Bearing_Error(float Set_Bearing, float Current_Bearing);
float Get_Bearing(Location_Type* Current_Location,Waypoint_Type* Next_Location);
float Get_Distance_2D(Location_Type* Current_Location,Waypoint_Type* Next_Location);
