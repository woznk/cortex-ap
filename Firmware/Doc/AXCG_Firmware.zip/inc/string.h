/*
 * string.h
 *
 *  Created on: Feb 27, 2011
 *      Author: Alex
 */
#include "stm32f10x.h"

void Int_To_Dec_String (s32, char* String, u8 Zero_Fill, bool);
void Int_To_Hex_String(u32,char*);
u16 String_Append(char*,char*,u16);
u16 String_Get_Length(char*);
char Checksum_Calculate(char*);
int String_To_Int(char*,u8);
