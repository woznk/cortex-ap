/*
 * main.h
 *
 *  Created on: Feb 28, 2011
 *      Author: Alex
 */

/* Includes */
//#include <stddef.h>
#include <stdlib.h>
#include "stm32f10x.h"
#include "board.h"
#include "hw_config.h"
#include "usb_lib.h"
#include "usb_desc.h"
#include "usb_mem.h"
#include "usb.h"
#include "usb_istr.h"
#include "usb_pwr.h"
#include "ff.h"
#include "rtc.h"
#include "ahrs.h"
#include "gps.h"
#include "string.h"
#include "led_button.h"
#include "sdcard.h"
#include "radio_servos.h"
#include "pressure_sensors.h"
#include "miscellaneous.h"
#include "controller.h"
#include "navigation.h"
#include "I2C_ee.h"
/* public define  */
#define TIMER_PRESCALER 72-1
#define ADC1_DR_Address ((u32)0x4001244C)
#define ADC3_DR_Address ((u32)0x40013C4C)
#define UART4_DR_Address ((u32)0x40004C04)
#define USART1_DR_Address ((u32)0x40013804)
#define NMEA_MODE	0
#define BINARY_MODE	1
#define MAX_WAYPOINTS	32
#define ZERO_AIRSPEED_VOLTAGE 1075

// Radio/Servo channels
#define AILERON_CHANNEL		0
#define FLAP_CHANNEL		1
#define GEAR_CHANNEL		2
#define ELEVATOR_CHANNEL	3
#define AUX2_CHANNEL		4
#define THROTTLE_CHANNEL	5
#define RUDDER_CHANNEL		6

/* Macros */

/* public Structures */
/* public function prototypes */
void Attitude_Controller_Task(void*);
