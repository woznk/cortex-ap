/*
 * misc.c
 *
 *  Created on: Mar 9, 2011
 *      Author: Alex
 */
#include "main.h"
/*******************************************************************************
* Function Name  : Delay
* Description    : Delay x us
* Input          : u32 Delay
* Output         : None
* Return         : None
*******************************************************************************/
void Delay_us(u32 Delay)
{
	u32 i =0;
	for(i=Delay*10; i--; );
}
/*******************************************************************************
* Function Name  : Demo_Routine
* Description    : Old demo function to test specific elements
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void Demo_Routine(void)
{
}
