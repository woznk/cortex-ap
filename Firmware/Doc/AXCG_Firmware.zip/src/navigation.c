/*
 * navigation.c
 *
 *  Created on: May 26, 2011
 *      Author: Alex
 */
#include "navigation.h"
#include "arm_math.h"
#include "math_helper.h"
#include <math.h>
/*******************************************************************************
* Function Name  : Bearing_Error
* Description    : determine bearing between two Bearings
* Input          : Location1, Location2
* Output         : Float
* Return         : Float, Float
*******************************************************************************/
float Get_Bearing_Error(float Set_Bearing, float Current_Bearing)
{
	float Error =(Set_Bearing - Current_Bearing);

	if(Error > 180)
		Error -= 360;
	else if (Error < -180)
		Error += 360;
	return Error;
}
/*******************************************************************************
* Function Name  : Get_Bearing
* Description    : determine bearing between two locations
* Input          : Location1, Location2
* Output         : bearing
* Return         : Bearing in degrees
*******************************************************************************/
float Get_Bearing(Location_Type* Current_Location,Waypoint_Type* Next_Location)
{
	// get x and y offsets
	float Delta_Lat = ((float)Next_Location->Latitude - (float)Current_Location->Latitude)/1000000;
	float Delta_Long = ((float)Next_Location->Longitude - (float)Current_Location->Longitude)/1000000;
	Delta_Lat /= cos(D2R ((float)Next_Location->Latitude+(float)Current_Location->Latitude) /2000000 );
	// calculate bearing
	float Bearing = 90 + atan2(-Delta_Lat, Delta_Long) * 57.2957795;
	// wrap -> 0 to 360
	if (Bearing < 0)
		Bearing += 360;
	return(Bearing);
}

/*******************************************************************************
* Function Name  : Get_Distance_2D
* Description    : determine distance between current
* 				 : location and next waypoint in 2D (lat and Long)
* Input          : Location1, Location2
* Output         : bearing
* Return         : Distance in meters
*******************************************************************************/
float Get_Distance_2D(Location_Type* Current_Location,Waypoint_Type* Next_Location)
{
	/* Equirectangular approximation */
	// get x and y deltas
	float Delta_Lat = ((float)Next_Location->Latitude - (float)Current_Location->Latitude)/1000000;
	float Delta_Long = ((float)Next_Location->Longitude- (float)Current_Location->Longitude)/1000000;
	//Scale long
	Delta_Long *= cos(D2R ((float)Next_Location->Latitude+(float)Current_Location->Latitude) /2000000 );

	// calculate distance
	float Distance = pow(Delta_Lat,2)+pow(Delta_Long,2);
	Distance = sqrt(Distance);
	// transform degrees to distance [m] -> earth circumference = 40075160[m]
	Distance *= 111319.9;
	return(Distance);

	/*  haversine formula */
	/*float Lat1 = D2R((float)Next_Location->Latitude/1000000);
	float Lat2 = D2R((float)Current_Location->Latitude/1000000);
	float Delta_Lat = Lat2 - Lat1;
	float Delta_Long = D2R((float)Next_Location->Longitude/1000000 - (float)Current_Location->Longitude/1000000);
	float a = sin(Delta_Lat/2)*sin(Delta_Lat/2)+sin(Delta_Long/2)*sin(Delta_Long/2)*cos(Lat1)*cos(Lat2);
	float c =2*atan2(sqrt(a),sqrt(1-a));
	return c*6371000;*/

}
