/*
 * string.c
 *
 *  Created on: Feb 27, 2011
 *      Author: Alex
 */
/* Includes */
#include "string.h"

/*******************************************************************************
* Function Name  : Int_To_Dec_String
* Description    : Converts an Integer to a decimal string
* Input          : Integer to convert, and pointer to string to write result.
* Output         : None
* Return         : None
*******************************************************************************/
void Int_To_Dec_String (s32 Value, char* String, u8 Zero_Fill,bool Plus_Sign)
{
	s32 Number = Value;
	char Inv_String[10];
	s16 i = 0;
	u8 Temp = 0;
	bool Negative = FALSE;

	//Check if negative
	if(Number<0)
	{
		Number = 0-Number;
		Negative = TRUE;
	}
	// Convert to string (inverted!)
	if(Number == 0)
		Inv_String[i++]= '0';
	else
	{
		while (Number != 0)
		{
			Temp = Number%10;
			Inv_String[i++]= (Temp+'0');
			Number-=Temp;
			Number/=10;
		}
	}
	//Fill Rest with zeros
	while(i< Zero_Fill)
		Inv_String[i++]='0';
	// If negative add minus sign
	if(Negative == TRUE)
		Inv_String[i++]='-';
	else if(Plus_Sign == TRUE)
		Inv_String[i++]='+';
	//Flip String
	u8 j=0;
	for(i-=1;i>=0;i--)
		String[j++]=Inv_String[i];
	//finish with null character
	String[j]='\0';
}
/*******************************************************************************
* Function Name  : Int_To_Hex_String
* Description    : Converts an Integer to a hex string
* Input          : Integer to convert, and pointer to string to write result.
* Output         : None
* Return         : None
*******************************************************************************/
void Int_To_Hex_String (u32 Value, char* String)
{
	u32 Work_Value = Value;
	char Inv_String[10];
	s16 i = 0;
	u8 Temp = 0;
	while (Work_Value != 0)
	{
		Temp = Work_Value&0xF;
		if (Temp <=9)
			Inv_String[i++]= (Temp+'0');
		else
			Inv_String[i++]= (Temp-10+'A');
		Work_Value=Work_Value>>4;
	}
	//Flip String
	u8 j=0;
	for(i-=1;i>=0;i--)
		String[j++]=Inv_String[i];
	//finish with null character
	String[j]='\0';
}
/*******************************************************************************
* Function Name  : String_Append
* Description    : Adds a string to end of another string.
* Input          : Pointers to Base string and append string.
* 				 : Optional: End of base string position. if 0 will find it.
* Output         : None
* Return         : End of String position
*******************************************************************************/
u16 String_Append(char* String_Base, char* String_Append, u16 End_Of_String)
{
	u16 i = 0;
	u16 j = 0;
	if (End_Of_String == 0)
	{
		//Find end of string
		while(String_Base[i++]!='\0');
		//Point to '\0' character.
		i--;
	}
	else
		i = End_Of_String;
	//Add append string until null character
	while(String_Append[j]!=0)
	{
		String_Base[i++]=String_Append[j++];
	}
	//Add null character at end
	String_Base[i]='\0';
	return i;
}
/*******************************************************************************
* Function Name  : String_Get_Length
* Description    : Determines length of string
* Input          : Pointer to string
* Output         : None
* Return         : Length of string
*******************************************************************************/
u16 String_Get_Length(char* String)
{
	u16 Length = 0;
	while(String[Length++]!='\0');
	return Length-1;
}
/*******************************************************************************
* Function Name  : Checksum_Calculate
* Description    : Calculate checksum for AHRS message
* Input          : char* String - String
* Output         : None
* Return         : char checksum result
*******************************************************************************/
char Checksum_Calculate(char* String)
{
	unsigned char xor = 0;
	u16 i = 0;
	// Go until end of string or *
	while (String[i]!= '\0' && String[i]!= '*' )
		xor ^= (unsigned char)String[i++];
	return xor;
}
/*******************************************************************************
* Function Name  : String_To_Int
* Description    : Calculate integer value from ascii string
* Input          : char* String - String, u8 Length
* Output         : None
* Return         : Value
*******************************************************************************/
int String_To_Int(char* String,u8 Length)
{
	u8 i = 0;;
	bool Negative = FALSE;
	s32 Value=0;

	//Check for sign and remove if present
	if(String[0]=='-')
	{
		Negative = TRUE;
		i++;
	}
	else if(String[0]=='+')
		i++;

	// Calculate absolute value
	while(i<Length)
	{
		if(String[i] != '.')
		{
			Value *= 10;
			Value+=(String[i]-48);
		}
		i++;
	}
	// Correct sign if '-' was present
	if(Negative == TRUE)
		Value = 0-Value;

	return Value;

}
