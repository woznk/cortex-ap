/**
*************************=== ACX-Glider Firmware ===*************************
**    Author: Alex Pabouctsidis
**    Date: 1/2011
****************************************************************************/

#include "main.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"

#include "registers.h"
#include "arm_math.h"
#include "math_helper.h"

/* PID Gains */
/* Private macro */
/* Registers */
u8 Cycle_Read_Registers[3] = {0,0,0};
u16 Cycle_Read_Frequency = 20;
u8 UI_Mode = 0;

// Configuration Registers
u16 SD_Log_Frequency = 100;
u16 Attitude_PID_Frequency = 50;
u16 Navigate_PID_Frequency = 10;
PID_Instance_f32_Sat Aileron_PID;
PID_Instance_f32_Sat Elevator_PID;
PID_Instance_f32_Sat Roll_PID;
PID_Instance_f32_Sat Pitch_PID;
Servo_Endpoint_Type Servo_Endpoints[7];
u8 Max_Bank;
s8 Max_Pitch[2];
Waypoint_Type Waypoints[MAX_WAYPOINTS];
float Cruise_Speed_Setpoint; // m/s
u32 GPS_Alt_Error = 1000; // cm
u32 Throttle_Alt_Threshold = 500; // cm
u32 Pitch_Offset=0; // milidegrees
Flight_Mode_Type Radio_Timeout_Mode = 0; //0-Neutral, 1- FBW Neutral, 2 - Return home

/* Private variables */
/******************** Radio *******************/
u16 Radio_Channels[7];
bool Radio_New_Data = FALSE;
Flight_Mode_Type Mode_Switch = Manual;
u8 Signal_Strength;
/********************* GPS ********************/
char GPS_RxBuffer[256];
char GPS_TxBuffer[256];
u8 GPS_Mode = NMEA_MODE;
GPS_Message_Type GPS_Message;
GPS_Data_Type GPS_Data;
bool GPS_Ready = FALSE;

/**************** Pressure Sensors *************/
u32 DPres_Voltage; //Sensor Voltage in mV
u32 Pres_Voltage; //Sensor Voltage in mV

/********************** AHRS *******************/
AHRS_Message_Type AHRS_Message;
char AHRS_TxBuffer[256];
char AHRS_RxBuffer[256];
AHRS_Data_Type AHRS_Data;

/***************** RUN TIME STATS **************/
char Run_Time_Stats_Buffer[512];

/****** Attitude / Navigation Controller *******/
float Pitch_Setpoint;
float Roll_Setpoint;
float Airspeed;

int AHRS_Heading_Error = 0;

Flight_Mode_Type Flight_Mode = Manual;
u8 Current_Waypoint = 0;
Flight_Mode_Type Previous_Mode = Manual;

/***************** FreeRTOS ********************/
xTaskHandle GPS_Init_Handle;
xSemaphoreHandle Navigate;


/**===========================================================================
**   							Functions
**===========================================================================*/
/*******************************************************************************
* Function Name  : Register_Write
* Description    : Write data to register from string
* Input          : Register number, String
* Output         : None
* Return         : None
*******************************************************************************/
bool Register_Write(u8 Register_Number, char* Write_String)
{
	u8 Channel_Number;
	u8 Waypoint_Number;
	bool Valid = TRUE;
	u8 Value;
	// Comments are example writes strings
	switch(Register_Number){
	case CYCLE_READ_REG:
		//$AXWRG,XX,1,0,0
		Cycle_Read_Registers[0] = Write_String[10]-48;
		Cycle_Read_Registers[1] = Write_String[12]-48;
		Cycle_Read_Registers[2] = Write_String[14]-48;
		break;
	case CYCLE_READ_FREQ_REG:
		//$AXWRG,XX,050
		Cycle_Read_Frequency = String_To_Int(&Write_String[10],3);
		break;
	case MODE_REG:
		//$AXWRG,XX,1
		UI_Mode = String_To_Int(&Write_String[10],1);
		break;
	case SD_LOG_FREQ_REG:
		//$AXWRG,XX,100
		SD_Log_Frequency = String_To_Int(&Write_String[10],3);
		break;
	case ATTITUDE_PID_FREQ_REG:
		//$AXWRG,XX,050
		Attitude_PID_Frequency = String_To_Int(&Write_String[10],3);
		break;
	case AILERON_PID_REG:
		//$AXWRG,XX,05020,00720,00000 //50.2, 7.2, 0
		Aileron_PID.Kp = (float)String_To_Int(&Write_String[10],5)/100;
		Aileron_PID.Ki = (float)String_To_Int(&Write_String[16],5)/100;
		Aileron_PID.Kd = (float)String_To_Int(&Write_String[22],5)/100;
		break;
	case ELEVATOR_PID_REG:
		//$AXWRG,XX,01500,00350,00632 // 15, 3.5, 6.32
		Elevator_PID.Kp = (float)String_To_Int(&Write_String[10],5)/100;
		Elevator_PID.Ki = (float)String_To_Int(&Write_String[16],5)/100;
		Elevator_PID.Kd = (float)String_To_Int(&Write_String[22],5)/100;
		break;
	case NAVIGATION_PID_FREQ_REG:
		//$AXWRG,XX,010
		Navigate_PID_Frequency = String_To_Int(&Write_String[10],3);
		break;
	case ROLL_PID_REG:
		Roll_PID.Kp = (float)String_To_Int(&Write_String[10],5)/100;
		Roll_PID.Ki = (float)String_To_Int(&Write_String[16],5)/100;
		Roll_PID.Kd = (float)String_To_Int(&Write_String[22],5)/100;
		break;
	case PITCH_PID_REG:
		Pitch_PID.Kp = (float)String_To_Int(&Write_String[10],5)/100;
		Pitch_PID.Ki = (float)String_To_Int(&Write_String[16],5)/100;
		Pitch_PID.Kd = (float)String_To_Int(&Write_String[22],5)/100;
		break;
	case SERVO_EP_REG:
		//$AXWRG,XX,Y,-500,+500
		Channel_Number = (u8)String_To_Int(&Write_String[10],1);
		Servo_Endpoints[Channel_Number].Min = String_To_Int(&Write_String[12],4);
		Servo_Endpoints[Channel_Number].Max= String_To_Int(&Write_String[17],4);
		break;
	case MAX_BANK_REG:
		//$AXWRG,XX,45
		Max_Bank = (u8)String_To_Int(&Write_String[10],2);
		break;
	case MAX_PITCH_REG:
		//$AXWRG,XX,-10,+30
		Max_Pitch[0] = (u8)String_To_Int(&Write_String[10],3);
		Max_Pitch[1] = (u8)String_To_Int(&Write_String[14],3);
		break;
	case WAYPOINTS_REG:
		//$AXWRG,XX,YY,42041732,06378920,50252,1000,02
		Waypoint_Number =(u8)String_To_Int(&Write_String[10],2);
		Waypoints[Waypoint_Number].Latitude = String_To_Int(&Write_String[13],8);
		Waypoints[Waypoint_Number].Longitude = String_To_Int(&Write_String[22],8);
		Waypoints[Waypoint_Number].Altitude = String_To_Int(&Write_String[31],5);
		Waypoints[Waypoint_Number].Radius = String_To_Int(&Write_String[37],4);
		Waypoints[Waypoint_Number].Next = String_To_Int(&Write_String[42],2);
		break;
	case CRUISE_SPEED_REG:
		//AXWRG,XX,1650
		Cruise_Speed_Setpoint = (float)String_To_Int(&Write_String[10],4)/100;
		break;
	case GPS_ALT_ERROR_REG:
		//AXWRG,XX,0500
		GPS_Alt_Error = String_To_Int(&Write_String[10],4);
		break;
	case THROTTLE_ALT_THRESH_REG:
		//AXWRG,XX,0750
		Throttle_Alt_Threshold = String_To_Int(&Write_String[10],4);
		break;
	case PITCH_OFFSET_REG:
		//AXWRG,XX,+03500
		Pitch_Offset = String_To_Int(&Write_String[10],6);
		break;
	case RADIO_TIMEOUT_REG:
		//AXWRG,XX,1
		Value = String_To_Int(&Write_String[10],1);
		switch(Value)
		{
		case 0:
			Radio_Timeout_Mode = Manual;
			break;
		case 1:
			Radio_Timeout_Mode = FBW;
			break;
		case 2:
			Radio_Timeout_Mode = Auto_B;
			break;
		}
		break;
	default:
		// Invalid Registers Number
		USB_Send_String("$AXERR,1*41\n");
		Valid = FALSE;
		break;
	}
	return(Valid);
}
/*******************************************************************************
* Function Name  : Register_Read
* Description    : Create string from register data to send via USB
* Input          : Register number, String
* Output         : None
* Return         : None
*******************************************************************************/
void Register_Read(u8 Register_Number,u8 Sub_Register, char* Final_String)
{
	char Work_String[64];
	u16 String_Position;
	u8 Checksum;

	// Header
	String_Position = String_Append(Final_String,"$AXRRG,",0);
	Int_To_Dec_String(Register_Number,Work_String,2,FALSE);
	String_Position = String_Append(Final_String,Work_String,String_Position);
	String_Position = String_Append(Final_String,",",String_Position);
	// Data fields
	switch(Register_Number){
	case YPR_DATA_REG:
		// YPR Data Register
		//Yaw
		Int_To_Dec_String(AHRS_Data.Yaw,Work_String,6,TRUE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		String_Position = String_Append(Final_String,",",String_Position);
		//Pitch
		Int_To_Dec_String(AHRS_Data.Pitch,Work_String,6,TRUE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		String_Position = String_Append(Final_String,",",String_Position);
		//Roll
		Int_To_Dec_String(AHRS_Data.Roll,Work_String,6,TRUE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		break;
	case GPS_DATA_REG:
		// GPS Data Register
		//Latitude
		Int_To_Dec_String(GPS_Data.Position.Latitude,Work_String,9,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		String_Position = String_Append(Final_String,",",String_Position);
		//Longitude
		Int_To_Dec_String(GPS_Data.Position.Longitude,Work_String,9,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		String_Position = String_Append(Final_String,",",String_Position);
		//Altitude
		Int_To_Dec_String(GPS_Data.Altitude,Work_String,5,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		String_Position = String_Append(Final_String,",",String_Position);
		//Ground Speed
		Int_To_Dec_String(GPS_Data.Ground_Speed,Work_String,4,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		String_Position = String_Append(Final_String,",",String_Position);
		//Number of Satellites
		Int_To_Dec_String(GPS_Data.Sattelites_Used,Work_String,1,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		String_Position = String_Append(Final_String,",",String_Position);
		// GPS Fix
		Int_To_Dec_String(GPS_Data.Fix_Type,Work_String,1,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		break;
	case PRESSURE_DATA_REG:
		// Pressure Data
		//Differential Pressure
		Int_To_Dec_String(DPres_Voltage,Work_String,4,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		String_Position = String_Append(Final_String,",",String_Position);
		//Absolute Pressure
		Int_To_Dec_String(Pres_Voltage,Work_String,4,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		break;
	case CYCLE_READ_REG:
		// Cycle reads
		// 1
		Int_To_Dec_String(Cycle_Read_Registers[0],Work_String,4,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		String_Position = String_Append(Final_String,",",String_Position);
		// 2
		Int_To_Dec_String(Cycle_Read_Registers[1],Work_String,4,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		String_Position = String_Append(Final_String,",",String_Position);
		// 3
		Int_To_Dec_String(Cycle_Read_Registers[2],Work_String,4,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		break;
	case CYCLE_READ_FREQ_REG:
		// Cycle read frequency
		// Frequency
		Int_To_Dec_String(Cycle_Read_Frequency,Work_String,3,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		break;
	case MODE_REG:
		// Mode
		Int_To_Dec_String(UI_Mode,Work_String,1,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		break;
	case SD_LOG_FREQ_REG:
		// SD Card Log Frequency
		// Frequency
		Int_To_Dec_String(SD_Log_Frequency,Work_String,3,FALSE);

		String_Position = String_Append(Final_String,Work_String,String_Position);
		break;
	case SERVO_POSITIONS_REG:
		break;
	case ATTITUDE_PID_FREQ_REG:
		Int_To_Dec_String(Attitude_PID_Frequency,Work_String,3,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		break;
	case AILERON_PID_REG:
		//Kp*100
		Int_To_Dec_String((int)(Aileron_PID.Kp*100),Work_String,5,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		String_Position = String_Append(Final_String,",",String_Position);
		//Ki*100
		Int_To_Dec_String((int)(Aileron_PID.Ki*100),Work_String,5,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		String_Position = String_Append(Final_String,",",String_Position);
		//Kd*100
		Int_To_Dec_String((int)(Aileron_PID.Kd*100),Work_String,5,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		break;
	case ELEVATOR_PID_REG:
		//Kp*100
		Int_To_Dec_String((int)(Elevator_PID.Kp*100),Work_String,5,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		String_Position = String_Append(Final_String,",",String_Position);
		//Ki*100
		Int_To_Dec_String((int)(Elevator_PID.Ki*100),Work_String,5,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		String_Position = String_Append(Final_String,",",String_Position);
		//Kd*100
		Int_To_Dec_String((int)(Elevator_PID.Kd*100),Work_String,5,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		break;
	case NAVIGATION_PID_FREQ_REG:
		break;
		Int_To_Dec_String(Navigate_PID_Frequency,Work_String,3,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		String_Position = String_Append(Final_String,Work_String,String_Position);
	case ROLL_PID_REG:
		//Kp*100
		Int_To_Dec_String((int)(Roll_PID.Kp*100),Work_String,5,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		String_Position = String_Append(Final_String,",",String_Position);
		//Ki*100
		Int_To_Dec_String((int)(Roll_PID.Ki*100),Work_String,5,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		String_Position = String_Append(Final_String,",",String_Position);
		//Kd*100
		Int_To_Dec_String((int)(Roll_PID.Kd*100),Work_String,5,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		String_Position = String_Append(Final_String,",",String_Position);
		break;
	case PITCH_PID_REG:
		//Kp*100
		Int_To_Dec_String((int)(Pitch_PID.Kp*100),Work_String,5,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		String_Position = String_Append(Final_String,",",String_Position);
		//Ki*100
		Int_To_Dec_String((int)(Pitch_PID.Ki*100),Work_String,5,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		String_Position = String_Append(Final_String,",",String_Position);
		//Kd*100
		Int_To_Dec_String((int)(Pitch_PID.Kd*100),Work_String,5,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		String_Position = String_Append(Final_String,",",String_Position);
		break;
	case SERVO_EP_REG:
		// Add sub register
		Int_To_Dec_String(Sub_Register,Work_String,1,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		String_Position = String_Append(Final_String,",",String_Position);
		// min
		Int_To_Dec_String(Servo_Endpoints[Sub_Register].Min,Work_String,3,TRUE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		String_Position = String_Append(Final_String,",",String_Position);
		//max
		Int_To_Dec_String(Servo_Endpoints[Sub_Register].Max,Work_String,3,TRUE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		break;
	case MAX_BANK_REG:
		// Bank
		Int_To_Dec_String(Max_Bank,Work_String,2,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		break;
	case MAX_PITCH_REG:
		// min pitch
		Int_To_Dec_String(Max_Pitch[0],Work_String,2,TRUE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		String_Position = String_Append(Final_String,",",String_Position);
		// max pitch
		Int_To_Dec_String(Max_Pitch[1],Work_String,2,TRUE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		break;
	case WAYPOINTS_REG:
		// Add sub register
		Int_To_Dec_String(Sub_Register,Work_String,2,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		String_Position = String_Append(Final_String,",",String_Position);
		// Latitude
		Int_To_Dec_String(Waypoints[Sub_Register].Latitude,Work_String,8,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		String_Position = String_Append(Final_String,",",String_Position);
		// Longitude
		Int_To_Dec_String(Waypoints[Sub_Register].Longitude,Work_String,8,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		String_Position = String_Append(Final_String,",",String_Position);
		// Altitude
		Int_To_Dec_String(Waypoints[Sub_Register].Altitude,Work_String,5,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		String_Position = String_Append(Final_String,",",String_Position);
		// Radius
		Int_To_Dec_String(Waypoints[Sub_Register].Radius,Work_String,4,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		String_Position = String_Append(Final_String,",",String_Position);
		// Next
		Int_To_Dec_String(Waypoints[Sub_Register].Next,Work_String,2,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		break;
	case CRUISE_SPEED_REG:
		//Speed
		Int_To_Dec_String((int)(Cruise_Speed_Setpoint*100),Work_String,4,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		break;
	case GPS_ALT_ERROR_REG:
		// Altitude error
		Int_To_Dec_String(GPS_Alt_Error,Work_String,4,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		break;
	case THROTTLE_ALT_THRESH_REG:
		// Throttle threshold
		Int_To_Dec_String(Throttle_Alt_Threshold,Work_String,5,FALSE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		break;
	case PITCH_OFFSET_REG:
		// pitch offset in millidegrees
		Int_To_Dec_String(Pitch_Offset,Work_String,5,TRUE);
		String_Position = String_Append(Final_String,Work_String,String_Position);
		break;
	case RADIO_TIMEOUT_REG:
		//AXWRG,XX,1
		switch(Radio_Timeout_Mode)
		{
		case Manual:
			String_Position = String_Append(Final_String,"0",String_Position);
			break;
		case FBW:
			String_Position = String_Append(Final_String,"1",String_Position);
			break;
		case Auto_B:
			String_Position = String_Append(Final_String,"2",String_Position);
			break;
		default:
			break;
		}
		break;
	default:
		// Send Error 1
		String_Append(Final_String,"$AXERR,1*41\n",0);
	}
	// Checksum
	Checksum = Checksum_Calculate(&Final_String[1]);
	String_Position = String_Append(Final_String,"*",String_Position);
	Int_To_Hex_String(Checksum,Work_String);
	String_Position = String_Append(Final_String,Work_String,String_Position);

	// Finish string off with '\n', '\0'
	Final_String[String_Position]='\n';
	Final_String[String_Position+1]='\0';
}
/*******************************************************************************
* Function Name  : EE_Load
* Description    : Load data from EEPROM
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void EE_Load()
{
	u16 i;

	// Block 0: GPS Waypoints
	I2C_EE_Set_Block(0);

	// Store GPS Waypoints
	for(i=0;i<16;i++)
		I2C_EE_BufferRead((u8*)&Waypoints[i],i*16,15);

	// Block 0: GPS Waypoints
	I2C_EE_Set_Block(1);

	// Store GPS Waypoints
	for(i=16;i<MAX_WAYPOINTS;i++)
		I2C_EE_BufferRead((u8*)&Waypoints[i],i*16,15);

	// Block 1: PID Instances / Servo Endpoints / Min+Max Bank+Pitch
	I2C_EE_Set_Block(2);

	// Store PID Instance (only gains and endpoints)
	I2C_EE_BufferRead((u8*)&Aileron_PID.Endpoint[0],0,20);
	I2C_EE_BufferRead((u8*)&Elevator_PID.Endpoint[0],20,20);
	I2C_EE_BufferRead((u8*)&Roll_PID.Endpoint[0],40,20);
	I2C_EE_BufferRead((u8*)&Pitch_PID.Endpoint[0],60,20);

	// Store Servo Endpoints
	I2C_EE_BufferRead((u8*)Servo_Endpoints,80,28);

	// Min/Max Bank and Pitch
	I2C_EE_BufferRead((u8*)&Max_Bank,108,1);
	I2C_EE_BufferRead((u8*)&Max_Pitch,109,2);

	I2C_EE_Set_Block(3);
	// cruise speed
	I2C_EE_BufferRead((u8*)&Cruise_Speed_Setpoint,0,4);
	// gps altitude error
	I2C_EE_BufferRead((u8*)&GPS_Alt_Error,4,4);
	// throttle altitude threshold
	I2C_EE_BufferRead((u8*)&Throttle_Alt_Threshold,8,4);
	// pitch offset
	I2C_EE_BufferRead((u8*)&Pitch_Offset,12,4);
	// radio timeout
	I2C_EE_BufferRead((u8*)&Radio_Timeout_Mode,16,1);
}

/*******************************************************************************
* Function Name  : EE_Store
* Description    : Store register data to EEPROM
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void EE_Store()
{
	u16 i;

	// Block 0: GPS Waypoints (0-15)
	I2C_EE_Set_Block(0);

	// Store GPS Waypoints
	for(i=0;i<16;i++)
		I2C_EE_BufferWrite((u8*)&Waypoints[i],i*16,15);

	// Block 1: GPS Waypoints (16-32)
	I2C_EE_Set_Block(1);
	for(i=16;i<MAX_WAYPOINTS;i++)
		I2C_EE_BufferWrite((u8*)&Waypoints[i],i*16,15);

	// Block 1: PID Instances
	I2C_EE_Set_Block(2);

	// Store PID Instance (only gains and endpoints)
	I2C_EE_BufferWrite((u8*)&Aileron_PID.Endpoint[0],0,20);
	I2C_EE_BufferWrite((u8*)&Elevator_PID.Endpoint[0],20,20);
	I2C_EE_BufferWrite((u8*)&Roll_PID.Endpoint[0],40,20);
	I2C_EE_BufferWrite((u8*)&Pitch_PID.Endpoint[0],60,20);

	// Store Servo Endpoints
	I2C_EE_BufferWrite((u8*)Servo_Endpoints,80,28);

	// Min/Max Bank and Pitch
	I2C_EE_BufferWrite((u8*)&Max_Bank,108,1);
	I2C_EE_BufferWrite((u8*)&Max_Pitch,109,2);

	I2C_EE_Set_Block(3);
	// cruise speed
	I2C_EE_BufferWrite((u8*)&Cruise_Speed_Setpoint,0,4);
	// gps altitude error
	I2C_EE_BufferWrite((u8*)&GPS_Alt_Error,4,4);
	// throttle altitude threshold
	I2C_EE_BufferWrite((u8*)&Throttle_Alt_Threshold,8,4);
	// pitch offset
	I2C_EE_BufferWrite((u8*)&Pitch_Offset,12,4);
	// radio timeout
	I2C_EE_BufferWrite((u8*)&Radio_Timeout_Mode,16,1);
}
/**===========================================================================
**  							Tasks
**===========================================================================*/
/*******************************************************************************
* Task Name		 : Read_Parse_Buffers_Task
* Description    : Read GPS and AHRS buffers, and if new message -> parse
*******************************************************************************/
void Read_Parse_Buffers_Task(void *pvParameters)
{
	portTickType Last_Wake_Time;
	Last_Wake_Time = xTaskGetTickCount();

	// gps period (debug)
	//u32 Past_Time = 0;
	//u32 Current_Time = 0;
	//u32 deltaT = 0;

	// Read buffers
	while(1)
	{
		GPS_Read_Buffer(GPS_RxBuffer,&GPS_Message);
		AHRS_Read_Buffer(AHRS_RxBuffer,&AHRS_Message);
		//If new complete messages, parse data
		if(GPS_Message.New_Message == TRUE)
		{
			// Determine time between new messages (debug)
			/*Current_Time = xTaskGetTickCount();
			deltaT = Current_Time - Past_Time;
			Past_Time = Current_Time;*/

			// Read and parse
			GPS_Message_Parse(&GPS_Message,&GPS_Data);
			GPS_Message.New_Message = FALSE;

			// Option 1: Unblock Navigate task if in auto mode
			if(Mode_Switch == Auto_A || Mode_Switch == Auto_B)
				xSemaphoreGive(Navigate);
			// Option 2: Correct AHRS Heading error
			AHRS_Heading_Error = (AHRS_Data.Yaw+180000)-GPS_Data.Heading;
		}
		if (AHRS_Message.New_Message == TRUE)
		{
			// If sensor explorer mode, forward all AHRS message to USB
			if(UI_Mode == 1)
				USB_Send_String(AHRS_Message.Message);
			AHRS_Message_Parse(&AHRS_Message,&AHRS_Data);
			// swap / invert axes according to AXCG orientation in airplane
			// Configuration for Pressure sensor (pitot tube) facing backwards
			AHRS_Data.Pitch = 0-AHRS_Data.Pitch;
			AHRS_Data.Roll = 0-AHRS_Data.Roll;
			// add pitch offset to pith
			AHRS_Data.Pitch += Pitch_Offset;
			// mark as read
			AHRS_Message.New_Message = FALSE;
		}
		vTaskDelayUntil(&Last_Wake_Time,(2.5/portTICK_RATE_MS));
	}
}
/*******************************************************************************
* Task Name		 : Record_Data_Task
* Description    : Record data to SD card at a fixed frequency
*******************************************************************************/
void Record_Data_Task(void *pvParameters)
{
	portTickType Last_Wake_Time;
	Last_Wake_Time = xTaskGetTickCount();
	bool Recording = FALSE;
	u8 Blink_Counter = 0;
	RTC_t Time;
	u8 Fsync_Counter = 0;

	//Start recording on reset!
	//Create new File
	SD_Create_New_File();
	Recording = TRUE;

	while(1)
	{
		if(Button2_Rising_Edge()==TRUE)
		{
			if(Recording == TRUE)
			{
				//Close File, etc
				SD_Close_File();
				Recording = FALSE;
				Led_Reset(3);
			}
			else
			{
				// If GPS fix, set RTC time
				if(GPS_Data.Fix_Type == 3)
				{
					Time.year = GPS_Data.Date.Year;
					Time.month = GPS_Data.Date.Month;
					Time.mday = GPS_Data.Date.Day;
					Time.hour = GPS_Data.UTC_Time.Hours;
					Time.min = GPS_Data.UTC_Time.Minutes;
					Time.sec = GPS_Data.UTC_Time.Seconds;
					rtc_settime(&Time);
				}
				//Create new File
				SD_Create_New_File();
				Recording = TRUE;
			}
		}
		// Blink led & record
		if(Recording == TRUE)
		{
			if(Blink_Counter++ == 50)
			{
				Led_Toggle(3);
				Blink_Counter=0;
			}
			// write data line to sd card
			SD_Record_Data(&AHRS_Data,&GPS_Data,Radio_Channels,(u32)DPres_Voltage,(u32)Pres_Voltage,
					Roll_Setpoint,Pitch_Setpoint,(u8)Mode_Switch,Current_Waypoint,Servo_Get_Position(THROTTLE_CHANNEL),
					Servo_Get_Position(AILERON_CHANNEL),Servo_Get_Position(ELEVATOR_CHANNEL));
			// Flush cached information -> if reset without closing, file is still valid
			// Called every second
			if(Fsync_Counter++ == 100)
			{
				SD_Sync();
				Fsync_Counter = 0;
			}
		}
		vTaskDelayUntil(&Last_Wake_Time,(1000/SD_Log_Frequency)/portTICK_RATE_MS);
	}
}
/*******************************************************************************
* Task Name		 : Flight_Mode_Task
* Description    : Select flight mode with push button and set/reset/toggle
* 				   LEDs to the corresponding mode
*******************************************************************************/
void Flight_Mode_Task(void *pvParameters)
{
	portTickType Last_Wake_Time;
	Last_Wake_Time = xTaskGetTickCount();

	u8 Clock_Divide = 0;

	while(1)
	{
		// If button press switch flight mode (Manual -> FBW -> Auto)
		if(Button1_Rising_Edge()==TRUE)
		{
			switch(Flight_Mode){
			case Manual:
				Flight_Mode= FBW;
				Led_Set(2);
				Led_Set(1);
				break;
			case FBW:
				Flight_Mode= Auto_A;
				Led_Set(2);
				Led_Reset(1);
				break;
			case Auto_A:
				Flight_Mode= Auto_B;
				Led_Set(2);
				Led_Set(1);
				break;
			case Auto_B:
				Flight_Mode = Manual;
				Led_Reset(2);
				Led_Reset(1);
				break;
			};
			// run time stats (DEBUG!)
			vTaskGetRunTimeStats((void *)Run_Time_Stats_Buffer);
			USB_Send_String(Run_Time_Stats_Buffer);
		}
		//Toggle leds depending on mode
		if(Flight_Mode == FBW)
		{
			if (Clock_Divide++ == 10)
			{
				Led_Toggle(2);
				Led_Toggle(1);
				Clock_Divide =0;
			}
		}
		vTaskDelayUntil(&Last_Wake_Time,(50/portTICK_RATE_MS));

	}
}
/*******************************************************************************
* Task Name		 : Pressure_Data_Task
* Description    : Read and filter data from pressure sensors ADC
*******************************************************************************/
void Pressure_Data_Task(void *pvParameters)
{
	portTickType Last_Wake_Time;
	Last_Wake_Time = xTaskGetTickCount();

	Pressure_Filter_Initialize();
	while(1)
	{
		Pressure_Get_Data(&DPres_Voltage,&Pres_Voltage);
		// Done, start again in 10ms
		vTaskDelayUntil(&Last_Wake_Time,(10/portTICK_RATE_MS));
	}
}
/*******************************************************************************
* Task Name		 : Send_Stats_Task
* Description    : if button pushed - generate runtime stats and send to USB
*******************************************************************************/
void Send_Stats_Task(void *pvParameters)
{
	portTickType Last_Wake_Time;
	Last_Wake_Time = xTaskGetTickCount();
	while(1)
	{
		// If rising edge-> send stats to usb
		if(Button1_Rising_Edge()==TRUE)
		{
			vTaskGetRunTimeStats((void *)Run_Time_Stats_Buffer);
			USB_Send_String(Run_Time_Stats_Buffer);
		}
		vTaskDelayUntil(&Last_Wake_Time,(100/portTICK_RATE_MS));
	}
}
/*******************************************************************************
* Task Name		 : Send_Stats_Task
* Description    : Read data registers cyclically at a fixed frequency
*******************************************************************************/
void Cycle_Register_Read_Task(void *pvParameters)
{
	portTickType Last_Wake_Time;
	Last_Wake_Time = xTaskGetTickCount();
	static char String[256];

	//clear string
	String[0] = 0;
	while(1)
	{
		if(Cycle_Read_Registers[0] == 1)
		{
			Register_Read(YPR_DATA_REG,0,String);
			USB_Send_String(String);
			String[0] = 0;
		}

		if(Cycle_Read_Registers[1] == 1)
		{
			Register_Read(GPS_DATA_REG,0,String);
			USB_Send_String(String);
			String[0] = 0;
		}

		if(Cycle_Read_Registers[2] == 1)
		{
			Register_Read(PRESSURE_DATA_REG,0,String);
			USB_Send_String(String);
			String[0] = 0;
		}
		vTaskDelayUntil(&Last_Wake_Time,(1000/Cycle_Read_Frequency)/portTICK_RATE_MS);
	}
}
/*******************************************************************************
* Task Name		 : Mission_Control_Task
* Description    : Decode messages from USB and write/read to the
* 				   corresponding registers
*******************************************************************************/
void Mission_Control_Task(void *pvParameters)
{
	portTickType Last_Wake_Time;
	Last_Wake_Time = xTaskGetTickCount();
	xTaskHandle Cycle_Read;
	bool Cycle_Read_Active = FALSE;

	USB_String USB_In_String;
	u8 Register_Number;
	u8 Sub_Register = 0;
	char Final_String[256];

	// Clear final string
	Final_String[0]=0;
	while(1)
	{
		USB_Read_Buffer(&USB_In_String);
		if(USB_In_String.New_String == TRUE)
		{
			//Parse String
			if((USB_In_String.String[1] == 'A') && (USB_In_String.String[2] == 'X'))
			{
				// AXRRG - Register Read
				if((USB_In_String.String[3] == 'R') && (USB_In_String.String[4] == 'R')&& (USB_In_String.String[5] == 'G'))
				{
					//Register Read
					Register_Number = String_To_Int(&USB_In_String.String[7],2);
					// if Servo end points read sub register
					if((Register_Number == SERVO_EP_REG))
						Sub_Register = String_To_Int(&USB_In_String.String[10],1);
					else if (Register_Number == WAYPOINTS_REG)
						Sub_Register = String_To_Int(&USB_In_String.String[10],2);
					Register_Read(Register_Number,Sub_Register, Final_String);
					//Send finished string
					USB_Send_String(Final_String);
				}
				// AXWRG - Register Write
				else if((USB_In_String.String[3] == 'W') && (USB_In_String.String[4] == 'R')&& (USB_In_String.String[5] == 'G'))
				{
					//Register Write
					Register_Number = String_To_Int(&USB_In_String.String[7],2);
					if(Register_Write(Register_Number,&USB_In_String.String[0])== TRUE);
						USB_Send_String("$AXWRG*5B\n");

						// cycle read task manager
					switch(Register_Number){

					case CYCLE_READ_REG:
						// if any '1', create cycle read tasks, else delete
						if(Cycle_Read_Registers[0] | Cycle_Read_Registers[1] | Cycle_Read_Registers[2])
						{
							// If no task, create it
							if(Cycle_Read_Active == FALSE)
							{
								xTaskCreate(Cycle_Register_Read_Task,( signed portCHAR * ) "Cycle Register Read",256,NULL,2,&Cycle_Read);
								Cycle_Read_Active = TRUE;
							}
						}
						else if (Cycle_Read_Active == TRUE)
						{
							//Delete task
							vTaskDelete(Cycle_Read);
							Cycle_Read_Active = FALSE;
						}
						break;
					case MODE_REG:
						//if Mode = 1 -> Sensor Explorer Mode, stop cycle reads
						if(UI_Mode == 1)
						{
							Cycle_Read_Registers[0] = 0;
							Cycle_Read_Registers[1] = 0;
							Cycle_Read_Registers[2] = 0;
							//Delete cycle read task
							if (Cycle_Read_Active == TRUE)
							{
								vTaskDelete(Cycle_Read);
								Cycle_Read_Active = FALSE;
							}
						}
						break;
					default:
						break;
					}
					USB_Send_String(Final_String);
				}
				// AXSEE - Store EEPROM
				else if ((USB_In_String.String[3] == 'S') && (USB_In_String.String[4] == 'E')&& (USB_In_String.String[5] == 'E'))
				{
					EE_Store();
					USB_Send_String("$AXSEE*4A\n");
				}
			}
			// Message is destined for VN-100 -> send string to VN-100
			else if ((USB_In_String.String[1] == 'V') && (USB_In_String.String[2] == 'N'))
			{
				if(UI_Mode == 1)
					AHRS_Send_Message(USB_In_String.String);
			}
			else
			{
				// Cannot recognize string
				USB_Send_String("$AXERR,3*43\n");
			}
			// Done with USB string
			USB_In_String.New_String = FALSE;
			// Clear Final String
			Final_String[0] = 0;
		}
		vTaskDelayUntil(&Last_Wake_Time,(10/portTICK_RATE_MS));
	}
}
/*******************************************************************************
* Task Name		 : GPS_Initialize_Task
* Description    : Send GPS configuration strings (Binary, SBAS, 10Hz) with a
* 				   delay between each string. When done task auto deletes itself
*******************************************************************************/
void GPS_Initialize_Task(void *pvParameters)
{
	portTickType Last_Wake_Time;
	Last_Wake_Time = xTaskGetTickCount();

	// Send Gibberish to GPS
	GPS_Send_Message("$ABC123XYZ\r\n");

	// Delay 4s
	vTaskDelayUntil(&Last_Wake_Time,4000/portTICK_RATE_MS);

	//delay 0.5s
	vTaskDelayUntil(&Last_Wake_Time,500/portTICK_RATE_MS);
	// Send binary string
	GPS_Send_Message("$PGCMD,16,0,0,0,0,0*6A\r\n");
	// Binary GPS mode
	GPS_Mode = BINARY_MODE;

	//delay 0.5s
	vTaskDelayUntil(&Last_Wake_Time,500/portTICK_RATE_MS);
	//set update rate to 10hz
	GPS_Send_Message("$PMTK220,100*2F");

	//delay 0.5s
	vTaskDelayUntil(&Last_Wake_Time,500/portTICK_RATE_MS);
	// SBAS on
	GPS_Send_Message("$PMTK313,1*2E\r\n");

	GPS_Ready = TRUE;
	// delete task
	vTaskDelete(GPS_Init_Handle);

}
/*******************************************************************************
* Task Name		 : Radio_Timeout_Task
* Description    : Checks for new data from RC radio. if no new data, go to radio
* 				   Timeout mode: servos neutral, FBW neutral, or return home
*******************************************************************************/
void Radio_Timeout_Task(void *pvParameters)
{
	portTickType Last_Wake_Time;
	Last_Wake_Time = xTaskGetTickCount();

	while(1)
	{
		// if no new data
		if(Radio_New_Data == FALSE)
		{
			//if in manual mode -> set servos to neutral
			switch(Radio_Timeout_Mode)
			{
			case Manual:
				// Switch to manual mode and set all servos neutral and cut throttle
				Mode_Switch = Manual;
				Servo_Set_Position(AILERON_CHANNEL,0);
				Servo_Set_Position(FLAP_CHANNEL,0);
				Servo_Set_Position(GEAR_CHANNEL,0);
				Servo_Set_Position(ELEVATOR_CHANNEL,0);
				Servo_Set_Position(AUX2_CHANNEL,0);
				Servo_Set_Position(THROTTLE_CHANNEL,-500);
				Servo_Set_Position(RUDDER_CHANNEL,0);
				break;
			case FBW:
				// switch to FBW mode and change setpoints and cut throttle
				Mode_Switch = FBW;
				Servo_Set_Position(THROTTLE_CHANNEL,-500);
				Roll_Setpoint = 0;
				Pitch_Setpoint = -2;
				break;
			case Auto_A:
				// Switch to auto mode and change waypoint number
				Mode_Switch = Auto_A;
				Current_Waypoint = 0;
			case Auto_B:
				// Switch to auto mode and change waypoint number
				Mode_Switch = Auto_B;
				Current_Waypoint = 0;
			}
		}
		// Current has been accounted for -> set to false
		Radio_New_Data = FALSE;
		// Delay for 0.1s
		vTaskDelayUntil(&Last_Wake_Time,100/portTICK_RATE_MS);
	}
}
/*******************************************************************************
* Task Name		 : Attitude_Controller_Task
* Description    : Attitude control loop. Controls the Rol and pitch of the aircraft
*******************************************************************************/
void Attitude_Controller_Task(void *pvParameters)
{
	portTickType Last_Wake_Time;
	Last_Wake_Time = xTaskGetTickCount();

	int Aileron_Servo = 0;
	int Elevator_Servo = 0;

	// PID Gains
	//Aileron_PID.Kp = 9.2;
	//Aileron_PID.Ki = 2;
	//Aileron_PID.Kd = 0;
	Aileron_PID.Endpoint[0] = (float)Servo_Endpoints[AILERON_CHANNEL].Min/5;
	Aileron_PID.Endpoint[1] = (float)Servo_Endpoints[AILERON_CHANNEL].Max/5;

	//Elevator_PID.Kp = 7;
	//Elevator_PID.Ki = 2;
	//Elevator_PID.Kd = 0;
	Elevator_PID.Endpoint[0] = (float)Servo_Endpoints[ELEVATOR_CHANNEL].Min/5;
	Elevator_PID.Endpoint[1] = (float)Servo_Endpoints[ELEVATOR_CHANNEL].Max/5;

	// Initialize PID
	PID_Init_f32(&Aileron_PID,1);
	PID_Init_f32(&Elevator_PID,1);

	while(1)
	{
		if ((Mode_Switch == FBW) || (Mode_Switch == Auto_A) || (Mode_Switch == Auto_B))
		{
			// reinitialize states
			if (Previous_Mode == Manual)
			{
				// Initialize PID
				PID_Init_f32(&Aileron_PID,1);
				PID_Init_f32(&Elevator_PID,1);
			}
			// Aileron
			Aileron_Servo = (int)(PID_f32(&Aileron_PID,Roll_Setpoint-(float)AHRS_Data.Roll/1000))*5; // 100 * 5 = 500 (+- 100% too +- 500us)
			Servo_Set_Position(AILERON_CHANNEL,Aileron_Servo);
			Servo_Set_Position(GEAR_CHANNEL,Aileron_Servo);
			// Elevator
			Elevator_Servo = (int)( PID_f32(&Elevator_PID,Pitch_Setpoint-(float)AHRS_Data.Pitch/1000) / arm_cos_f32((float)D2R(AHRS_Data.Roll/1000)) )*5;
			Servo_Set_Position(ELEVATOR_CHANNEL,Elevator_Servo);
		}
		Previous_Mode = Mode_Switch;
		// Delay for 1/PID_Frequency
		vTaskDelayUntil(&Last_Wake_Time,(1000/Attitude_PID_Frequency)/portTICK_RATE_MS);
	}
}
/*******************************************************************************
* Task Name		 : Navigate_Task
* Description    : Calculates roll setpoint and throttle in order to navigate
* 				   The programmed waypoints.
*******************************************************************************/
void Navigate_Task(void *pvParameters)
{
	portTickType Last_Wake_Time;
	Last_Wake_Time = xTaskGetTickCount();

	float Bearing_Error; // in millidegrees
	Location_Type Current_Location;

	int Altitude;
	int Altitude_Set;

	// PID Gains
	//Roll_PID.Kp = 1;
	//Roll_PID.Ki = 0;
	//Roll_PID.Kd = 0;
	Roll_PID.Endpoint[0] = -(float)Max_Bank;
	Roll_PID.Endpoint[1] = (float)Max_Bank;
	//Pitch_PID.Kp = 1;
	//Pitch_PID.Ki = 0;
	//Pitch_PID.Kd = 0;

	// Initialize PID
	PID_Init_f32(&Roll_PID,1);



	while(1)
	{
		// Unlock on GPS New data
		xSemaphoreTake(Navigate,portMAX_DELAY);
		// if in Automatic mode -> Control roll and pitch setpoints
		if((Mode_Switch == Auto_A) || (Mode_Switch == Auto_B))
		{
			Current_Location.Altitude = GPS_Data.Altitude;
			Current_Location.Latitude =   GPS_Data.Position.Latitude;
			Current_Location.Longitude =   GPS_Data.Position.Longitude;
			// If within waypoint radius go to next waypoint - in
			if(Get_Distance_2D(&Current_Location,&Waypoints[Current_Waypoint]) <= (float)(Waypoints[Current_Waypoint].Radius)/100)
				Current_Waypoint = Waypoints[Current_Waypoint].Next;

			//Calculate AHRS Heading
			//AHRS_Heading = (AHRS_Data.Yaw+180000)-AHRS_Error; // With GPS Correction
			//AHRS_Heading = (AHRS_Data.Yaw+180000);			 //Without GPS Correction

			// Get bearing error - in degrees floating point
			// Use AHRS Heading
			//Bearing_Error = Get_Bearing_Error(Get_Bearing(&Current_Location,&Waypoints[Current_Waypoint]),(float)AHRS_Heading/1000);
			Bearing_Error = Get_Bearing_Error(Get_Bearing(&Current_Location,&Waypoints[Current_Waypoint]),(float)GPS_Data.Heading/1000);

			// USe GPS HEading
			//Calculate Roll setpoint based on heading,
			Roll_Setpoint = PID_f32(&Roll_PID,Bearing_Error);

			// Add throttle if close to altitude of next waypoint (within Throttle_Alt_Threshold) - in CM fixed point
			Altitude = Current_Location.Altitude - GPS_Alt_Error;
			Altitude_Set = Waypoints[Current_Waypoint].Altitude;
		}
		//if in Full auto (Auto_B) control safety throttle
		if(Mode_Switch == Auto_B)
		{
			// Calculate needed throttle
			if(Altitude >= Altitude_Set+Throttle_Alt_Threshold)
				Servo_Set_Position(THROTTLE_CHANNEL,-500);
			else if (Altitude <= Altitude_Set)
				Servo_Set_Position(THROTTLE_CHANNEL,+500);
			else
				Servo_Set_Position(THROTTLE_CHANNEL,500+(int)(1000*((int)Altitude_Set-(int)Altitude))/(int)Throttle_Alt_Threshold);
		}

		// Delay for 1/Navigate Frequency
		vTaskDelayUntil(&Last_Wake_Time,(1000/Navigate_PID_Frequency)/portTICK_RATE_MS);
	}
}
/*******************************************************************************
* Task Name		 : Airspeed_Task
* Description    : Calculates the Pitch setpoint to maintain cruise speed
*******************************************************************************/
void Airspeed_Task(void *pvParameters)
{
	portTickType Last_Wake_Time;
	Last_Wake_Time = xTaskGetTickCount();

	Pitch_PID.Endpoint[0] = (float)Max_Pitch[0];
	Pitch_PID.Endpoint[1] = (float)Max_Pitch[1];

	PID_Init_f32(&Pitch_PID,1);
	while(1)
	{
		if((Mode_Switch == Auto_A) || (Mode_Switch == Auto_B))
		{
		// Get airspeed error - in m/s floating point
		if (DPres_Voltage>=ZERO_AIRSPEED_VOLTAGE)
			arm_sqrt_f32(1.2*2*(float)(DPres_Voltage-ZERO_AIRSPEED_VOLTAGE),&Airspeed);
		else
			Airspeed = 0;
		// Calulate Pitch setpoint
		Pitch_Setpoint = -PID_f32(&Pitch_PID,Cruise_Speed_Setpoint-Airspeed);
		}

		// Run at 20 Hz
		vTaskDelayUntil(&Last_Wake_Time,50/portTICK_RATE_MS);
	}

}

/**===========================================================================
**   							Main
**===========================================================================*/

int main(void)
{
	// System
	SystemInit();
	RTC_Initialize();
	RCC_Configuration();
	NVIC_Configuration();
	GPIO_Configuration();
	// Turn on LEDs indicating start of initialization
	Led_Set(0);
	//I2C EEPROM
	I2C_Configuration();

	// GPS
	GPS_USART_Initialize(38400);
	GPS_Enable(ENABLE);

	// AHRS
	AHRS_DMA_Initialize((u32*)AHRS_TxBuffer,(u32*)AHRS_RxBuffer);
	AHRS_USART_Initialize(460800);
	AHRS_Reset(DISABLE);
	AHRS_Enable(ENABLE);

	//Radio + Servo
	Spektrum_USART_Initialize();
	Servo_PWM_Initialize(50);

	// Pressure Sensors
	Pressure_ADC_DMA_Initialize();
	Pressure_ADC_Initialize();

	// USB
	USB_Init();

	//Load Configuration from EEPROM
	EE_Load();

	// SD Card
	SD_Mount();

	// Semaphores
	vSemaphoreCreateBinary(Navigate);

	// Tasks
	xTaskCreate(Attitude_Controller_Task,( signed portCHAR * ) "Attitude PID",128,NULL,8,NULL);
	xTaskCreate(Read_Parse_Buffers_Task,( signed portCHAR * ) "Read Parse Buffers",128,NULL,7,NULL);
	xTaskCreate(Navigate_Task,( signed portCHAR * ) "Navigation Task",256,NULL,6,NULL);
	xTaskCreate(Airspeed_Task,( signed portCHAR * ) "Airspeed Task",256,NULL,6,NULL);
	xTaskCreate(Pressure_Data_Task,( signed portCHAR * ) "Pressure Data",256,NULL,5,NULL);
	xTaskCreate(Record_Data_Task,( signed portCHAR * ) "Record Data",1028,NULL,4,NULL);
	xTaskCreate(Radio_Timeout_Task,( signed portCHAR * ) "Flight Mode Button",32,NULL,3,NULL);
	xTaskCreate(Mission_Control_Task,( signed portCHAR * ) "Mission Control UI",256,NULL,2,NULL);
	xTaskCreate(GPS_Initialize_Task,( signed portCHAR * ) "GPS Initialize",64,NULL,1,&GPS_Init_Handle);
	xTaskCreate(Flight_Mode_Task,( signed portCHAR * ) "Flight Mode Button",256,NULL,1,NULL);
	//xTaskCreate(Send_Stats_Task,( signed portCHAR * ) "Send RunTime Stats",256,NULL,1,NULL);

	// Turn led off, and start scheduler
	Led_Reset(0);
	vTaskStartScheduler();

	while (1){
	}
}
