/*
 * controller.c
 *
 *  Created on: May 19, 2011
 *      Author: Alex
 */

#include "controller.h"

/*******************************************************************************
* Function Name  : PID_Init_f32
* Description    : Initalise A0,A1,A2 from Kp,Ki,Kd gains
* Input          : PID instance, Reset
* Output         : None
* Return         : None
*******************************************************************************/
void PID_Init_f32(PID_Instance_f32_Sat * S, int Reset_State )
{
	/* Derived coefficient B2 */
    S->B2 = S->Kp + S->Ki + S->Kd;

    /* Derived coefficient B1 */
    S->B1 = (-S->Kp) - ((float) 2.0 * S->Kd);

    /* Derived coefficient B0 */
    S->B0 = S->Kd;

    if(Reset_State)
    {
    	S->State[0]=0;
    	S->State[1]=0;
    	S->State[2]=0;
    }
}

/*******************************************************************************
* Function Name  : PID_f32
* Description    : Calculate ouput from error input
* Input          : PID instance, error value
* Output         : None
* Return         : None
*******************************************************************************/
float PID_f32(PID_Instance_f32_Sat * S,float E)
{
	float Ucm;
	float Uid;
	float Elim;

	// y[n] = y[n-1] + B2 * x[n] +B1 * x[n-1] + B0 * x[n-2]
	/*Ideal = (S->State[2])+ (S->B2 * e) + (S->B1 * S->State[0]) + (S->B0 * S->State[1]);

	// Saturate
	if(Ideal > S->Endpoint[1])
		Out = S->Endpoint[1];
	else if (Ideal < S->Endpoint[0])
		Out = S->Endpoint[0];
	else
		Out=Ideal;

	// Update state
	S->State[0] = In;			// x(k-1)
	S->State[1] = S->State[0];	// x(k-2)
	S->State[2] = Out;			// y(k-1)

	// return to application
	return (Out);*/


	Uid = S->State[0]+(S->Kp + S->Ki + S->Kd)*E -(S->Kd*S->State[1]);

	// Saturate
	if(Uid > S->Endpoint[1])
		Ucm = S->Endpoint[1];
	else if (Uid < S->Endpoint[0])
		Ucm = S->Endpoint[0];
	else
		Ucm=Uid;

	Elim = E-(Uid-Ucm)/(S->Kp+S->Ki+S->Kd);
	S->State[0] +=  S->Ki*Elim;
	S->State[1] = E;

	return(Ucm);

}
