/*
 *
 * Copyright (c) 2013, Paul Honig & Peter Tambach
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the ETV.
 * 4. Neither the name of the ETV nor the
 *    names of its contributors may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY Paul Honig & Peter Tambach ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Paul Honig & Peter Tambach BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

/*
 * These values differ for every MPU6050 Unit.
 * Please calibrate again when when first using with a new sensor.
 * These ranges are set for a range of accel +-4g and gyro +-500'/s
 */
#define FC_MPU6050_X_ACCEL	517
#define FC_MPU6050_Y_ACCEL	33
#define FC_MPU6050_Z_ACCEL	(8007-8192)  /* 1g down is 8192 */
#define FC_MPU6050_X_GYRO		18
#define FC_MPU6050_Y_GYRO		-93
#define FC_MPU6050_Z_GYRO		-196

/*
 * Declaring an union for the registers and the axis values.
 * The byte order does not match the byte order of
 * the compiler and AVR chip.
 * The AVR chip (on the Arduino board) has the Low Byte
 * at the lower address.
 * But the MPU-6050 has a different order: High Byte at
 * lower address, so that has to be corrected.
 * The register part "reg" is only used internally,
 * and are swapped in code.
 */
typedef union 
{
	struct
	{
		uint8_t x_accel_h;
		uint8_t x_accel_l;
		uint8_t y_accel_h;
		uint8_t y_accel_l;
		uint8_t z_accel_h;
		uint8_t z_accel_l;
		uint8_t t_h;
		uint8_t t_l;
		uint8_t x_gyro_h;
		uint8_t x_gyro_l;
		uint8_t y_gyro_h;
		uint8_t y_gyro_l;
		uint8_t z_gyro_h;
		uint8_t z_gyro_l;
	} reg;
	struct
	{
		int16_t x_accel;
		int16_t y_accel;
		int16_t z_accel;
		int16_t temperature;
		int16_t x_gyro;
		int16_t y_gyro;
		int16_t z_gyro;
	} value;
} accel_t_gyro_union;

typedef struct 
{
	int16_t x_accel;
	int16_t y_accel;
	int16_t z_accel;
	int16_t x_gyro;
	int16_t y_gyro;
	int16_t z_gyro;
} accel_gyro_calibration;

typedef struct
{
	// Output angles in degrees
	float x_angle; // Pitch
	float y_angle; // Roll
	float z_angle;

	// Accelometer data raw (for now)
	int16_t x_accel;
	int16_t y_accel;
	int16_t z_accel;
} MPU6050OutputData;


/*
 * Initialize the MPU6050 sensor.
 */
int MPU6050Init(void);

/*
 * Get the accelerometer and gyro calibration values.
 * This is done by placing the device on a flat leveled surface, and not move it.
 * The routine will take 80 samples and avarage them, returning the results
 */
accel_gyro_calibration *MPU6050GetCalibrationValues(void);

/*
 * This function should only be called by the update thread.
 */
void MPU6050Update(void);

/*
 * Copy the output struct to other threads
 */
void MPU6050GetData(MPU6050OutputData *data);

/*
 * Copy raw device data
 */
void MPU6050GetRawData(accel_t_gyro_union *data);
