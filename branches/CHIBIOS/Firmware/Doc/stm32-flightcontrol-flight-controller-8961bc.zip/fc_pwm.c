/*
 *
 * Copyright (c) 2013, Paul Honig & Peter Tambach
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the ETV.
 * 4. Neither the name of the ETV nor the
 *    names of its contributors may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY Paul Honig & Peter Tambach ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Paul Honig & Peter Tambach BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "ch.h"
#include "hal.h"

#include "fc_pwm.h"

/*
 * Setup for timer 8
 */
static PWMConfig pwmcfg8 = {
	1000000,                                    /* 1MHz PWM clock frequency.   */
  2500,                                       /* Initial PWM period 1/200S.       */
	NULL,
	{
		{PWM_OUTPUT_ACTIVE_HIGH, NULL},
		{PWM_OUTPUT_ACTIVE_HIGH, NULL},
		{PWM_OUTPUT_ACTIVE_HIGH, NULL},
		{PWM_OUTPUT_ACTIVE_HIGH, NULL}
	},
	0,
#if STM32_PWM_USE_ADVANCED
	0,
#endif
	0
};

typedef enum {
  pwm_start,
  pwm_stop,
} pwmState;

static pwmState state;

/*
 * Set pulse width on one of the 4 PWM channels.
 * The performance is set in microseconds.
 */
void PWMSetTimeHigh(uint8_t channel, uint16_t timeHigh)
{
  if(state == pwm_start) {
    /*
     * The time high needs to be multiplied by 3.
     */
    pwmEnableChannel(&PWMD8, channel, PWM_PERCENTAGE_TO_WIDTH(&PWMD8, 4*timeHigh));
  }
}

/*
 * Initialize the PWM output
 */
void PWMInit(void)
{
	/*
	 * Initializes the PWM driver 1 
	 */
	pwmStart(&PWMD8, &pwmcfg8);

#if 0
	/*
	 * Timer 8 ports
   * Should be set in board file.
	 */
	palSetPadMode(GPIOC, 6, PAL_MODE_ALTERNATE(3));
	palSetPadMode(GPIOC, 7, PAL_MODE_ALTERNATE(3));
	palSetPadMode(GPIOC, 8, PAL_MODE_ALTERNATE(3));
	palSetPadMode(GPIOC, 9, PAL_MODE_ALTERNATE(3));
#endif

	/*
	 * Set all of the channels 100us, to show the PWM is not armed.
	 */
	PWMSetTimeHigh(0, 100);
	PWMSetTimeHigh(1, 100);
	PWMSetTimeHigh(2, 100);
	PWMSetTimeHigh(3, 100);

	pwmStop(&PWMD8);
  
  state = pwm_stop;
}

/*
 * Enable PWM channels
 */
void PWMEnable(void)
{
	/*
	 * Initializes the PWM driver 1 
	 */
	pwmStart(&PWMD8, &pwmcfg8);

	/*
	 * Set all of the channels 100us, to show the PWM is not armed.
	 */
	PWMSetTimeHigh(0, 100);
	PWMSetTimeHigh(1, 100);
	PWMSetTimeHigh(2, 100);
	PWMSetTimeHigh(3, 100);

  state = pwm_start;
}

/*
 * Disable PWM channels
 */
void PWMDisable(void)
{
	/*
	 * Initializes the PWM driver 1 
	 */
	pwmStop(&PWMD8);

  state = pwm_stop;
}

