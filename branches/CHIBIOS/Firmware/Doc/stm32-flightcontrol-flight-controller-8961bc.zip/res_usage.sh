#!/bin/bash
cd build
cat flightcontrol.map | grep ".stacks         0x20000000"
STACKS=`cat flightcontrol.map | grep ".stacks         0x20000000" | gawk '{print$3}'`

cat flightcontrol.map | grep "__ram_start__ ="
RAM_START=`cat flightcontrol.map | grep "__ram_start__ =" | gawk '{print$1}'`

cat flightcontrol.map | grep "__ram_size__ ="
RAM_MCU=`cat flightcontrol.map | grep "__ram_size__ =" | gawk '{print$1}'`

cat flightcontrol.map | grep ".data" | grep "load address"
cat flightcontrol.map | grep ".bss" | grep "load address"

cat flightcontrol.map | grep "_end = ."
PROGRAM=`cat flightcontrol.map | grep "_end = ." | gawk '{print$1}'`

cat flightcontrol.map | grep "__heap_end__ = (__ram_end__ - __stacks_total_size__)"

FLASH_USED=`du -b flightcontrol.bin | gawk '{print$1}'`
FLASH_MCU=1048576
echo "------------------------------------------------------------------------------------------------------------"

let "STACK = STACKS"
let "RAM_MCU = RAM_MCU"
let "RAM_USED = PROGRAM - RAM_START"
let "PROGRAM = PROGRAM - RAM_START - STACK"
let "FLASH_PERCENT = (100 * FLASH_USED)/FLASH_MCU"
let "RAM_PERCENT = (100 * RAM_USED)/RAM_MCU"

echo "SRAM:  stacks = $STACK, program = $PROGRAM, total = $RAM_USED, mcu_ram = $RAM_MCU, utilization = $RAM_PERCENT%"
echo "FLASH: program = $FLASH_USED, mcu_flash = $FLASH_MCU, utilization = $FLASH_PERCENT%"
