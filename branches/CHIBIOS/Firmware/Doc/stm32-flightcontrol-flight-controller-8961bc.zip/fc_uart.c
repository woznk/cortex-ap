/*
 *
 * Copyright (c) 2013, Paul Honig & Peter Tambach
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the ETV.
 * 4. Neither the name of the ETV nor the
 *    names of its contributors may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY Paul Honig & Peter Tambach ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Paul Honig & Peter Tambach BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "ch.h"
#include "hal.h"
#include "chprintf.h"

#include "fc_gpio.h"

#include <stdio.h>
#include <string.h>
#include <stdarg.h>

/*
 * UART Printf buffer
 */
#define BUF_SIZE	160
static char UARTPrintBuf[BUF_SIZE];

/*
 * Serial port Mutex
 */
static Mutex					sermtx; /* Mutex */


static SerialConfig serial_cfg_1 = {
	57600,
	0,
	0,
	0,
};

static SerialConfig serial_cfg_2 = {
		57600,
		0,
		0,
		0,
};

static SerialConfig serial_cfg_4 = {
	115200,
	0,
	0,
	0,
};

/*
 * Initialize the serial port
 */
void UARTInit(void)
{
	/*
	 * Initialize Mutex
	 */
	chMtxInit(&sermtx); /* Mutex initialization before use */

	/*
	 * Telemetry UART
	 */
	sdStart(&SD1, &serial_cfg_1);

  /*
   * Debug terminal
   */
	sdStart(&SD4, &serial_cfg_4);
	palSetPadMode(GPIOA, 0, PAL_MODE_ALTERNATE(8));
	palSetPadMode(GPIOA, 1, PAL_MODE_ALTERNATE(8));

	/*
	 * GPS Interface
	 */
	sdStart(&SD2, &serial_cfg_2);
	//palSetPadMode(GPIOD, 5, PAL_MODE_ALTERNATE(7));
	//palSetPadMode(GPIOD, 6, PAL_MODE_ALTERNATE(7));
}


/*
 * Print formatted string to serial port
 */
void UARTPrintf(const char *format, ...)
{
	va_list ap; 
	va_start (ap, format);

	chMtxLock(&sermtx);

	/* 
	 * Build string to send to the buffer.
	 */
	vsnprintf(UARTPrintBuf, BUF_SIZE, format, ap);

	/*
   * Print stuff UART
	 */
	chprintf((BaseSequentialStream *) &SD4, UARTPrintBuf);

	chMtxUnlock();
}
