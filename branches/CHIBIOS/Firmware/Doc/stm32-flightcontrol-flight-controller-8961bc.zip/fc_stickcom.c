/*
 *
 * Copyright (c) 2013, Paul Honig & Peter Tambach
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the ETV.
 * 4. Neither the name of the ETV nor the
 *    names of its contributors may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY Paul Honig & Peter Tambach ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Paul Honig & Peter Tambach BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "ch.h"
#include "hal.h"
#include "fc_receiver.h"
#include "fc_gpio.h"
#include "fc_pwm.h"

/*
 * In this software we assume mode 2 transmitter configuration.
 * Functions that can be triggered through the stick commands
 * Arming motors														: Throttle / Yaw bottom right, Pitch / Roll centered
 * Disarming motors													: Throttle / Yaw bottom left, Pitch / Roll centered
 * Gyroscope and accelerometer calibration	:	Throttle / Yaw bottom left, Pitch / Roll bottom right
 * Initialize GPS home position							: Throttle / Yaw bottom left, Pitch / Roll top right
 */

/*
 * For now these values are defines. 
 * In the future they might come from the eprom.
 */
#define		STC_LOW		  10
#define		STC_MIDLOW	(500-STC_LOW)
#define		STC_MIDHIGH	(500+STC_LOW)
#define		STC_HIGH		(1000-STC_LOW)
#define   STC_EDGE    4000            /* used to invalidate the default -1 error value. */

/*
 * Used to simplify Stick command detection.
 */
typedef enum {
	none=0, 
	min,
	mid,
	max
} stc_pos_t;

/*
 * Structure holding the per channel detection limit.
 */
typedef struct {
	rec_width_t low;			/* Below this the channel considered low					*/
	rec_width_t midlow;	/* Above this the channel is considered center		*/
	rec_width_t midhigh;	/* Below this the channel is considered centered	*/
	rec_width_t high;		/* Above this the channel is considered high			*/
} stc_limit_t;

/* 
 * structure holding the limits.
 */
static stc_limit_t limit;

/* Command enumeration */
typedef enum {
	nocommand,
	arm,
	disarm,
	callibrate,
	gps_init
} stc_command_t; 

/*
 * Initialize detection with default values.
 */
void STCInit(void)
{
  /* 
   * Disable Arm LED 
   */
  ledoff1(NULL);

  /* 
   * Set detection range 
   */
	limit.low			= STC_LOW;
	limit.midlow	= STC_MIDLOW;
	limit.midhigh	=	STC_MIDHIGH;
	limit.high		= STC_HIGH;
}

/*
 * Convert the channel width to a discrete position.
 */
static stc_pos_t STCChannelDecode(rec_width_t value)
{
	stc_pos_t retval = none;
	if( value < limit.low){
		retval = min;
	} 
	else if(value > limit.midlow && value < limit.midhigh) {
		retval = mid;
	}
	else if(value > limit.high && value < STC_EDGE) {
		retval = max;
	}

	return retval;
}

/*
 * Decode stick commands and return command value
 *
 * In this software we assume mode 2 transmitter configuration.
 * Functions that can be triggered through the stick commands
 * Arming motors                            : Throttle / Yaw bottom right, Pitch / Roll centered
 * Disarming motors                         : Throttle / Yaw bottom left, Pitch / Roll centered
 * Gyroscope and accelerometer calibration  : Throttle / Yaw bottom left, Pitch / Roll bottom right
 * Initialize GPS home position             : Throttle / Yaw bottom left, Pitch / Roll top right
 */
static stc_command_t STCDecodeCommand(stc_pos_t pitch, stc_pos_t roll, stc_pos_t yaw, stc_pos_t throttle)
{
	stc_command_t command = nocommand;

	if((throttle == min) && (yaw == max) && (pitch == min) && (roll == min)){
		command = arm;
	}
  /* Since disarming can be done in an emergency, pitch and roll do not need to be centered.  */
	else if((throttle == min) && (yaw == min)){
		command = disarm;
	}
	else if((throttle == min) && (yaw == min) && (pitch == min) && (roll == max)){
		command = callibrate;
	}
	else if((throttle == min) && (yaw == min) && (pitch == max) && (roll == max)){
		command = gps_init;
	}

	return command;
}

/*
 * Get channel positions, and translate into fuctions to call.
 */
void STCCommand(void)
{
	stc_pos_t	pitch;
	stc_pos_t	roll;
	stc_pos_t	yaw;
	stc_pos_t	throttle;
	rec_width_t tmp=0;
	stc_command_t com=nocommand;

	/* Get channel positions. */
	tmp       = RECGetWidth(PITCH);
	pitch     = STCChannelDecode(tmp);
	tmp       = RECGetWidth(ROLL);
	roll	    = STCChannelDecode(tmp);
	tmp       = RECGetWidth(YAW);
	yaw		    = STCChannelDecode(tmp);
	tmp	      = RECGetWidth(THROTTLE);
	throttle  = STCChannelDecode(tmp);

	/* Call methods when a pattern matches. */
	com = STCDecodeCommand(pitch, roll, yaw, throttle);
	switch(com){
		case arm: 
			PWMEnable();	
      ledon1(NULL);
      break;
		case disarm:
			PWMDisable();
      ledoff1(NULL);
      break;
		case callibrate:
      break;
		case gps_init:
      break;
		default:
			return;
	}
}

