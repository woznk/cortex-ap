/*
 *
 * Copyright (c) 2013, Paul Honig & Peter Tambach
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the ETV.
 * 4. Neither the name of the ETV nor the
 *    names of its contributors may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY Paul Honig & Peter Tambach ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Paul Honig & Peter Tambach BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

/* 
 * This is a simple kalman filter implementation.
 * This filter assumes the current measure meant close to the last one is the correct one.
 * This function can be used to even out slow changing precesses, like bearing and altitude.
 * sample values for float Q = 0.022; R = 0.617;
 */
float KALsimple(float z_measured, float x_est_last, float Q, float R);

/*
 * Kalman Structure for a position and speed.
 */
typedef struct {
	float Q_angle;
	float Q_gyro;
	float R_angle;

	float x_angle;
	float x_bias;
	float P_00; 
	float	P_01; 
	float P_10; 
	float P_11;
} kalman2Struct;

/*
 * Kalman Structure for a position, speed and acceleration
 */
typedef struct {
	Matrix31 xk_hatc; /* Last state estimate */

	Matrix33 Q;			/* Process Error Matrix */
	Matrix33 R;			/* Measurement Error Matrix */
	Matrix33 P;			/* Noise Matrix */

} kalman3Struct;

/*
 * Initialize the Kalman structure for a position and speed Kalman filter
 */
void KAL2Init(kalman2Struct *kalStruct);

/*
 * Insert Accelerometer Angle, and Gyroscope rate + time elapsed to get none-drifting angle data.
 * All input should be in Radiants.
 * The Kalman structure handles the variables that are stored from one iteration to the other.
 * This filter acts on 2 value in the model, position and speed.
 */
float KAL2Calculate(kalman2Struct *kalman2Struct, float newAngle, float newRate,int looptime);

/*
 * Initialize the Kalman filter for a position, speed and acceleration filter.
 * Assuming position, speed and acceleration to be 0 at time 0.
 */
void KAL3Init(kalman3Struct *kalman3Struct);

/*
 * Insert Acceleration of position or both to update Kalman Filter state and get new estimate out.
 * Model in this Kalman filter is based on Newtons laws of motion.
 * newPos in m
 * newAccel in m/s^2 (When no control input leave 0.0)
 * dt in ms
 */
void KAL3Calculate(kalman3Struct *kalStruct, float newPos, float newAccel, int looptime);

