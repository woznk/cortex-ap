/*
 *
 * Copyright (c) 2013, Paul Honig & Peter Tambach
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the ETV.
 * 4. Neither the name of the ETV nor the
 *    names of its contributors may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY Paul Honig & Peter Tambach ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Paul Honig & Peter Tambach BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "ch.h"
#include "hal.h"

#include "fc_uart.h"

/*
 * Debug Settings
 */
#define FC_I2C_DEBUG 1

/* Initialize I2C to 400 kHz mode. */
static const I2CConfig i2cfg1 = {
    OPMODE_I2C,
    400000,
    FAST_DUTY_CYCLE_2, //Changed since ChibiOS 2.4.2
};

/*
 * Initialize the I2C subsystem, including the pins.
 */
void I2CInit(void){
	i2cStart(&I2CD1, &i2cfg1);
  
	palSetPadMode(GPIOB, 6, PAL_MODE_ALTERNATE(4) | PAL_STM32_OTYPE_OPENDRAIN);
  palSetPadMode(GPIOB, 7, PAL_MODE_ALTERNATE(4) | PAL_STM32_OTYPE_OPENDRAIN);
  palSetPadMode(GPIOB, 9, PAL_MODE_ALTERNATE(0));

	/* startups. Pauses added just to be safe */
	chThdSleepMilliseconds(100);
}

/*
 * Read a number of bytes into a provided buffer.
 */
msg_t I2CRead(i2caddr_t dev_addr, uint8_t *tx_buf, uint8_t tx_size, uint8_t *rx_buf, uint8_t rx_size)
{
	msg_t retval=0;						/* Return value */
	systime_t tmo = MS2ST(4);		/* 4 milliseconds */
	i2cflags_t i2cflags=0;

	/*
   * Claim I2C bus for this thread
	 */
  i2cAcquireBus(&I2CD1);

	/*
	 * Read the different elements, 
	 */
	retval = i2cMasterTransmitTimeout (
			&I2CD1,
			dev_addr,
			tx_buf,
			tx_size,
			rx_buf,
			rx_size,
			tmo);

	/*
	 * Release I2C bus
	 */
  i2cReleaseBus(&I2CD1);

#ifdef FC_I2C_DEBUG
	if (retval != RDY_OK) {
		i2cflags = i2cGetErrors(&I2CD1);
		switch(i2cflags){
			case I2CD_ACK_FAILURE:
				UARTPrintf("I2C Error ACK Failure\r\n");
				break;
			case I2CD_TIMEOUT:
				UARTPrintf("I2C Error Timeout\r\n");
				break;
			default:
				UARTPrintf("I2C Unknown error\r\n");
		}	
	}
#endif
	
	return retval;
}

/*
 * Get short from I2C bus.
 * Because of byte ordering reverse MSB and LSB
 */
msg_t I2CReadShort(i2caddr_t dev_addr, uint8_t *tx_buf, uint8_t tx_size, short *result)
{
	uint8_t	rx_buf[2];					/* Receive buffer */
	msg_t retval=0;

	/*
	 * Get value.
	 */
	retval = I2CRead(dev_addr, tx_buf, tx_size, rx_buf, 2);

	/*
	 * When results are read, reverse LSB and MSB.
	 */
	if (retval == RDY_OK) {
		*result = (short) (rx_buf[0] << 8) + rx_buf[1];
	} 

	return retval;
}

/*
 * Read a number of bytes into a provided buffer.
 */
msg_t I2CWrite(i2caddr_t dev_addr, uint8_t *tx_buf, uint8_t tx_size)
{
	msg_t retval=0;

	/*
	 * Sneaky do a read :)
	 */
	retval = I2CRead(dev_addr, tx_buf, tx_size, NULL, 0);

	return retval;
}
