/*
 *
 * Copyright (c) 2013, Paul Honig & Peter Tambach
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the ETV.
 * 4. Neither the name of the ETV nor the
 *    names of its contributors may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY Paul Honig & Peter Tambach ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Paul Honig & Peter Tambach BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 *
 */

#include "ch.h"
#include "hal.h"
#include <string.h>
#include <math.h>

#include "fc_gen.h"
#include "fc_gpio.h"
#include "fc_controller.h"
#include "fc_gpio.h"
#include "fc_pid.h"
#include "fc_pwm.h"
//#include "fc_uart.h"
#include "fc_receiver.h"
#include "fc_altitude.h"
#include "fc_state.h"
#include "fc_stickcom.h"
#include "fc_settings.h"

/*
 * Structures holding the X, Y and Z axis controllers
 */
PIDStruct controlX;
PIDStruct controlY;
PIDStruct controlZ;

/*
 * Mutex to lock output buffer
 */
static Mutex					controlMtx; /* Mutex */

/*
 * Structure holding current system state.
 */
STATEOutputData sysState;

/*
 * Structure to store results in.
 */
ControlStruct controlStruct;
ControlStruct controlDeg;
ControlStruct controlOut;
PWMoutput			PWMout;


/*
 * Initialize controller.
 */
void CONTROLInit(void)
{
	/* 
	 * Setup the PID controller structures.
	 */
	initPIDStruct(&controlX);
	initPIDStruct(&controlY);
	initPIDStruct(&controlZ);

	/*
	 * Initialize Mutex
	 */
	chMtxInit(&controlMtx); /* Mutex initialization before use */

	/*
	 * Clear controlStruct.
	 */
	memset(&controlStruct, 0, sizeof(ControlStruct));

	/*
	 * Clear System State struct.
	 */
	memset(&sysState, 0, sizeof(STATEOutputData));

	/*
	 * DEBUG set aiming values hard for now
	 */
	controlX.Kp=SETGetFloat(val_x_cont_kp);
	controlY.Kp=SETGetFloat(val_y_cont_kp);
  controlZ.Kp=SETGetFloat(val_z_cont_kp);

  /*
   * Set default power to the output.
   */
  controlStruct.power=0;
}

/*
 * Get results out.
 */
void CONTROLGetOut(ControlStruct *out)
{
  chMtxLock(&controlMtx);
  memcpy(out, &controlStruct, sizeof(ControlStruct));
  chMtxUnlock();
}

/*
 * Routine to put the structure hold content to the PWM out.
 */
static void CONTROLPWMOut(void)
{
  /*
   * Put the 4 values to the PWM out.
   */
  chMtxLock(&controlMtx);
  PWMSetTimeHigh(0, PWMout.m1);
  PWMSetTimeHigh(1, PWMout.m2);
  PWMSetTimeHigh(2, PWMout.m3);
  PWMSetTimeHigh(3, PWMout.m4);
  chMtxUnlock();
}

/*
 * Calculate the Power distribution over the 4 motors.
 * Provided with controller structure the PWMoutput structure gets filled with the appropriate 
 * The algorithm is configured the fly the Quad copter in X mode.
 * With motor configuration :
 *
 * 1   2
 *   X
 * 4   3
 *
 * 1, 3 rotate clockwise
 * 2, 4 rotate counter clockwise
 */
static void CONTROLCalcPower(void)
{
  //	uint16_t qpower; /* Holds power/4 */
  int cutoff=0;

  /*
   * Distribute the Throttle over the 4 Motors
   */
  chMtxLock(&controlMtx);

  /*
   * set power to output.
   */
  cutoff = SETGetInt(val_throt_cutoff);
  if(controlStruct.power < cutoff) {
    /*
     * When the throttle power is below cutoff, no power to the motors.
     */
    PWMout.m1 = PWMout.m2 = PWMout.m3 = PWMout.m4 = 0;
  } else {

    /*
     * Set basic power.
     */
    PWMout.m1 = controlStruct.power;
    PWMout.m2 = controlStruct.power;
    PWMout.m3 = controlStruct.power;
    PWMout.m4 = controlStruct.power;

    /*
     * Calculate Z axis correction
     */
    PWMout.m1 += controlStruct.z;
    PWMout.m2 += controlStruct.z;
    PWMout.m3 -= controlStruct.z;
    PWMout.m4 -= controlStruct.z;

    /*
     * Calculate Y axis correction
     */
    PWMout.m1 -= controlStruct.y;
    PWMout.m4 -= controlStruct.y;
    PWMout.m3 += controlStruct.y;
    PWMout.m2 += controlStruct.y;

    /*
     * Calculate X axis correction
     */
    PWMout.m1 -= controlStruct.x;
    PWMout.m3 -= controlStruct.x;
    PWMout.m2 += controlStruct.x;
    PWMout.m4 += controlStruct.x;

  }

    /*
     * Add minimal PWM width to Signal
     */
    PWMout.m1 += PWM_MIN_HIGH;
    PWMout.m2 += PWM_MIN_HIGH;
    PWMout.m3 += PWM_MIN_HIGH;
    PWMout.m4 += PWM_MIN_HIGH;

  chMtxUnlock();
}

/*
 * To make sure no motor cuts in mid air.
 * Output should me held between 500-2000 us.
 */
static void CONTROLLimitOut(void)
{
  chMtxLock(&controlMtx);

  GENconstrain(PWMout.m1, PWM_MIN_HIGH, PWM_MAX_HIGH);
  GENconstrain(PWMout.m2, PWM_MIN_HIGH, PWM_MAX_HIGH);
  GENconstrain(PWMout.m3, PWM_MIN_HIGH, PWM_MAX_HIGH);
  GENconstrain(PWMout.m4, PWM_MIN_HIGH, PWM_MAX_HIGH);

  chMtxUnlock();
}

/*
 * Get the control structure
 */
void CONTROLGetStruct(PWMoutput *out)
{
  chMtxLock(&controlMtx);
  memcpy(out, &controlOut, sizeof(ControlStruct));	
  chMtxUnlock();
}

/*
 * Get current motor pwm output state.
 */
void CONTROLGetMotorOut(PWMoutput *out)
{
  chMtxLock(&controlMtx);
  memcpy(out, &PWMout, sizeof(PWMoutput));	
  chMtxUnlock();
}

/*
 * Get values from receiver PWM
 */
static void CONTROLGetReceiveruS(void)
{
  chMtxLock(&controlMtx);

  controlStruct.power = RECGetWidth(THROTTLE);
  controlStruct.x = (RECGetWidth(PITCH)-RECGetMiddle());
  controlStruct.y = (RECGetWidth(ROLL)-RECGetMiddle());
  controlStruct.z = (RECGetWidth(YAW)-RECGetMiddle());

  chMtxUnlock();
}

/*
 * Convert Receiver values to degrees, for stabalized mode.
 */
static void CONTROLRecToDeg(void)
{
  controlDeg.power = controlStruct.power;
  controlDeg.x =  (controlStruct.x*45) / RECGetMiddle();
  controlDeg.y =  (controlStruct.y*45) / RECGetMiddle();
  controlDeg.z =  (controlStruct.z*45) / RECGetMiddle();
}

/*
 * Loop to update the PID output towards the PWM module.
 */
void CONTROLUpdate(void)
{
  /*
   * Execute stickcommands.
   */
  STCCommand();

  /*
   * Update State structure, and retrieve it.
   */
  STATEUpdate();
  STATEGet(&sysState);

  /*
   * Update controlles from receiver.
   */
  CONTROLGetReceiveruS();

  /*
   * Convert Receiver values to degrees, for stabalized mode.
   * Default is -45' to +45' (in stabalized mode)
   */
  CONTROLRecToDeg();

  /*
   * Update the output values
   */
  chMtxLock(&controlMtx);
  controlStruct.x = PIDUpdatePid(&controlX, sysState.pitch*RADTODEG, controlDeg.x,  sysState.time);
  controlStruct.y = PIDUpdatePid(&controlY, sysState.roll*RADTODEG,  controlDeg.y,	sysState.time);
  controlStruct.z = PIDUpdatePid(&controlZ, sysState.yawSpeed,       controlDeg.z,  sysState.time);
	chMtxUnlock();

	/*
	 * Put the output values towards power distribution calculations.
	 */
	CONTROLCalcPower();

	/*
	 * Limit the controller output to sane values.
	 */
	CONTROLLimitOut();

	/*
	 * Send the results to the PWM out channels.
	 */
	CONTROLPWMOut();

	/*
	 * Copy Controlstruct to the out struct.
	 */
	chMtxLock(&controlMtx);
	memcpy(&controlStruct, &controlOut, sizeof(ControlStruct));	
	chMtxUnlock();


	ledtoggle2();
}

