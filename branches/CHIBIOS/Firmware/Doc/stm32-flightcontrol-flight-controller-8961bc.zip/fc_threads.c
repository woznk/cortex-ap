/*
 *
 * Copyright (c) 2013, Paul Honig & Peter Tambach
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the ETV.
 * 4. Neither the name of the ETV nor the
 *    names of its contributors may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY Paul Honig & Peter Tambach ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Paul Honig & Peter Tambach BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "ch.h"
#include "hal.h"

#include "fc_uart.h"

#include "fc_gen.h"
#include "fc_bmp085.h"
#include "fc_mpu6050.h"
#include "fc_hmc5883.h"
#include "fc_threads.h"
#include "fc_em411.h"
#include "fc_controller.h"

/*
 * Accelerometer thread
 */
static WORKING_AREA(PollAccelThreadWA, 256);
static msg_t PollAccelThread(void *arg) {
	chRegSetThreadName("PollAccel");
	(void)arg;
	long timeNow=0;
	long timePrev=0;

	while (TRUE) {
		timePrev = MS2ST(chTimeNow());
		MPU6050Update();
		timeNow = MS2ST(chTimeNow());
		// Update 200 time/second
		chThdSleepMilliseconds(5-(timeNow-timePrev));
	}
	return 0;
}

/*
 * Barometer thread
 */
static WORKING_AREA(PollBaroThreadWA, 512);
static msg_t PollBaroThread(void *arg) {
	chRegSetThreadName("PollBaro");
	(void)arg;
	long timeNow=0;
	long timePrev=0;

	while (TRUE) {
		timePrev = MS2ST(chTimeNow());
#ifdef USE_BMP085
		BMP085UpdatePressure();
#endif
		timeNow = MS2ST(chTimeNow());
		// Update the pressure 20 times a second
		chThdSleepMilliseconds(50-(timeNow-timePrev));
	}
	return 0;
}

/*
 * Compass thread
 */
static WORKING_AREA(PollCompassThreadWA, 256);
static msg_t PollCompassThread(void *arg) {
	chRegSetThreadName("PollCompass");
	(void)arg;
	long timeNow=0;
	long timePrev=0;
	while (TRUE) {
		/*chThdSleepMilliseconds(rand() & 31);*/
		timePrev = MS2ST(chTimeNow());
		HMC5883Update();
		timeNow = MS2ST(chTimeNow());
		chThdSleepMilliseconds(7-(timeNow-timePrev));
	}
	return 0;
}

/*
 * GPS thread
 */
static WORKING_AREA(PollGPSThreadWA, 1280);
static msg_t PollGPSThread(void *arg) {
	chRegSetThreadName("PollGPS");
	(void)arg;
	while (TRUE) {
		/* 
		 * No time out here, as interface is blocking
		 */
		EM411Update();
	}
	return 0;
}

/*
 * Controller thread
 */
static WORKING_AREA(PollControlThreadWA, 2024);
static msg_t PollControlThread(void *arg) {
	chRegSetThreadName("PollController");
	(void)arg;
	long timeNow=0;
	long timePrev=0;
	long timeDiff=0;

	while (TRUE) {
		timePrev = MS2ST(chTimeNow());
		CONTROLUpdate();
		timeNow = MS2ST(chTimeNow());
		timeDiff = 5-(timeNow-timePrev);
		// Avoid infinite sleep
		if(timeDiff > 0) {
			chThdSleepMilliseconds(timeDiff);
		}
	}
	return 0;
}

/*
 * Start Threads
 */
void startThreads(void)
{
	/* 
	 * Create barometer thread 
	 */
	chThdCreateStatic(PollBaroThreadWA,
			sizeof(PollBaroThreadWA),
			NORMALPRIO,
			PollBaroThread,
			NULL);

	/* 
	 * Create accelerometer thread 
	 */
	chThdCreateStatic(PollAccelThreadWA,
			sizeof(PollAccelThreadWA),
			NORMALPRIO,
			PollAccelThread,
			NULL);

	/*
	 * Create compass thread
	 */
	chThdCreateStatic(PollCompassThreadWA,
			sizeof(PollCompassThreadWA),
			NORMALPRIO,
			PollCompassThread,
			NULL);

	/*
	 * Create gps thread
	 */
	chThdCreateStatic(PollGPSThreadWA,
			sizeof(PollGPSThreadWA),
			NORMALPRIO,
			PollGPSThread,
			NULL);

	/*
	 * Create control thread
	 */
	chThdCreateStatic(PollControlThreadWA,
			sizeof(PollControlThreadWA),
			NORMALPRIO,
			PollControlThread,
			NULL);
}
