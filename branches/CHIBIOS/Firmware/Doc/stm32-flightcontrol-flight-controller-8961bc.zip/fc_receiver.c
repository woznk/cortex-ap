/*
 *
 * Copyright (c) 2013, Paul Honig & Peter Tambach
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the ETV.
 * 4. Neither the name of the ETV nor the
 *    names of its contributors may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY Paul Honig & Peter Tambach ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Paul Honig & Peter Tambach BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *	PWM Receiver for STM32-FlightControl
 *	File initiated on 08.08.13 by Piele, piele@creativeserver.net
 *
 */
#include "ch.h"
#include "hal.h"
#include "fc_receiver.h"
#include "fc_gpio.h"
#include "pwm4.h"
#include "fc_settings.h"

/*
 * Since the max output is 1000 and min is 0
 * Mid should be 500.
 */
#define REC_MID_SIGNAL 500

/*
 * Structure holding the translation settings per channel.
 * translate 8 channels.
 */
typedef struct {
	uint16_t channel; /* Channel Number				*/
	uint16_t min;			/* Minimal pulse width	*/
	uint16_t max;			/* Maximal pulse width	*/
} rec_chan_trans_t;
static rec_chan_trans_t rec_trans_table[8];

/*
 * Things that this module needs to do :
 * Configure PWM4 Chibios external module
 * Scale the input to 0 - 1000 per channel.
 * Map channel to the corresponding: Throttle, yaw, pitch, roll, function 1,2,3,4.
 * Check sanity of the input signal, by observing microseconds.
 * Dispatch Signal loss signal to disarm routine.
 * Configuration structure.
 */

void RECSignalLost(void)
{
	/*
	 * Toggle blue LED when signal is lost.
	 */
	ledon2(0);
}

/*
 * PWM4 configuration.
 */
static PWM4Config pwm4cfg = {
	1000000,	/* 1MHz PWM4 Clock frequency */
	PWM4_CHANNEL_1 | PWM4_CHANNEL_2 | PWM4_CHANNEL_3 | PWM4_CHANNEL_4, /* Capture all channels */
	10,			/* Trigger watchdog after 10 timeouts */
	RECSignalLost			/* No overflow trigger for now				 */
};

/*
 * Initialize the receiver input
 */
void RECInit(void)
{
	/*
	 * Initializes the PWM4 Driver for timer 1 & 4
	 */
	pwm4Start(&PWM4D1, &pwm4cfg);
	pwm4Start(&PWM4D4, &pwm4cfg);

	/*
	 * Timer 1 ports
	 */
	pwm4Enable(&PWM4D1);
	pwm4Enable(&PWM4D4);

	/*
	 * Set the pins to the ones used on the AQ32-Board.
	 */
	pwm4SetPortPin(&PWM4D4, 1, GPIOD, 12);
	pwm4SetPortPin(&PWM4D4, 2, GPIOD, 13);
	pwm4SetPortPin(&PWM4D4, 3, GPIOD, 14);
	pwm4SetPortPin(&PWM4D4, 4, GPIOD, 15);

	/*
	 * Set the pins to the ones used on the AQ32-Board.
	 */
	pwm4SetPortPin(&PWM4D1, 1, GPIOE, 9);
	pwm4SetPortPin(&PWM4D1, 2, GPIOE, 11);
	pwm4SetPortPin(&PWM4D1, 3, GPIOE, 13);
	pwm4SetPortPin(&PWM4D1, 4, GPIOE, 14);

	/*
	 * Put in standard translation table
	 * Name -> channel
	 */
	rec_trans_table[ROLL].channel			= 0;
	rec_trans_table[PITCH].channel		= 1;
	rec_trans_table[THROTTLE].channel = 2;
	rec_trans_table[YAW].channel			= 3;
	rec_trans_table[FUNC1].channel		= 4;
	rec_trans_table[FUNC2].channel		= 5;
	rec_trans_table[FUNC3].channel		= 6;
	rec_trans_table[FUNC4].channel		= 7;

	/*
	 * Use the settings to fill te min and max values.
	 */
int SETGetInt(enum settings_index index);
  rec_trans_table[PITCH].max    = SETGetInt(val_rec_max_pitch);
  rec_trans_table[PITCH].min    = SETGetInt(val_rec_min_pitch);
  rec_trans_table[ROLL].max     = SETGetInt(val_rec_max_roll);
  rec_trans_table[ROLL].min     = SETGetInt(val_rec_min_roll);
  rec_trans_table[THROTTLE].max = SETGetInt(val_rec_max_throt);
  rec_trans_table[THROTTLE].min = SETGetInt(val_rec_min_throt);
  rec_trans_table[YAW].max      = SETGetInt(val_rec_max_yaw);
  rec_trans_table[YAW].min      = SETGetInt(val_rec_min_yaw);
}

/*
 * Change translation table.
 */
void RECSetTransTable(rec_names_t name, uint16_t channel)
{
	rec_trans_table[name].channel=channel;
}

/*
 * Change min value for channel.
 */
void RECSetMinPWM(rec_names_t name, uint16_t min)
{
	rec_trans_table[name].min=min;
}

/*
 * Change min value for channel.
 */
void RECSetMaxPWM(rec_names_t name, uint16_t max)
{
	rec_trans_table[name].max=max;
}

/*
 * Get the raw PWM width.
 */
static inline rec_width_t RECGetRawWidth(uint16_t channel)
{
	rec_width_t width=0;

	width = pwm4GetWidth(&PWM4D4, channel);

	return (int) width;
}

/*
 * Normalize and check channel for sanity
 * When insane values, return 0xFFFF (65535)
 * Otherwise, a range between 0-1000 is returned.
 */
static inline rec_width_t RECNormalize(rec_names_t name, uint16_t val)
{
	uint32_t retval=0;

  if (val > rec_trans_table[name].max+30 || val < rec_trans_table[name].min-30) {
      retval = 0xFFFF;
  } else if(val > rec_trans_table[name].max) {
		retval = 1000;
  } else if(val < rec_trans_table[name].min) {
		retval = 0;
	} else {
		retval = val-rec_trans_table[name].min;
		retval *= 1000;
		retval = retval / (rec_trans_table[name].max-rec_trans_table[name].min);
	}

	return retval;
}


/*
 * Returns walue of the last pulse width.
 */
rec_width_t RECGetWidthMs(rec_names_t name)
{
	rec_width_t retval=0;
	uint16_t		channel=0;

	channel = rec_trans_table[name].channel;

	retval  = RECGetRawWidth(channel);

	return retval;
}

/*
 * Returns walue of the last pulse width.
 */
rec_width_t RECGetWidth(rec_names_t name)
{
	rec_width_t retval=0;
	rec_width_t	ms=0;

  ms = RECGetWidthMs(name);

	retval = RECNormalize(name, ms);

	return retval;
}

/*
 * Return Receiver mid signal.
 */
rec_width_t RECGetMiddle(void)
{
	return REC_MID_SIGNAL;
}
