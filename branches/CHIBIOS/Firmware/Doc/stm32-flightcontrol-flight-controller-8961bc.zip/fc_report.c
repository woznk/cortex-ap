/*
 *
 * Copyright (c) 2013, Paul Honig & Peter Tambach
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the ETV.
 * 4. Neither the name of the ETV nor the
 *    names of its contributors may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY Paul Honig & Peter Tambach ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Paul Honig & Peter Tambach BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "ch.h"
#include "hal.h"
#include <math.h>
#include <string.h>

#include "fc_gen.h"
#include "fc_gpio.h"
#include "MadgwickAHRS.h"
#include "fc_uart.h"
#include "fc_hmc5883.h"
#include "fc_receiver.h"
#include "fc_mpu6050.h"
#include "fc_altitude.h"
#include "fc_controller.h"
#include "fc_state.h"

/*
 * Structure system state is stored in.
 */
static STATEOutputData stateData;

/*
 * Do not put these on stack
 */
//static long		timeLast=0;			/* Time Last in ms */
//static long		timeNow=0;			/* Time now in ms */
//static long		timeDelta=0;		/* Time delta in ms */
//static float	Pitch=0.0;				/* Pitch */
//static float	Roll=0.0;					/* Roll */
//static altitute_t	barAlt=0.0;	/* Barometer Altitude */
static compass_union compass;						/* compass union */
static accel_t_gyro_union accel_t_gyro;	/* gyrocope data */
static QuatStruct normAccel;		/* Normalized acceleration vector. */
static QuatStruct rawAccel;			/* Raw acceleration vector. */
static QuatStruct madQuat;			/* Structure holding the Madgwick output. */
static PWMoutput out;						/* PWM output structure */
uint8_t			frame=0;						/* Number of frames */

/*
 * Report Debug info in human readable format through the UART.
 */
void REPORTHuman(void) 
{

	/*
	 * Get the state of the quad.
	 */
	STATEGet(&stateData);

	/*
	 * Get input values for the 3 axis.
	 */
	MPU6050GetRawData(&accel_t_gyro);

	/*
	 * Get Compass data
	 */
	memset(&compass, 0, sizeof(compass));
	HMC5883GetData(&compass);
	
	/*
	 * Calculate 3 axis of acceleration.
	 * Take the accelerometer vector, and rotate it using the quaternion from madgwick
	 */
	rawAccel.w=0.0;
	rawAccel.x=accel_t_gyro.value.x_accel/819.2;
	rawAccel.y=-accel_t_gyro.value.z_accel/819.2;
	rawAccel.z=accel_t_gyro.value.y_accel/819.2;
	GENQuatRotate(&normAccel, &rawAccel, &madQuat);

	// Print quaternion terms
	UARTPrintf("\r\n\r\nQUAT  %8.3f %8.3f %8.3f %8.3f\r\n", q0, q1, q2, q3);
	//UARTPrintf("PITC  %d \r\n", (int)(quaternion_to_roll()*RADTODEG));
	//UARTPrintf("ROLL  %d \r\n", (int)(quaternion_to_pitch()*RADTODEG));
	UARTPrintf("PITC  %d \r\n", (int)(stateData.pitch*RADTODEG));
	UARTPrintf("ROLL  %d \r\n", (int)(stateData.roll*RADTODEG));
  UARTPrintf("YawV  %.2f \r\n", stateData.yawSpeed);
	UARTPrintf("COMP  %d %d %d \r\n",  compass.value.x_compass, compass.value.y_compass, compass.value.z_compass);
	UARTPrintf("ACCE  %d %d %d \r\n", accel_t_gyro.value.x_accel, accel_t_gyro.value.y_accel, accel_t_gyro.value.z_accel);

	//UARTPrintf("ALTK   %8.3f\n", kalAltStruct.xk_hatc[0]);
	UARTPrintf("ALTK  %8.3f\r\n", normAccel.y+GAccel);
	UARTPrintf("RECV     PITCH:%04d ROLL:%04d YAW:%04d THROTTLE:%04d \r\n", RECGetWidth(PITCH), RECGetWidth(ROLL), RECGetWidth(YAW), RECGetWidth(THROTTLE) );
	//UARTPrintf("RECV ms  PITCH:%04d ROLL:%04d YAW:%04d THROTTLE:%04d \r\n", RECGetWidthMs(PITCH), RECGetWidthMs(ROLL), RECGetWidthMs(YAW), RECGetWidthMs(THROTTLE) );

	// Print Motor Power distribution
	CONTROLGetMotorOut(&out);
	UARTPrintf("\r\n");
	UARTPrintf("1 %4d   %4d 3\r\n", out.m1, out.m3);
	UARTPrintf("       X\r\n");
	UARTPrintf("4 %4d   %4d 2\r\n", out.m4, out.m2);

	// Clear screen
	frame++;
	if(frame % 100 == 0) {
		 UARTPrintf("\033[2J\033[0;0f");
		 UARTPrintf("\033[%d;%df", 0, 0);
	} else {
		UARTPrintf( "\033[0;0H" ); // Move cursor to 0,0
	}

	//ledtoggle1();
}
