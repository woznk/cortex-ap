/*
 *
 * Copyright (c) 2013, Paul Honig & Peter Tambach
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the ETV.
 * 4. Neither the name of the ETV nor the
 *    names of its contributors may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY Paul Honig & Peter Tambach ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Paul Honig & Peter Tambach BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

/** A simple kalman filter example by Adrian Boeing 
  www.adrianboeing.com 
 */ 

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#include "fc_gen.h"
#include "fc_kalman.h"

/*
 * --- Kalman filter module  ----------------------------------------------------------------------------
 * Thanks to http://www.x-firm.com/?page_id=191
 */

/*
 * Initialize the Kalman structure.
 */
void KAL2Init(kalman2Struct *kalStruct)
{
	kalStruct->Q_angle  =  0.001;
	kalStruct->Q_gyro   =  0.003;
	kalStruct->R_angle  =  0.03;

	kalStruct->x_bias = 0;
	kalStruct->P_00 = 0;
	kalStruct->P_01 = 0;
	kalStruct->P_10 = 0;
	kalStruct->P_11 = 0;
}

/*
 * Insert Accelerometer Angle, and Gyroscope rate + time elapsed to get none-drifting angle data.
 * All input should be in Radiants.
 */
float KAL2Calculate(kalman2Struct *kalStruct, float newAngle, float newRate,int looptime) {
	float dt, y, S;
	float K_0, K_1;

	dt = looptime/1000.0;
	kalStruct->x_angle += dt * (newRate - kalStruct->x_bias);
	kalStruct->P_00 +=  - dt * (kalStruct->P_10 + kalStruct->P_01) + kalStruct->Q_angle * dt;
	kalStruct->P_01 +=  - dt * kalStruct->P_11;
	kalStruct->P_10 +=  - dt * kalStruct->P_11;
	kalStruct->P_11 +=  + kalStruct->Q_gyro * dt;

	y = newAngle - kalStruct->x_angle;
	S = kalStruct->P_00 + kalStruct->R_angle;
	K_0 = kalStruct->P_00 / S;
	K_1 = kalStruct->P_10 / S;

	kalStruct->x_angle +=  K_0 * y;
	kalStruct->x_bias  +=  K_1 * y;
	kalStruct->P_00 -= K_0 * kalStruct->P_00;
	kalStruct->P_01 -= K_0 * kalStruct->P_01;
	kalStruct->P_10 -= K_1 * kalStruct->P_00;
	kalStruct->P_11 -= K_1 * kalStruct->P_01;

	/* 
	 * When the angle is over 2*pi radiants, we start a zero again.
	 */
	if(kalStruct->x_angle < 0.0) {
		kalStruct->x_angle += 2*M_PI;
	}
	if(kalStruct->x_angle > 2*M_PI){
		kalStruct->x_angle -= 2*M_PI;
	}

	return kalStruct->x_angle;
}


/*
 * Initialize the Kalman 3 variable structure with sane starting values.
 */
void KAL3Init(kalman3Struct *kal)
{
	int i=0;
	int j=0;
	
	kal->xk_hatc[0]=0.0;
	kal->xk_hatc[1]=0.0;
	kal->xk_hatc[2]=0.0;

	//kal->Q;			/* Process Error Matrix */
	//kal->R;			/* Measurement Error Matrix */
	//kal->P;			/* Noise Matrix */
	
	// For now Q Process matrix low
	for(i=0; i<3; i++) {
		for(j=0; j<3; j++) {
			kal->Q[i][j]=0.01;
		}
	}
	kal->Q[0][0]=0.001;

	// For now R Measurement matrix avarage
	for(i=0; i<3; i++) {
		for(j=0; j<3; j++) {
			kal->R[i][j]=3.5;
		}
	}
	kal->R[1][0]=3.501;

	// For now P matrix starts at 0
	for(i=0; i<3; i++) {
		for(j=0; j<3; j++) {
			if (i==j) kal->P[i][j]=1.0;
			else kal->P[i][j]=0.0;
		}
	}
}

/*
 * Insert Acceleration of position or both to update Kalman Filter state and get new estimate out.
 * Model in this Kalman filter is based on Newtons laws of motion.
 * newPos in m
 * newAccel in m/s^2 (When no control input leave 0.0)
 * dt in ms
 */
static Matrix33 Hxa = {{0, 0, 0}, {0, 0, 0}, {0, 0, 1}};
static Matrix33 Hxpa = {{1, 0, 0}, {0, 0, 0}, {0, 0, 1}};	
static Matrix33 Pk;				// P Predicted (Predicten noise in the system)
static Matrix33 Sk;				// Innovation covariance
static Matrix33 Kk;				// Kalman Gain
static Matrix33 *Hx;			// Measurement matrix
static Matrix33 tmat1;		// temp
static Matrix33 tmat2;		// temp
static Matrix33 tmat3;		// temp
static Matrix31 xk_hatc; 	// Previous process state
static Matrix31 yk_hat;		// Difference between predicted and model
static Matrix31 tvec1;		// temp
void KAL3Calculate(kalman3Struct *kalStruct, float newPos, float newAccel, int looptime) 
{
	// When the position is provided the observation matrix gets amended
	if(newPos == 0.0) {
		Hx = &Hxa;
	} else {
		Hx = &Hxpa;
	}

	// Store measurements is vector
	Matrix31 zk = {newPos, 0, newAccel};

	// dt = looptime in seconds
	float dt = looptime/1000.0;

	// Initialize model Matrix
	Matrix33 F = {{1, dt, .5*dt*dt}, {0, 1, dt}, {0, 0, 1}};

	// Predict
	Matrix33v3Mul(F, kalStruct->xk_hatc, xk_hatc);

	// Pk     = F*Pk_*F' + Q;
	Matrix33Mul(F, kalStruct->P, tmat1); // F*Pk_
	Matrix33Trans(F, tmat2); // F'
	Matrix33Mul(tmat1, tmat2, tmat3); // (F*Pk_)*F'
	Matrix33Add(tmat3, kalStruct->Q , Pk); // (F*Pk_*F') + Q

	// yk_hat  = zk - Hx * xk_hat;
	Matrix33v3Mul(*Hx, xk_hatc, tvec1); // Hx * xk_hat
	Vector3Sub(zk, tvec1, yk_hat); // zk - (Hx * xk_hat_)
	
 	//   Sk      = Hx*Pk*Hx' + R;
	Matrix33Mul(*Hx, Pk, tmat1); // Hx*Pk
	Matrix33Trans(*Hx, tmat2); // Hx'
	Matrix33Mul(tmat1, tmat2, tmat3); // (Hx*Pk)*Hx'
	Matrix33Add(tmat3, kalStruct->R, Sk);

  //  Kk      = Pk * Hx' * inv(Sk);
	Matrix33Inv(Sk, tmat1); //inv(Sk)
	Matrix33Mul(Pk, tmat2, tmat3); // Pk * Hx'
	Matrix33Mul(tmat3, tmat1, Kk); // (Pk * Hx') * (inv(Sk))

  //  xk_hat_  = xk_hat + Kk*yk_hat;
	Matrix33v3Mul(Kk, yk_hat, tvec1); // Hx * yk_hat_
	Vector3Add(xk_hatc, tvec1, kalStruct->xk_hatc); // xk_hat + (Kk*yk_hat)

  //  Pk_      = (eye(3) - Kk*Hx)*Pk;
	Matrix33Mul(Kk, *Hx, tmat1); // Kk*Hx
	Matrix33Sub(MatrixEye33, tmat1, tmat2); // (eye(3) - Kk*Hx)
	Matrix33Mul(tmat2, Pk, kalStruct->P); // (eye(3) - Kk*Hx)*Pk
}

