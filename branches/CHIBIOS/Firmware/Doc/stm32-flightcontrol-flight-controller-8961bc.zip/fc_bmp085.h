/*
 *
 * Copyright (c) 2013, Paul Honig & Peter Tambach
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the ETV.
 * 4. Neither the name of the ETV nor the
 *    names of its contributors may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY Paul Honig & Peter Tambach ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Paul Honig & Peter Tambach BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

/*
 * Structure holding calibration data.
 */
typedef struct {
	short						ac1;
	short						ac2;
	short						ac3;
	unsigned short	ac4;
	unsigned short	ac5;
	unsigned short  ac6;
	short						b1;
	short						b2;
	short						mb;
	short						mc;
	short						md;
} BMP085CalData;

typedef struct {
	long		x1;
	long		x2;
	long		b5;
	long		temp;
	uint8_t oss;
} BMP085Temp;

/*
 * Get the calibration data.
 */
msg_t BMP085GetCalData(void);

/*
 * Get the pressure
 */
long BMP085GetPressure(void);

/*
 * Returns 1 when new data is available.
 */
uint8_t BMP085NewData(void);

/*
 * Initialize the BMP085 driver.
 */
void BMP085Init(void);

/*
 * Update pressure in register
 * This method should only be executed by the thread.
 */
void BMP085UpdatePressure(void);

/*
 * Get the current temperature
 */
short BMP085GetTemp(void);

/*
 * Take 20 samples, use them to calculate the variance in the measurements.
 */
float BMP085GetVariance(void);

