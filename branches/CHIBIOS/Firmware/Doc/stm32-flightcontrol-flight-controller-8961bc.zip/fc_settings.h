/*
 *
 * Copyright (c) 2013, Paul Honig & Peter Tambach
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the ETV.
 * 4. Neither the name of the ETV nor the
 *    names of its contributors may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY Paul Honig & Peter Tambach ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Paul Honig & Peter Tambach BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * PWM Receiver for STM32-FlightControl
 * File initiated on 08.08.13 by Piele, piele@creativeserver.net
 */

#ifndef FC_SETTINGS
#define FC_SETTINGS

/*
 * Enum indexing the settings
 */
typedef enum {
  type_b,  /* Byte */
  type_i,  /* Integer */
  type_f,  /* floating point */
} value_type;

/*
 * structure holding settings
 */
typedef struct {
  value_type type;
  union Value {
    uint8_t b;
    int     i;
    float   f;
  } value;
} setting_val;

/*
 * Add new settings here in the fc_settings_values.h file
 * the values can be set.
 */
enum settings_index {
  val_rec_min_pitch=0, /* rec = receiver */
  val_rec_max_pitch,
  val_rec_min_roll,
  val_rec_max_roll,
  val_rec_min_yaw,
  val_rec_max_yaw,
  val_rec_min_throt,
  val_rec_max_throt,
  val_gyro_x_fact,      /* To convert the gyroscope output accuratly to degrees */
  val_gyro_y_fact,
  val_gyro_z_fact,
  val_last_value,       /* Last value, used as a measurement for array length. */
	val_throt_cutoff,			/* Below this level of thrust no power to the engines. */
  val_x_cont_kp,        /* X PID controller kP                                 */
  val_y_cont_kp,        /* Y PID controller kP                                 */
  val_z_cont_kp,        /* Z PID controller Kp                                 */
};

/*
 * Get byte value setting
 */
uint8_t SETGetByte(enum settings_index index);

/*
 * Get byte value setting
 */
int SETGetInt(enum settings_index index);

/*
 * Get byte value setting
 */
float SETGetFloat(enum settings_index index);

#endif

