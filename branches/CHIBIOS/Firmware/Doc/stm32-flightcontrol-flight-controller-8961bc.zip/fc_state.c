/*
 *
 * Copyright (c) 2013, Paul Honig & Peter Tambach
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the ETV.
 * 4. Neither the name of the ETV nor the
 *    names of its contributors may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY Paul Honig & Peter Tambach ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Paul Honig & Peter Tambach BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */
#include "ch.h"
#include "hal.h"
#include <math.h>
#include <string.h>

#include "MadgwickAHRS.h"
#include "fc_gen.h"
#include "fc_mpu6050.h"
#include "fc_hmc5883.h"
#include "fc_kalman.h"
#include "MadgwickAHRS.h"
#include "fc_altitude.h"
#include "fc_state.h"

/*
 * Mutex locking multi threaded variables.
 */
static Mutex					statemtx; /* Mutex */

/*
 * Variables needed to calculate the yaw angle velocity.
 */
float			angles[10];
uint8_t		pointer;

/*
 * Structure system state is stored in.
 */
static STATEOutputData stateData;

/*
 * Kalman structures
 */
kalman3Struct kalAltStruct;

/*
 * Lowpass filter structure.
 */
LowPassStruct yawSpeedLowPass;

/*
 * Get angle error relative to ground plane in radiants
 */
static void STATEGroundAngle(float *x, float *y)
{
  /*
   * Since the X is corresponding with the craft orientation, put it through.
   */
  *x = quaternion_to_roll ();

  /*
   * The roll seems reverse, so putting it in reverse out.
   */
  *y = -quaternion_to_pitch ();
}

/*
 * Feed Madgwick filter
 */
static void STATEFeedMadgwick(accel_t_gyro_union *accel_t_gyro, compass_union *compass)
{
  float gyroDegX=0.0;
  float gyroDegY=0.0;
  float gyroDegZ=0.0;

  /* Calulation where the 0.000266 comes from :
   * 1000'/s range = +- 500'/s either way.
   * resolution is 16 2 complement so offective 2^15 one way
   * 500' / 2^15 = 0.015 '/step : Now for te degrees to Radiants
   * 0.01525  / 360 * 2M_PI = 0.000266 
   */
  gyroDegX=accel_t_gyro->value.x_gyro*0.000266;
  gyroDegY=accel_t_gyro->value.y_gyro*0.000266;
  gyroDegZ=-accel_t_gyro->value.z_gyro*0.000266;

  /*
   * Feed data to Madgwick filter
   */
  MadgwickAHRSupdate(
      gyroDegX, gyroDegY, gyroDegZ, // Gyroscope
      accel_t_gyro->value.x_accel,  accel_t_gyro->value.y_accel,  accel_t_gyro->value.z_accel, // Accelerometer
      -compass->value.y_compass, -compass->value.x_compass,  compass->value.z_compass); // Magnetometer
}

/*
 * STATEInit()
 */
void STATEInit(void)
{
  /*
   * Initialize Mutex.
   */
  chMtxInit(&statemtx); /* Mutex initialization before use */

  /*
   * Zero output struct.
   */
  memset(&stateData, 0, sizeof(STATEOutputData));

  /*
   * Initialize kalman structure.
   */
  KAL3Init(&kalAltStruct); // Altitude structure

	/*
	 * Initialize Yaw Speed low pass filter
	 */
	GENInitLowPass(3, &yawSpeedLowPass);
}

/*
 * Get Yaw or Z angle rotation speed.
 */
static float lastYawPos;
static float STATEGetYawSpeed(long timeDelta)
{
  float retval  = 0.0;
  float current = 0.0;
  float delta   = 0.0;

  /* 
   * Get current rotation position
   */
  current = quaternion_to_yaw();

  /*
   * Calculate difference
   */
  delta = GENDifAngDeg(current, lastYawPos);


  /* 
   * delta to speed 
   */
  retval = (delta*1000)/timeDelta;

	/*
	 * Apply low pass filter
	 */
	retval = GENLowPass(retval, &yawSpeedLowPass);

  /* 
   * Store current pos as previous.
   */
  lastYawPos = current;

  return retval;
}


/*
 * Updates the vehicle state using the latest measurements.
 */
static long		timeLast=0;		/* Last Time the function was called in ms */
altitute_t		barAlt=0.0;				/* Barometer Altitude		*/
void STATEUpdate()
{
  QuatStruct normAccel; /* Normalized acceleration vector. */
  accel_t_gyro_union accel_t_gyro; /* gyrocope data */
  compass_union compass;
  long				timeDelta=0;		/* Time delta in ms			*/
  long				timeNow=0;			/* Time now ms					*/
  QuatStruct  madQuat;				/* Madgwick quaternion	*/
  QuatStruct  rawAccel;				/* Madgwick quaternion	*/
  float				pitch;					/* Pitch Angle					*/
  float				roll;						/* Roll Angle						*/
  float       yawSpeed;       /* Yaw rotation speed   */

  /*
   * Calculate the time passed since the last call to this function.
   */
  timeNow = MS2ST(chTimeNow());
  timeDelta = timeNow - timeLast;
  timeLast=timeNow;

  /*
   * Get input values for the 3 axis.
   */
  MPU6050GetRawData(&accel_t_gyro);

  /*
   * Get Compass data
   */
  memset(&compass, 0, sizeof(compass));
  HMC5883GetData(&compass);

  /*
   * Feed data to Madgwick filter.
   */
  STATEFeedMadgwick(&accel_t_gyro, &compass);
  madQuat.w=q0;
  madQuat.x=q1;
  madQuat.z=q2;
  madQuat.y=q3;

  /*
   * Normalize the quaternion
   */
  GENQuatNormalize(&madQuat);

  /*
   * Calculate error angle for x and z axis against leveled plane
   * Take a vector along the X and one across the y vector, translate it using the quaternion from
   * the Madgwick filter, than calculate the angle with the ground-plane
   */
  STATEGroundAngle(&roll, &pitch);

	/*
	 * Normalize the vector relative to the horizon and north.
	 */
	rawAccel.w=0.0;
	rawAccel.x=accel_t_gyro.value.x_accel/819.2;
	rawAccel.y=-accel_t_gyro.value.z_accel/819.2;
	rawAccel.z=accel_t_gyro.value.y_accel/819.2;
	GENQuatRotate(&normAccel, &rawAccel, &madQuat);

	/*
	 * Use Kalman filtering to compensate the hight of the vehicle
	 * Update when new barometer pressure has arrived, and update when new accel data is in.
	 */
	if(ALTNewData() == 0){
		barAlt =	0.0; // When no new data imput 0.0 only input altitude data when new barometer values are present.
	} else {
		barAlt =	ALTGetAlt();
	}
	KAL3Calculate(&kalAltStruct, barAlt, normAccel.y+GAccel, timeDelta);

	/*
	 * Lock mutex as we are going to change the structure.
	 */
	chMtxLock(&statemtx);

  /* 
   * Get horizontal rotation speed
   */
  yawSpeed = STATEGetYawSpeed(timeDelta);

	/*
	 * Store results in structs.
	 */
	stateData.roll			= roll;
	stateData.pitch			= pitch;
	stateData.alt				= barAlt;
	stateData.orient.x	= madQuat.x;
	stateData.orient.y	= madQuat.y;
	stateData.orient.z	= madQuat.z;
	stateData.orient.w	= madQuat.w;
	stateData.time			= timeLast;
  stateData.yawSpeed  = yawSpeed;
	
	chMtxUnlock();
}

/* 
 * Get the Z angle rotation speed.
 */


/*
 * Get state structure.
 * Containing the heading (quaternion) and deveations from ground-angle.
 */
void STATEGet(STATEOutputData *out)
{
	/*
	 * Lock mutex as we are going to change the structure.
	 */
	chMtxLock(&statemtx);
	
	/*
	 * Copy state to the output structure.
	 */
	memcpy(out, &stateData, sizeof(STATEOutputData));

	memset(angles, 0, sizeof(float)*10);
	pointer = 0;

	chMtxUnlock();
}

