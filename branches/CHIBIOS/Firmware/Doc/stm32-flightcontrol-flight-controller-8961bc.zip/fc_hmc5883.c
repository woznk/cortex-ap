/*
 *
 * Copyright (c) 2013, Paul Honig & Peter Tambach
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the ETV.
 * 4. Neither the name of the ETV nor the
 *    names of its contributors may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY Paul Honig & Peter Tambach ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Paul Honig & Peter Tambach BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "ch.h"
#include "hal.h"
#include <string.h>
#include <math.h>

#include "fc_hmc5883.h"
#include "fc_uart.h"
#include "fc_i2c.h"
#include "fc_mpu6050.h"

/*
 * Structure to store compass data.
 */
compass_union compass;

/*
 * Mutex locking multi threaded variables.
 */
static Mutex					hmc5883mtx; /* Mutex */

/*
 * Swap all high and low bytes.
 * After this, the registers values are swapped,
 * so the structure name like x_accel_l does no
 * longer contain the lower byte.
 */
static uint8_t swap;
#define SWAP(x,y) swap = x; x = y; y = swap

/*
 * HMC5883 registers
 */
#define HMC5883_CONFIG_REG_A						0x00
#define HMC5883_CONFIG_REG_B						0x01
#define HMC5883_MODE_REG								0x02
#define HMC5883_DATA_OUT_X_MSB_REG			0x03
#define	HMC5883_DATA_OUT_X_LSB_REG			0x04
#define HMC5883_DATA_OUT_Z_MSB_REG			0x05
#define HMC5883_DATA_OUT_Z_LSB_REG			0x06
#define HMC5883_DATA_OUT_Y_MSB_REG      0x07
#define HMC5883_DATA_OUT_Y_LSB_REG      0x08
#define HMC5883_STATUS_REG							0x09
#define HMC5883_IDENT_REG_A							0x0a
#define HMC5883_IDENT_REG_B							0x0b
#define HMC5883_IDENT_REG_C							0x0c

/*
 * Debug Settings
 */
#define FC_HMC5883_DEBUG

#define HMC5883_I2C_ADDRESS 0x3C>>1


/*
 * Set Config register A
 */
static uint8_t HMC5883SetConfigRegA(void)
{
	uint8_t retval=0;
	uint8_t tx_buf[2];

	/* 
	 * Set :
	 * 8 Samples per measurement
	 * 75 samples per second
	 * Normal measuring configuration
	 */
	tx_buf[0]=HMC5883_CONFIG_REG_A;
	tx_buf[1]=0b01111000;

	retval = I2CWrite(HMC5883_I2C_ADDRESS, tx_buf, 2);
#ifdef FC_HMC5883_DEBUG
	if(retval != RDY_OK) {
		UARTPrintf("HMC5883_CONFIG_REG_A I2C Error\r\n");
	}
#endif
	chThdSleepMilliseconds(10);

	return retval;
}

/*
 * Set Config register B
 */
static uint8_t HMC5883SetConfigRegB(void)
{
	uint8_t retval=0;
	uint8_t tx_buf[2];

	/* 
	 * Set :
	 * }- 1.3 Ga Gain
	 */
	tx_buf[0]=HMC5883_CONFIG_REG_B;
	tx_buf[1]=0b00100000;

	retval = I2CWrite(HMC5883_I2C_ADDRESS, tx_buf, 2);
#ifdef FC_HMC5883_DEBUG
	if(retval != RDY_OK) {
		UARTPrintf("HMC5883_CONFIG_REG_B I2C Error\r\n");
	}
#endif
	chThdSleepMilliseconds(10);

	return retval;
}

/*
 * Set Config register B
 */
static uint8_t HMC5883SetModeReg(void)
{
	uint8_t retval=0;
	uint8_t tx_buf[2];

	/* 
	 * Set :
	 * Continuous-Measurement Mode.
	 */
	tx_buf[0]=HMC5883_MODE_REG;
	tx_buf[1]=0b00000000;

	retval = I2CWrite(HMC5883_I2C_ADDRESS, tx_buf, 2);
#ifdef FC_HMC5883_DEBUG
	if(retval != RDY_OK) {
		UARTPrintf("HMC5883_MODE_REG I2C Error\r\n");
	}
#endif
	chThdSleepMilliseconds(10);

	return retval;
}

/*
 * Initialize the BMP085 driver.
 */
uint8_t HMC5883Init(void)
{
	uint8_t retval=0;

	/*
	 * Setup the config registers.
	 */
	retval  = HMC5883SetConfigRegA();
	retval |= HMC5883SetConfigRegB();

	/*
	 * Setup operation mode.
	 */
	retval |= HMC5883SetModeReg();

	/*
	 * Initialize Mutex
	 */
	chMtxInit(&hmc5883mtx); /* Mutex initialization before use */

	return retval;
}

/*
 * Get Compass data
 */
void HMC5883GetData(compass_union *compassPtr)
{
	chMtxLock(&hmc5883mtx);
	memcpy(compassPtr, &compass, sizeof(compass_union));
	chMtxUnlock();
}

/*
 * Update sensor data.
 * This method should only be called by the update thread.
 */
void HMC5883Update(void)
{
	uint8_t retval=0;
	uint8_t tx_buf[1];

	chMtxLock(&hmc5883mtx);
	tx_buf[0]=HMC5883_DATA_OUT_X_MSB_REG;
	retval = I2CRead(HMC5883_I2C_ADDRESS, tx_buf, 1, (uint8_t *) &compass, (uint8_t) sizeof(compass_union));
	chMtxUnlock();

#ifdef FC_HMC5883_DEBUG
	if(retval != RDY_OK) {
		UARTPrintf("MPU6050_ACCEL_XOUT_H I2C Error\r\n");
	}
#endif

	/*
	 * Fix the byte ordering
	 */
	chMtxLock(&hmc5883mtx);
	SWAP (compass.reg.x_compass_h, compass.reg.x_compass_l);
	SWAP (compass.reg.y_compass_h, compass.reg.y_compass_l);
	SWAP (compass.reg.z_compass_h, compass.reg.z_compass_l);

	/*
	 * Calculate the compass heading compensated for angle offset.
	 */
	chMtxUnlock();
}

