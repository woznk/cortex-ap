/*
 *
 * Copyright (c) 2013, Paul Honig & Peter Tambach
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the ETV.
 * 4. Neither the name of the ETV nor the
 *    names of its contributors may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY Paul Honig & Peter Tambach ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Paul Honig & Peter Tambach BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "ch.h"
#include "hal.h"
#include "pwm4.h"

#include "fc_gen.h"
#include "fc_uart.h"
#include "fc_gpio.h"
#include "fc_ext.h"
#include "fc_i2c.h"
#include "fc_spi.h"

#ifdef USE_BMP085 // Using BMP085 pressure sensor
#include "fc_bmp085.h"
#endif
#ifdef USE_MS5611 //  Using MS5611 pressure sensor
#include "fc_ms5611.h"
#endif

#include "fc_kalman.h"
#include "fc_mpu6050.h"
#include "fc_hmc5883.h"
#include "fc_threads.h"
#include "fc_em411.h"
#include "fc_controller.h"
#include "fc_receiver.h"
#include "fc_pwm.h"
#include "fc_stickcom.h"
#include "fc_report.h"
#include "fc_altitude.h"
#include "fc_state.h"
#include "MadgwickAHRS.h"

#include <stdio.h>
#include <string.h>
#include <math.h>

/*
 * Coordinates to my parents house as test :)
 */
#define TEST_LAT	52.492913
#define TEST_LONG	 4.592467

/*
 * Dummy abort symbol, need for newlib
 * Added this to support the official ARM toolchain
 * https://launchpad.net/gcc-arm-embedded
 */
void abort(void){while(1==1){}}

#if 0
/*
 * Execute calibration cycle
 */
static void calibration(void)
{
	accel_gyro_calibration *calivalue;

	/*
	 * Do Calibration
	 */
	calivalue = MPU6050GetCalibrationValues();
	UARTPrintf("Accel X :%hd\r\n", calivalue->x_accel);
	UARTPrintf("Accel Y :%hd\r\n", calivalue->y_accel);
	UARTPrintf("Accel Z :%hd\r\n", calivalue->z_accel);
	UARTPrintf("Gyro  X :%hd\r\n", calivalue->x_gyro);
	UARTPrintf("Gyro  Y :%hd\r\n", calivalue->y_gyro);
	UARTPrintf("Gyro  Z :%hd\r\n", calivalue->z_gyro);

	chThdSleepMilliseconds(100000);
}
#endif

/*
 * Application entry point.
 */
int main(void) {
	//BMP085Temp *temp=NULL;
	//short			  temp=0;
	//long				pressure=0;
	//float				alt=0.0;
	//accel_t_gyro_union accel_t_gyro; // obsolete
	//compass_union compass;
	//MPU6050OutputData gyroData;
	//ControlStruct	control;
	//EM411FixData gpsFix;
	//EM411CourseSpeed gpsCs;
	//EM411Coords	here;
	//EM411Coords	there;
	//PWMoutput		out;
	//float dist=0.0;
	//float angle=0.0;
	//float gyroDegX=0.0;
	//float gyroDegY=0.0;
	//float gyroDegZ=0.0;

	//float	variance=0.0;

	/*
	 * Setup coordinates to there place.
	 */
	//there.decLat=TEST_LAT;
	//there.decLong=TEST_LONG;

	/*
	 * Remapping the PWM out ports before initializing Chibios.
	 * Full Remap TIM3 to PC6-9
	 */
	//GPIO_PinRemapConfig(GPIO_FullRemap_TIM3, ENABLE);   
	//RCC->APB2ENR |=  1 <<  0;
	//AFIO->MAPR |= 0x00000C00;		/* Remap Timer 3 to the remap ports */


  /*
   * System initializations.
   * - HAL initialization, this also initializes the configured device drivers
   *   and performs the board-specific initializations.
   * - Kernel initialization, the main() function becomes a thread and the
   *   RTOS is active.
   */
  halInit();
  chSysInit();

	/*
	 * Initialize peripherals
	 */
	UARTInit();
	EXTInit();
	PWMInit();
	I2CInit();
	pwm4Init();
	RECInit();
	SPIInit();
	STATEInit();
	CONTROLInit();
  STCInit();

	/*
	 * Starts the transmission, it will be handled entirely in background.
	 */
	UARTPrintf("Starting...\r\n");

	/*
	 * Device initialization
	 */
#ifdef USE_BMP085
	UARTPrintf("Initializing BMP085\r\n");
	BMP085Init();
#endif
#ifdef USE_MS5611
	UARTPrintf("Initializing MS5611\r\n");
	MS5611Init();
#endif
	UARTPrintf("Initializing MPU6050\r\n");
	MPU6050Init();
	UARTPrintf("Initializing HMC5883\r\n");
	HMC5883Init();
//	UARTPrintf("Initializing EM411\r\n");
//	EM411Init();
	chThdSleepMilliseconds(5000);
//

	/*
	 * Starting threads
	 */
	startThreads();

#if 0
	/*
	 * Provide Sensor calibration values.
	 */
	calibration();
#endif

	/*
	 * Clear screen
	 */
	UARTPrintf( "\033[2J" );


  /*
   * Normal main() thread activity, in this demo it does nothing.
   */
  while (TRUE) {
		/*
		 * Get data
		 */
		REPORTHuman();

		/*
		 * Wait a while between reporting
		 */
    chThdSleepMilliseconds(25);
  }

 // return 0;
}
