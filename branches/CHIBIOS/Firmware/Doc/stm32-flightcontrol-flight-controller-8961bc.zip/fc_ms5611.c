/*
 *
 * Copyright (c) 2013, Paul Honig & Peter Tambach
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the ETV.
 * 4. Neither the name of the ETV nor the
 *    names of its contributors may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY Paul Honig & Peter Tambach ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Paul Honig & Peter Tambach BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */
#include "ch.h"
#include "hal.h"

#include "fc_ms5611.h"

#ifdef MS5611_I2C_BUS
#include "fc_i2c.h"
#endif

/*
 * Interface on AQ32 board :
 * interface	: I2C
 * CSB				: High
 */

#ifdef MS5611_I2C_BUS
/*
 * I2C BUS address
 */
#define MS5611_I2C_ADDR 0b1110110

#endif


/*
 * Driver internal value
 */
static Mutex							ms5611mtx; /* Mutex */
static ms5611_pressure_t	ms5611cur=0;
static uint8_t						ms5611new=0;

/*
 * Table of commands.
 */
#define MS5611_COM_RESET			0x1E
#define MS5611_COM_D1_256			0x40
#define MS5611_COM_D1_512			0x42
#define MS5611_COM_D1_1024		0x44
#define MS5611_COM_D1_2048		0x46
#define MS5611_COM_D1_4096		0x48
#define MS5611_COM_D2_256			0x50
#define MS5611_COM_D2_512			0x52
#define MS5611_COM_D2_1024		0x54
#define MS5611_COM_D2_2048		0x56
#define MS5611_COM_D2_4096		0x58
#define MS5611_COM_ADC_READ		0x00
#define MS5611_COM_PROM_READ	0xA0


/* 
 * Callibration values from eprom of device.
 */
static uint16_t calval[6];

/*
 * Send command to MS5611
 */
static msg_t MS5611SendCommand(uint8_t command)
{
#ifdef MS5611_I2C_BUS
	msg_t retval=0;

	retval = I2CWrite(MS5611_I2C_ADDR, &(command), 1);

	return retval;
#endif
}

/*
 * Read value from 5611
 * Read data is stored in buffer, Read status returned
 */
static msg_t MS5611ReadRegister(uint8_t command, uint8_t *buf, uint8_t size)
{
#ifdef MS5611_I2C_BUS
	msg_t retval=0;

	retval = I2CRead(MS5611_I2C_ADDR, &(command), 1, buf, size);

	return retval;
#endif
}

/*
 * Read Eprom value
 *
 */
static uint8_t MS5611ReadEprom(uint8_t regNum, uint16_t *buf)
{
	uint8_t	retval=0;
	uint8_t com=0;

	/*
	 * Calculate command to send.
	 */
	com = MS5611_COM_PROM_READ | (regNum << 1);

	/*
	 * Send command.
	 */
	retval = MS5611ReadRegister(com, (uint8_t*) buf, 2);

	/*
	 * return bytes read.
	 */
	return retval;
}


/*
 * Get Callibration values. 
 */
void MS5611GetCalValues(void)
{
	uint8_t loop=0;

	/* 
	 * Send read commands for PROM Read 0xA1 - 0xA6.
	 * Which will read rom values 1 to 6.
	 */
	for(loop=0; loop < 6; loop++){
		// TODO When returned value != 2 panic
		MS5611ReadEprom(loop+1, calval+loop);
	}

#ifdef MS5611_TESTDATA
	calval[0] = 40127;
	calval[1] = 36924;
	calval[2] = 23317;
	calval[3] = 23282;
	calval[4] = 33464;
	calval[5] = 28312;
#endif

}

/*
 * Send reset to MS5611
 */
void MS5611Reset(void)
{
	/* Send 0x1E (reset) to MS5611. */
	MS5611SendCommand(MS5611_COM_RESET);
}

/*
 * Initialize the MS5611 chip
 */
void MS5611Init(void)
{
	/* Initialize Mutex */
	chMtxInit(&ms5611mtx); /* Mutex initialization before use */

	/* After poweron the device needs a reset. */
	MS5611Reset();

	/* Read the Eprom to get callibration data. */
	MS5611GetCalValues();
}

/*
 * Get the uncompensated digital pressure value.
 */
static uint32_t MS5611GetD1(void)
{
	uint32_t d1=0;

	/* Convert D1 (OSR=4096) 0x48 */
	MS5611SendCommand(MS5611_COM_D1_4096);

	/* Sleep for 8.22 ms */
	// TODO implement sleep

	/* Read coversion result */
	MS5611ReadRegister(MS5611_COM_ADC_READ, (uint8_t*) &d1, 4);

#ifdef MS5611_TESTDATA
	d1 = 9085466;
#endif

	return d1;
}

/*
 * Get the uncompensated digital tempreture value.
 */
static uint32_t MS5611GetD2(void)
{
	uint32_t d2=0;

	/* Convert D2 (OSR=4096) 0x58 */
	MS5611SendCommand(MS5611_COM_D2_512);

	/* Sleep for 1.06 ms */
	// TODO implement sleep

	/* Read coversion result */
	MS5611ReadRegister(MS5611_COM_ADC_READ, (uint8_t*) &d2, 4);

#ifdef MS5611_TESTDATA
	d2 = 8569150;
#endif

	return d2;
}

/*
 * Use Rom data and d1 + d2 to calculate the pressure.
 */
static ms5611_pressure_t MS5611GetValue(void)
{
	uint32_t dt=0;
	uint32_t d1=0;
	uint32_t d2=0;
	uint64_t off=0;
	uint64_t off2=0;
	ms5611_pressure_t retval=0;
	uint64_t sens=0;
	uint64_t sens2=0;
	uint32_t t2=0;
	uint32_t temp=0;

	/* Get digital values */
	d1 = MS5611GetD1();
	d2 = MS5611GetD2();

	/* Difference between actual and reference temperature */
	dt = d2 - (calval[4] * 256);
	/* Actual temperature (-40...85°C with 0.01°C resolution) */
	temp = 2000 + (dt * calval[5]) / 8388608;

	/* Second order temperature compensation. */
	if(temp < 2000) {
		/* When the temperature is lower than 20'C */
		t2		= (dt*dt) / 2147483648;
		off2	= 5*(temp-2000)*(temp-2000)/2;
		sens2 = 5*(temp-2000)*(temp-2000)/4; 
	}
	if(temp < 1500) {
		/* When the temperature is lower than 15'C */
		off2	= off2 + 7*(temp+1500)*(temp+1500);
		sens2 =	sens2 + 11*(temp+1500)*(temp+1500)/2;
	}

	/* Integrate first and second order temperature correction. */
	temp = temp - t2;
	off = off - off2;
	sens = sens - sens2;

	/* Offset at actual temperature */
	off = calval[1] * 65536 + (calval[3] * dt) / 128;
	/* Sensitivity at actual temperature */
	sens = calval[0] * 32768 + (calval[2] * dt) / 256;
	/* Temperature compensated pressure (10...1200mbar with * 0.01mbar resolution) */
	retval = (d1 * sens / 2097152 - off) / 32768;

	return retval;
}

/*
 * Update pressure in register
 */
void MS5611UpdatePressure(void)
{
	chMtxLock(&ms5611mtx);
	ms5611cur = MS5611GetValue();
	ms5611new=1;
	chMtxUnlock();
}

/*
 * Returns 1 when new data is available.
 */
uint8_t MS5611NewData(void)
{
	uint8_t temp=0;

	chMtxLock(&ms5611mtx);
	temp=ms5611new;
	/*
	 * Reset new data flag
	 */
	ms5611new=0;	
	chMtxUnlock();
	return temp;
}

/*
 * Get the last pressure
 */
ms5611_pressure_t MS5611GetPressure(void)
{
	ms5611_pressure_t retval;
	chMtxLock(&ms5611mtx);
	retval = ms5611cur;
	chMtxUnlock();
	return retval;
}

