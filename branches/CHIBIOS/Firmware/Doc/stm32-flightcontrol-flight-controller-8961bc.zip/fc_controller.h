/*
 *
 * Copyright (c) 2013, Paul Honig & Peter Tambach
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the ETV.
 * 4. Neither the name of the ETV nor the
 *    names of its contributors may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY Paul Honig & Peter Tambach ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Paul Honig & Peter Tambach BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

/*
 * Structure to hold output values in us (microseconds)
 * The 'ON' period of the signal should remain between 1000 and 2000 us.
 * The PWM signal period will be 1/200 second.
 */
typedef struct {
	uint16_t m1; /* Motor 1 front left */
	uint16_t m2; /* Motor 2 front right */
	uint16_t m3; /* Motor 3 back left */
	uint16_t m4; /* Motor 4 back right */
} PWMoutput;

/*
 * Controller input values.
 */
typedef struct {
	int power;	/* Input power (the amount of thrust */
	int x;			/* X correction factor */
	int y;			/* Y correction factor */
	int z;			/* Z correction factor */
} ControlStruct;

/*
 * Initialize controller.
 */
void CONTROLInit(void);

/*
 * Loop to update the PID output towards the PWM module.
 */
void CONTROLUpdate(void);

/*
 * Get results PID out.
 */
void CONTROLGetOut(ControlStruct *out);

/*
 * Get current motor pwm output state.
 */
void CONTROLGetMotorOut(PWMoutput *out);

/*
 * Get angle error relative to ground plane in radiants
 */
void CONTROLGroundAngle(QuatStruct *rot, float *x, float *z);
