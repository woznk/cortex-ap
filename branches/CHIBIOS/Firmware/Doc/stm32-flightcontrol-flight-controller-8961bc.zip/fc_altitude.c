/*
 *
 * Copyright (c) 2013, Paul Honig & Peter Tambach
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the ETV.
 * 4. Neither the name of the ETV nor the
 *    names of its contributors may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY Paul Honig & Peter Tambach ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Paul Honig & Peter Tambach BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */
#include <stdio.h>
#include <stdint.h>

#ifdef USE_BMP085 // Using BMP085 sensor
#include "fc_bmp085.h"
#endif
#ifdef USE_MS5611 // Using MS5611 Sensor
#include "fc_ms5611.h"
#endif

#include "fc_altitude.h"

/*
 * Average of 10 - 0 altitude measurements.
 */
static alt_pressure_t p0;

/*
 * Set p0 reference pressure
 * Take 10 measurements, store them as p0
 */
void ALTInit(void)
{
	uint8_t						loop=0;
	uint64_t					total=0;

	for(loop=0; loop<10; loop++){
#ifdef USE_MS5611
		total += MS5611GetPressure();
		while(MS5611NewData() == 0); // Spinlock for new data
#endif
#ifdef USE_BMP085
		total += BMP085GetPressure();
		while(BMP085NewData() == 0); // Spinlock for new data
#endif
	}
	p0=total/10;
}


/*
 * Take new measurement, and calculate hight difference.
 * 1 hPa = 0.001 bar = 8.3 meters at sealevel
 * 0.00001 bar -> 8.3 cm -> 0.083 m
 * This function returns altitude in meters
 */
altitute_t ALTGetAlt(void)
{
	altitute_t				alt=0.0;

#ifdef USE_MS5611
	ms5611_pressure_t delta=0;
	ms5611_pressure_t	now=0;

	/* Measure pressure */
	now = MS5611GetPressure();

	/* Difference */
	delta = now - p0;

	/*
	 * On sea level 1 millibar equals around 8.3 meters, because quadcopters will not exceed 100 meters.
	 * This estimate is good enough to calculate the high of the vehicle. 
	 */
	alt = delta * 0.083;
#endif
#ifdef USE_BMP085
	long	p=0;
	
	/*
	 * Get pressure
	 */
	p = BMP085GetPressure();
	//p = BMP085GetValue();

	/*
	 * Calculate Altitude in meters
	 */
	//alt = 44330*pow(1-((float)p/(float)bmp085p0),(1/5.255));
	alt = (bmp085p0-p)/100.0*8.43;
	alt = floorf(alt*10)/10;
#endif

	return alt;
}

/*
 * Test if new altitude data is available.
 */
uint8_t ALTNewData(void)
{
	uint8_t retval=0;
#ifdef USE_BMP085
	retval = BMP085NewData();
#endif	
#ifdef USE_MS5611
	retval = MS5611NewData();
#endif
	return retval;
}
