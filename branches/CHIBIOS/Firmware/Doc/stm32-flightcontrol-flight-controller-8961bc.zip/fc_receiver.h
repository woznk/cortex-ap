/*
 *
 * Copyright (c) 2013, Paul Honig & Peter Tambach
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the ETV.
 * 4. Neither the name of the ETV nor the
 *    names of its contributors may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY Paul Honig & Peter Tambach ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Paul Honig & Peter Tambach BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * PWM Receiver for STM32-FlightControl
 * File initiated on 08.08.13 by Piele, piele@creativeserver.net
 */

#ifndef REVEIVER_H
#define RECEIVER_H

/*
 * Structure names receiver channels.
 */
typedef enum {
	PITCH=0,
	ROLL,
	YAW,
	THROTTLE,
	FUNC1,
	FUNC2,
	FUNC3,
	FUNC4
} rec_names_t;

/*
 * Initialize the receiver input
 */
void ICURevrInit(void);

/*
 * Pulse width type
 */
typedef uint16_t rec_width_t;

/*
 * Initialize the PWM output
 */
void RECInit(void);

/*
 * Returns walue of the last pulse width.
 */
rec_width_t RECGetWidth(rec_names_t name);

/*
 * Returns walue of the last pulse width.
 */
rec_width_t RECGetWidthMs(rec_names_t name);

/*
 * Change translation table.
 */
void RECSetTransTable(rec_names_t name, uint16_t channel);

/*
 * Change min value for channel.
 */
void RECSetMinPWM(rec_names_t name, uint16_t min);

/*
 * Change max value for channel.
 */
void RECSetMaxPWM(rec_names_t name, uint16_t max);

/*
 * Return Receiver mid signal.
 */
rec_width_t RECGetMiddle(void);

#endif
