/*
 *
 * Copyright (c) 2013, Paul Honig & Peter Tambach
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the ETV.
 * 4. Neither the name of the ETV nor the
 *    names of its contributors may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY Paul Honig & Peter Tambach ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Paul Honig & Peter Tambach BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

/*
 * Return smallest float value
 */
float minabsf(float val1, float val2);

/*
 * Calculate the shortest angle.
 * For 2 angles in radiants 
 */
float GENCalcShortestAngle(float target, float pos);

/*
 * Calculate the mean of the mean of a float array
 */
float GENCalcVariance(float col[], size_t size);

/*
 * Variance test
 */
void GENTestVariance(void);

/*
 * Quaternion structure
 */
typedef struct {
	float x;
	float y;
	float z;
	float w;
} QuatStruct;

/*
 * Vector Structure 3
 */
typedef struct {
	float x;
	float y;
	float z;
} VectStruct3;

/*
 * Lowpass max 10 smoothing positions
 */
typedef struct {
  int   order;
  int   current;
  float x[10];
} LowPassStruct;

/*
 * 3x1 Matrix
 */
typedef float Matrix31[3];

/*
 * 3x3 Matrix
 */
typedef float Matrix33[3][3];

/*
 * Physical Constants (More or less)
 */
#define GAccel	9.81

/*
 * ========================================
 * Quaternion Routines
 * ========================================
 */

#define DEGTORAD ((2*M_PI)/360)
#define RADTODEG (360/(2*M_PI))

/*
 * Normalize quaternion
 */
int GENQuatNormalize(QuatStruct *quad);

/*
 * Rotate Quaternion quad1 over quad2 store result in quad3.
 */
void GENQuatRotate(QuatStruct *res, QuatStruct *q1, QuatStruct *q2);

/*
 * Multiply to quaternions
 */
void GENQuatMul(QuatStruct *res, QuatStruct *q1, QuatStruct *q2);

/*
 * Get conjugate of a quaternion.
 */
void GENQuatConj(QuatStruct *res, QuatStruct *q);


/* 
 * ========================================
 * Matrix functions
 * ========================================
 */

/*
 * Multiply a 3x3 matrix by a 3x1 Vector
 * Result is stored in vectout
 */
void Matrix33v3Mul(Matrix33 mat, Matrix31 vecin, Matrix31 vecout);

/*
 * Multiply a 3x3 matrix by a 3x3 matrix
 * Result is stored in matout
 */
void Matrix33Mul(Matrix33 mat1, Matrix33 mat2, Matrix33 matout);

/*
 * Add two 3x3 matrices
 * Result is stored in vectout
 */
void Matrix33Add(Matrix33 mat1, Matrix33 mat2, Matrix33 matout);

/*
 * Substract two 3x3 matrices
 * Result is stored in vectout
 */
void Matrix33Sub(Matrix33 mat1, Matrix33 mat2, Matrix33 matout);

/*
 * Multiply a 3x3 matrix by a scalar
 * Result is stored in vectout
 */
void Matrix33ScalMul(Matrix33 mat, float scal, Matrix33 matout);

/*
 * Multiply a 3x3 matrix by a scalar
 * Result is stored in vectout
 */
void Matrix33ScalAdd(Matrix33 mat, float scal, Matrix33 matout);

/*
 * Transpose a 3x3 Matrix
 */
void Matrix33Trans(Matrix33 matin, Matrix33 matout);

/*
 * Get the determinant of a 3x3 Matrix.
 */
float Matrix33Det(Matrix33 mat);

/*
 * Get the inverse matrix of a 3x3 matrix.
 */
void Matrix33Inv(Matrix33 in, Matrix33 out);

extern Matrix33 MatrixEye33;
/*
 * Add a 3 vector to a 3 vector
 * Result is stored in vectout
 */
void Vector3Add(Matrix31 vecin1, Matrix31 vecin2, Matrix31 vecout);

/*
 * Add a 3 vector to a 3 vector
 * Result is stored in vectout
 */
void Vector3Sub(Matrix31 vecin1, Matrix31 vecin2, Matrix31 vecout);

/*
 * Generic macro's
 */

/* 
 * constrain values to range.
 */
#define GENconstrain(v, vmin, vmax){																					\
	if (v <= vmin)																															\
		{ v = vmin; }																															\
	else if (v >= vmax)																													\
		{ v = vmax; }																															\
}

/*
 * When skipping cycles.
 */
#define nop() \
	   asm volatile ("nop")

/*
 * Init lowpass
 */
void GENInitLowPass(int order, LowPassStruct *lowpass);

/*
 * Lowpass filter max order 10
 */
float GENLowPass(float val, LowPassStruct *lowpass);

/* 
 * Calculate the difference between to angles in degrees. 
 */
float GENDifAngDeg(float x, float y);

/* 
 * Calculate shortest angle between 2 angles on cirkel
 * in radians.
 */
float GENDifAngRad(float x, float y);
