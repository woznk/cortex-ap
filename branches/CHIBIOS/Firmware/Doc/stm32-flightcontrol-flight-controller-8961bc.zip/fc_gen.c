/*
 *
 * Copyright (c) 2013, Paul Honig & Peter Tambach
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *    This product includes software developed by the ETV.
 * 4. Neither the name of the ETV nor the
 *    names of its contributors may be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY Paul Honig & Peter Tambach ''AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL Paul Honig & Peter Tambach BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */


#include "ch.h"
#include "hal.h"

#include <math.h>

#include <string.h>

#include "fc_uart.h"
#include "fc_gen.h"

/*
 * Return smallest absolute float value
 */
float minabsf(float val1, float val2)
{
	if(fabs(val1) < fabs(val2)) {
		return val1;
	} else {
		return val2;
	}
}

/*
 * Calculate the shortest angle.
 * For 2 angles in radiants 
 */
float GENCalcShortestAngle(float target, float pos)
{
	float error=0.0;

	error = target - pos;
	if (error > M_PI) {
		error -= 2*M_PI;
	}
	else if (error < -M_PI){
		error += 2*M_PI;
	}

	return error;
}

/*
 * Calculate the mean of the mean of a float array
 */
float GENCalcVariance(float col[], size_t size)
{
	size_t	count=0;
	float   total=0.0;
	float   mean=0.0;
	float   meanSquare=0.0;
	float		variance=0.0;

	/*
	 * Calculate mean square
	 */
	for(count=0; count < size; count++){
		total+=col[count]*col[count];
	}
	meanSquare=total/size;
	UARTPrintf("Mean Square:	%f\r\n",meanSquare);

	/*
	 * Calculate mean
	 */
	total=0.0;
	for(count=0; count < size; count++){
		total+=col[count];
	}
	mean=total/size;
	UARTPrintf("Mean:	%f\r\n", mean);

	/*
   * Calculate variance
	 */
	variance=meanSquare-(size/(size-1))*mean*mean;
	UARTPrintf("Variance:	%f\r\n", variance);

	/*
	 * Done!
	 */
	return variance;
}

/*
 * Variance test
 */
float numbers[8] = { 2.0, 4.0, 4.0, 4.0, 5.0, 5.0, 7.0, 9.0};
void GENTestVariance(void)
{
	float variance=0.0;
	
	UARTPrintf("Enter Variance\r\n");
	variance = GENCalcVariance(numbers, 8);
	UARTPrintf("Variance:	%f\r\n", variance);
	chThdSleepMilliseconds(10000);
}

/*
 *========================================
 * Quaternion functions
 *========================================
 */

/*
 * Normalize quaternion
 */
int GENQuatNormalize(QuatStruct *quat)
{
	int retval=0;
	float mag=0.0;

	mag = sqrt(quat->x*quat->x + quat->y*quat->y + quat->z * quat->z + quat->w * quat->w);

	if(mag == 0.0) {
		// Can't normalize the 0 vector.
		retval = -1;
	} else {
		quat->x = quat->x/mag;
		quat->y = quat->y/mag;
		quat->z = quat->z/mag;
		quat->w = quat->w/mag;
	}

	return retval;
}

#if 0
/*
 * Rotate Quaternion quad1 over quad2 store result in quad3.
 */
void GENQuatRotate(QuatStruct *res, QuatStruct *vect, QuatStruct *q)
{
	QuatStruct temp;
	QuatStruct conj;

	GENQuatConj(&conj, q);

	/*
	 * Quaternion rotation
	 * q*v*(q^-1)
	 */
	GENQuatMul(&temp, q, vect);
	GENQuatMul(res, &temp, &conj);
}

/*
 * Scalar vector product of 3 
 */
static VectStruct3 *VectAdd3(VectStruct3 *res, VectStruct3 *s, VectStruct3 *v)
{
	res->x=s->x+v->x;
	res->y=s->y+v->y;
	res->z=s->z+v->z;

	return res;
}
/*
 * Cross product.
 */
static VectStruct3 *cross(VectStruct3 *res, VectStruct3 *s, VectStruct3 *v)
{
	res->x = (s->y*v->z)-(s->z*v->y);
	res->y = (s->x*v->z)-(s->z*v->x);
	res->z = (s->x*v->y)-(s->y*v->x);

	return res;
}

//void rotate_vector_by_quaternion(const Vector3& v, const Quaternion& q, Vector3& vprime)
void GENQuatRotate(QuatStruct *res, QuatStruct *vect, QuatStruct *q)
{
	VectStruct3 res1;
	VectStruct3 res2;
	VectStruct3 res3;
	VectStruct3 res4;
	VectStruct3 v;

	// Extract the vector part of the quaternion
	VectStruct3 u;
	u.x = q->x;
	u.y = q->y;
	u.z = q->z;

	v.x = vect->x;
	v.y = vect->y;
	v.z = vect->z;
	

	// Extract the scalar part of the quaternion
	float s = q->w;

	// Do the math
	//*res = 2.0f * dot3(u, vect) * u
	scalarVect3(&res1, 2.0f * dot3(&u, &v), &u);

	//+ (s*s - dot3(u, u)) * vect
	scalarVect3(&res2, (s*s - dot3(&u, &u)), &v);
	VectAdd3(&res3, &res1, &res2);

	//+ 2.0f * s * cross(u, vect);
	scalarVect3(&res4, 2.0f * s, cross(&res1, &u, &v));
	VectAdd3(&res1, &res3, &res4);

	// Output
	res->x = res1.x;
	res->y = res1.y;
	res->z = res1.z;
	res->w = 0.0;
}
#endif

/*
 * Rotate Quaternion quad1 over quad2 store result in quad3.
 */
void GENQuatRotate(QuatStruct *res, QuatStruct *vect, QuatStruct *q)
{
	QuatStruct temp;
	QuatStruct conj;

	GENQuatConj(&conj, q);

	/*
	 * Quaternion rotation
	 * q*v*(q(conj))
	 */
	GENQuatMul(&temp, q, vect);
	GENQuatMul(res, &temp, &conj);
}


/*                                                                                                                            
 * Rotate Quaternion quad1 over quad2 store result in quad3.                                                                  
 */
void GENQuatMul(QuatStruct *res, QuatStruct *q1, QuatStruct *q2)
{
    res->w = q2->w*q1->w - q2->x*q1->x - q2->y*q1->y - q2->z*q1->z;
    res->x = q2->w*q1->x + q2->x*q1->w - q2->y*q1->z + q2->z*q1->y;
    res->y = q2->w*q1->y + q2->x*q1->z + q2->y*q1->w - q2->z*q1->x;
    res->z = q2->w*q1->z - q2->x*q1->y + q2->y*q1->x + q2->z*q1->w;
}

/*
 * Get conjugate of a quaternion.
 */
void GENQuatConj(QuatStruct *res, QuatStruct *q)
{
		res->w =  q->w;
		res->x = -q->x;
		res->y = -q->y;
		res->z = -q->z;
}

/*
 * Get conjugate of a quaternion.
 */
void GENQuatInv(QuatStruct *res, QuatStruct *q)
{
		res->x = -q->x;
		res->y = -q->y;
		res->z = -q->z;
		res->w = -q->w;
}

/*
 * 3x3 Identity Matrix
 */
Matrix33 MatrixEye33 = {{1,0,0}, {0,1,0}, {0,0,1}};

/*
 * Multiply a 3x3 matrix by a 3x1 Vector
 * Result is stored in vectout
 */
void Matrix33v3Mul(Matrix33 mat, Matrix31 vecin, Matrix31 vecout)
{
	int i=0;

	for(i=0; i<3; i++){
		vecout[i] = mat[i][0] * vecin[0] + mat[i][1] * vecin[1] + mat[i][2] * vecin[2];	
	}

}

/*
 * Multiply a 3x3 matrix by a 3x3 matrix
 * Result is stored in vectout
 */
void Matrix33Mul(Matrix33 mat1, Matrix33 mat2, Matrix33 matout)
{
	int		i=0;
	int		j=0;
	int		k=0;
	float temp=0.0;

	for(i=0; i<3; i++){
		for(j=0; j<3; j++){
			temp=0.0; // Start fresh
			// Inner product
			for(k=0; k<3; k++) {
				temp += mat2[k][j] * mat1[i][k];
			}
			// Store result
			matout[i][j] = temp;
		}
	}
}

/*
 * Add two 3x3 matrices
 * Result is stored in vectout
 */
void Matrix33Add(Matrix33 mat1, Matrix33 mat2, Matrix33 matout)
{
	int		i=0;
	int		j=0;

	for(i=0; i<3; i++){
		for(j=0; j<3; j++){
			matout[i][j]=mat1[i][j]+mat2[i][j];
		}
	}
}

/*
 * Substract two 3x3 matrices
 * Result is stored in vectout
 */
void Matrix33Sub(Matrix33 mat1, Matrix33 mat2, Matrix33 matout)
{
	int		i=0;
	int		j=0;

	for(i=0; i<3; i++){
		for(j=0; j<3; j++){
			matout[i][j]=mat1[i][j]-mat2[i][j];
		}
	}
}

/*
 * Multiply a 3x3 matrix by a scalar
 * Result is stored in vectout
 */
void Matrix33ScalMul(Matrix33 mat, float scal, Matrix33 matout)
{
	int		i=0;
	int		j=0;

	for(i=0; i<3; i++){
		for(j=0; j<3; j++){
			matout[i][j]=mat[i][j]*scal;
		}
	}
}

/*
 * Multiply a 3x3 matrix by a scalar
 * Result is stored in vectout
 */
void Matrix33ScalAdd(Matrix33 mat, float scal, Matrix33 matout)
{
	int		i=0;
	int		j=0;

	for(i=0; i<3; i++){
		for(j=0; j<3; j++){
			matout[i][j]=mat[i][j]+scal;
		}
	}
}

/*
 * Transpose a 3x3 Matrix
 */
void Matrix33Trans(Matrix33 matin, Matrix33 matout)
{
	int i=0;
	int j=0;

	for(i=0; i<3; i++){
		for(j=0; j<3; j++){
			matout[i][j]=matin[j][i];
		}
	}

}

/*
 * Add a 3 vector to a 3 vector
 * Result is stored in vectout
 */
void Vector3Add(Matrix31 vecin1, Matrix31 vecin2, Matrix31 vecout)
{
	vecout[0] = vecin1[0]+vecin2[0];
	vecout[1] = vecin1[1]+vecin2[1];
	vecout[2] = vecin1[2]+vecin2[2];
}

/*
 * Add a 3 vector to a 3 vector
 * Result is stored in vectout
 */
void Vector3Sub(Matrix31 vecin1, Matrix31 vecin2, Matrix31 vecout)
{
	vecout[0] = vecin1[0]-vecin2[0];
	vecout[1] = vecin1[1]-vecin2[1];
	vecout[2] = vecin1[2]-vecin2[2];
}

/*
 * Get the determinant of a 3x3 Matrix.
 */
float Matrix33Det(Matrix33 mat)
{
  float det;

  /*
   * Calculate determinant.
   */
  det=mat[0][0]*(mat[1][1]*mat[2][2]-mat[2][1]*mat[1][2])-mat[0][1]*(mat[1][0]*mat[2][2]-mat[1][2]*mat[2][0])+mat[0][2]*(mat[1][0]*mat[2][1]-mat[1][1]*mat[2][0]);//matdjoin

  return det;
}

/*
 * Get the inverse matrix of a 3x3 matrix.
 */
void Matrix33Inv(Matrix33 in, Matrix33 out)
{
	float det=0.0;

  /*
   * Determinant.
   */
  det = Matrix33Det(in);
	// Handle singular matrices
	if(det == 0.0) {
		in[0][0] += 0.01;
		det = Matrix33Det(in);
	}

  /*
   * calculate inverse
   */
  out[0][0]=(in[1][1]*in[2][2]-in[2][1]*in[1][2])/det;
  out[1][0]=-(in[1][0]*in[2][2]-in[1][2]*in[2][0])/det;
  out[2][0]=(in[1][0]*in[2][1]-in[2][0]*in[1][1])/det;
  out[0][1]=-(in[0][1]*in[2][2]-in[0][2]*in[2][1])/det;
  out[1][1]=(in[0][0]*in[2][2]-in[0][2]*in[2][0])/det;
  out[2][1]=-(in[0][0]*in[2][1]-in[2][0]*in[0][1])/det;
  out[0][2]=(in[0][1]*in[1][2]-in[0][2]*in[1][1])/det;
  out[1][2]=-(in[0][0]*in[1][2]-in[1][0]*in[0][2])/det;
  out[2][2]=(in[0][0]*in[1][1]-in[1][0]*in[0][1])/det;
}

/*
 * Init lowpass
 */
void GENInitLowPass(int order, LowPassStruct *lowpass)
{
  /* Clear array */
  memset(lowpass, 0, sizeof(LowPassStruct));

  /* Set filter order*/
  lowpass->order = order;
}

/*
 * Lowpass filter max order 10
 */
float GENLowPass(float val, LowPassStruct *lowpass)
{
  int     count=0;  
  float   total=0.0;
  float   retval=0.0;

  /*
   * Add the new value to the array
   */
  lowpass->x[lowpass->current] = val;
  lowpass->current = (lowpass->current + 1) % lowpass->order;

  /*
   * calculete avarage
   */
  for(count=0; count<lowpass->order; count++){
    total += lowpass->x[count];
  }
  retval = total/lowpass->order;

  /*
   * return value
   */
  return retval;
}

/* 
 * Calculate shortest angle between 2 angles on cirkel
 * in radians.
 */
#define PIV2 M_PI+M_PI
float GENDifAngRad(float x, float y)
{
  float arg;

  arg = fmod(y-x, PIV2);
  if (arg < 0 )  arg  = arg + PIV2;
  if (arg > M_PI) arg  = arg - PIV2;

  return (-arg);
}

/* 
 * Calculate the difference between to angles in degrees. 
 */
float GENDifAngDeg(float x, float y)
{
  float arg;
  arg = fmod(y-x, 360.0);
  if (arg < 0 )  arg  = arg + 360.0;
  if (arg > 180) arg  = arg - 360.0;
  return (-arg);
}
