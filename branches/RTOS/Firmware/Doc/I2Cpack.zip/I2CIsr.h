//*****************************************************************************
//
// I2CIsr.h - Prototypes for the I2C0 Driver.
//
//*****************************************************************************

#ifndef I2CISR_H_
#define I2CISR_H_

//*****************************************************************************
//
// If building with a C++ compiler, make all of the definitions in this header
// have a C binding.
//
//*****************************************************************************
#ifdef __cplusplus
extern "C"
{
#endif

//*****************************************************************************
//
// Defines for the API.
//
//*****************************************************************************	


//*****************************************************************************
//
// I2C Master operations.
//
//*****************************************************************************
#define I2C_NOP		0x00
#define I2C_READ 	0x01
#define I2C_WRITE 	0x02
	
//*****************************************************************************
//
// I2C states for opened device.
//
//*****************************************************************************	
#define I2C_OPENED			0x00
#define I2C_ERROR			0x01
#define I2C_FASTSPEED_CAP 	0x02
#define I2C_REGISTERED	 	0x04

//*****************************************************************************
//
// I2C transaction commands.
//
//*****************************************************************************	
#define I2C_BURST_SEND  0x01
#define I2C_BURST_READ  0x02
#define I2C_FINISH_SEND 0x03
#define I2C_FINISH_READ 0x04
#define I2C_MAX_TRANSACTION_COUNT 20
	
//*****************************************************************************
//
// I2C transaction structure.
//
//*****************************************************************************	
typedef struct I2CTransaction {
		unsigned char cmd;
		unsigned char len;
		unsigned char * data;
} I2C_TRANSACTION;
	
//*****************************************************************************
//
// Maximum number of simultaneously opened devices.
//
//*****************************************************************************
#define I2C_MAX_OPENED 0x10

//*****************************************************************************
//
// Size of receive buffer in bytes.
//
//*****************************************************************************	
#define I2C0_RX_RING_BUF_SIZE 0x10

//*****************************************************************************
//
// Prototypes for the APIs.
//
//*****************************************************************************
extern void I2C0ServiceTaskInit(void);
extern int I2C0ServiceTaskOpen(void);
extern int I2C0ServiceTaskRegister(unsigned long I2COpenID, unsigned char I2Caddress, unsigned char fastDevice); 
extern int I2C0ServiceTaskRead(unsigned long I2COpenID, unsigned char * I2Cdata, const unsigned long I2CDataCount);
extern int I2C0ServiceTaskWrite(unsigned long I2COpenID, unsigned char * I2Cdata, const unsigned long I2CDataCount);
extern int I2C0ServiceTaskTransaction(unsigned long I2COpenID, I2C_TRANSACTION ** transaction);
extern int I2C0ServiceTaskClose(unsigned long I2COpenID);
//*****************************************************************************
//
// Mark the end of the C bindings section for C++ compilers.
//
//*****************************************************************************
#ifdef __cplusplus
}
#endif

#endif /*I2CISR_H_*/
