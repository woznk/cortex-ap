//*****************************************************************************
//
// I2CIsr.c - Driver for Inter-IC (I2C) bus block.
//
//*****************************************************************************

#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"

#include "hw_ints.h"
#include "hw_memmap.h"
#include "hw_types.h"
#include "src/debug.h"
#include "src/gpio.h"
#include "src/i2c.h"
#include "src/interrupt.h"
#include "src/sysctl.h"
#include "utils/ringbuf.h"

#include "I2CIsr.h"


//*****************************************************************************
//
// Operation performed on the I2C bus.
//
//*****************************************************************************
static unsigned portCHAR I2C0Direction = I2C_NOP;

//*****************************************************************************
//
// This structure represents status of I2C0 device and its address. 
// Every state is defined in one bit. Access to these bits is via special function of 
// Cortex M3, bit band mapping.
//
//*****************************************************************************
typedef struct I2CDevice
{
	volatile unsigned long I2CStatus;
	unsigned char I2CAddress;
} I2CDEVICE;

//*****************************************************************************
//
// An array of i2c devices
//
//*****************************************************************************
static I2CDEVICE I2C0Device[I2C_MAX_OPENED];

//*****************************************************************************
//
// Informs service task about event from interrupt routine
//
//*****************************************************************************
static xSemaphoreHandle I2C0BinSemaphore = NULL;

//*****************************************************************************
//
// Exclusive lock, prevents simultaneous access 
//
//*****************************************************************************
static xSemaphoreHandle I2C0OAccessMutex = NULL;
 
//*****************************************************************************
//
// Counting semaphore to test maximum opened devices
//
//*****************************************************************************
static xSemaphoreHandle I2C0OpenCountSemaphore = NULL;

//*****************************************************************************
//
// Represents how many devices are opened 
//
//*****************************************************************************
static unsigned portCHAR I2C0OpenedDevice = 0;

//*****************************************************************************
//
// Represents for which device are operation related 
//
//*****************************************************************************
static unsigned portCHAR I2C0CurrentOpenedDevice = 0;

//*****************************************************************************
//
// The buffer used to hold characters received from the I2C0
//
//*****************************************************************************
static unsigned char I2C0RXBuffer[I2C0_RX_RING_BUF_SIZE];

//*****************************************************************************
//
// The structure used to hold information about ring buffer
//
//*****************************************************************************
static tRingBufObject ringI2C0RxBuff;

//*****************************************************************************
//
//! I2C0 interrupt handler.
//!
//! \param None
//!
//! This function is called after every event on the I2C bus. 
//!
//! Direction of operation is determined by I2C0Direction that is set in
//! I2C service task. Before returning a semaphore is released to inform service
//! task. If is operation succesful a macro to force context switch is called. 
//!
//! \return None.
//
//*****************************************************************************
void I2C0Interrupt(void)
{

	/*
	 * xSemaphoreGiveFromISR() will set *pxHigherPriorityTaskWoken to pdTRUE 
	 * if giving the semaphoree caused a task to unblock, and the unblocked 
	 * task has a priority higher than the currently running task.
	 */
	static portBASE_TYPE xHigherPriorityTaskWoken;

	// Value received from I2C bus	
	unsigned long I2C0Value;

	//Clear int source to avoid re-activation upon exit
	I2CMasterIntClear(I2C0_MASTER_BASE);

	if (I2C_MASTER_ERR_NONE == I2CMasterErr(I2C0_MASTER_BASE))
	{
		switch (I2C0Direction)
		{
		case I2C_READ:
			I2C0Value = I2CMasterDataGet(I2C0_MASTER_BASE);
			RingBufWriteOne(&ringI2C0RxBuff, (unsigned char) I2C0Value);
			break;
		case I2C_WRITE:
			// Writing is provided from service task this inform only about successful write.
			break;
		case I2C_NOP:
			return;
		}

		//There was no error during I2C operation
		HWREGBITW(&I2C0Device[I2C0CurrentOpenedDevice].I2CStatus, I2C_ERROR) = 0;

		// Unblock the task by releasing the semaphore.
		xSemaphoreGiveFromISR( I2C0BinSemaphore, &xHigherPriorityTaskWoken );

		/* If a task was woken by the character being received then we force
		 a context switch to occur in case the task is of higher priority than
		 the currently executing task (i.e. the task that this interrupt
		 interrupted.) */
		portEND_SWITCHING_ISR( xHigherPriorityTaskWoken );
	}
	else
	{

		//Inform service task that an error occured
		HWREGBITW(&I2C0Device[I2C0CurrentOpenedDevice].I2CStatus, I2C_ERROR) = 1;

		/* Unblock the task by releasing the semaphore. If an errror occured 
		 * there is no need to wake up service task immediately
		 */
		xSemaphoreGiveFromISR( I2C0BinSemaphore, &xHigherPriorityTaskWoken );
	}
}

//*****************************************************************************
//
//! Initializes I2C0 peripheral.
//!
//! \param None
//!
//! This function initializes hardware so is accessible without hard fault and   
//! sets up mutexes, semaphores and ring buffer.
//!
//! This function only enables peripheral.
//!
//! \return None.
//
//*****************************************************************************
void I2C0ServiceTaskInit(void)
{

	// Initialize the ring buffers used by the I2C Driver.
	RingBufInit(&ringI2C0RxBuff, I2C0RXBuffer, sizeof(I2C0RXBuffer));

	I2C0OpenCountSemaphore = xSemaphoreCreateCounting( I2C_MAX_OPENED, I2C_MAX_OPENED );
	I2C0BinSemaphore = xSemaphoreCreateCounting( 1, 0 );

	I2C0OAccessMutex = xSemaphoreCreateMutex();

	// Enable the peripherals used by this service task.
	SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C0);
	SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
	
	// Configure the appropriate pins to be I2C instead of GPIO.
	GPIOPinTypeI2C(GPIO_PORTB_BASE, GPIO_PIN_2 | GPIO_PIN_3);
	
	// Set interrupt priority to number higher than configMAX_SYSCALL_INTERRUPT_PRIORITY
	// defined in FreeRTOSConfig.h, see www.freertos.org
	IntPrioritySet(INT_I2C0, SET_SYSCALL_INTERRUPT_PRIORITY(6)); 
}


//*****************************************************************************
//
//! Sends data to the I2C controller.
//!
//! \param I2COpenID is the identifier of opened device.
//! \param I2Cdata is pointer to data that will be written to.
//! \param I2CDataCount how many bytes should be written
//!
//! This function sends byte(s) to the I2C controller. Simultaneous access is secured 
//! by mutex. The device has to be opened and registered before using this function.
//! 
//! \return Number of written bytes or -1 if error.
//
//*****************************************************************************
int I2C0ServiceTaskWrite(	unsigned long I2COpenID,
							unsigned char * I2Cdata,
							const unsigned long I2CDataCount)
{
	if ( (I2COpenID < I2C_MAX_OPENED) && (1 == HWREGBITW( &I2C0Device[I2COpenID].I2CStatus, I2C_OPENED)) && (1 == HWREGBITW( &I2C0Device[I2COpenID].I2CStatus, I2C_REGISTERED)))
	{
		// Access to shared resource   				
		xSemaphoreTake(I2C0OAccessMutex, ( portTickType ) portMAX_DELAY );
		
		// Inform interrupt driver for which device is action performed
		I2C0CurrentOpenedDevice = I2COpenID;

		I2C0Direction = I2C_WRITE;
		// Set device address
		I2CMasterSlaveAddrSet(I2C0_MASTER_BASE, I2C0Device[I2COpenID].I2CAddress, false);

		if (I2CDataCount < 2)
		{
			// Write only one byte to the I2C
			I2CMasterDataPut(I2C0_MASTER_BASE, *I2Cdata);

			// Informs I2C conntroller that only one byte will be written
			I2CMasterControl(I2C0_MASTER_BASE, I2C_MASTER_CMD_SINGLE_SEND);

			// Waiting for finishing transaction from interrupt routine 
			xSemaphoreTake(I2C0BinSemaphore, ( portTickType ) portMAX_DELAY);

			// Everything ok, no errors, returns one byte written
			if (0 == HWREGBITW(&I2C0Device[I2COpenID].I2CStatus, I2C_ERROR))
			{
				// Release mutex
				xSemaphoreGive(I2C0OAccessMutex);
				return 1;
			}
			else
			{
				// Release mutex
				xSemaphoreGive(I2C0OAccessMutex);
				return -1;
			}
		}
		else
		{
			// write several bytes 

			//write first byte on the I2C bus
			I2CMasterDataPut(I2C0_MASTER_BASE, *I2Cdata);

			// Informs I2C conntroller that several bytes will be written
			I2CMasterControl(I2C0_MASTER_BASE, I2C_MASTER_CMD_BURST_SEND_START);

			// Waiting for finishing transaction from interrupt routine 
			xSemaphoreTake(I2C0BinSemaphore, ( portTickType ) portMAX_DELAY);

			// Everything ok, no errors
			if (1 == HWREGBITW(&I2C0Device[I2COpenID].I2CStatus, I2C_ERROR))
			{
				// Release mutex
				xSemaphoreGive(I2C0OAccessMutex);
				return -1;
			}
			// move pointer to the next item 
			I2Cdata++;

			for (int it = 1; it < (I2CDataCount -1); it++)
			{

				I2CMasterDataPut(I2C0_MASTER_BASE, *I2Cdata);

				// Informs I2C conntroller that several bytes will be continue
				I2CMasterControl(I2C0_MASTER_BASE, 
				I2C_MASTER_CMD_BURST_SEND_CONT);

				// Waiting for finishing transaction from interrupt routine 
				xSemaphoreTake(I2C0BinSemaphore, ( portTickType ) portMAX_DELAY);

				// Everything ok, no errors
				if (1 == HWREGBITW(&I2C0Device[I2COpenID].I2CStatus, I2C_ERROR))
				{
					// Release mutex
					xSemaphoreGive(I2C0OAccessMutex);
					return -1;
				}

				// move pointer to the next item
				I2Cdata++;

			}
			// Write last byte on the I2C bus
			I2CMasterDataPut(I2C0_MASTER_BASE, *I2Cdata);

			// Informs I2C conntroller that this was last byte
			I2CMasterControl(I2C0_MASTER_BASE, I2C_MASTER_CMD_BURST_SEND_FINISH);

			// Waiting for finishing transaction from interrupt routine 
			xSemaphoreTake(I2C0BinSemaphore, ( portTickType ) portMAX_DELAY);

			// Everything ok, no errors, returns one byte written			
			if (1 == HWREGBITW(&I2C0Device[I2COpenID].I2CStatus, I2C_ERROR))
			{
				// Release mutex
				xSemaphoreGive(I2C0OAccessMutex);
				return -1;
			}
			// Release mutex
			xSemaphoreGive(I2C0OAccessMutex);
			// returns count of written bytes
			return I2CDataCount;
		}//if (I2CDataCount < 2)
	} //if ( (I2COpenID < I2C_MAX_OPENED) && (1 == HWREGBITW( &I2C0Device[I2COpenID].I2CStatus, I2C_OPENED)) && (1 == HWREGBITW( &I2C0Device[I2COpenID].I2CStatus, I2C_REGISTERED)))

	return -1;
}

//*****************************************************************************
//
//! Receives data from the I2C controller.
//!
//! \param I2COpenID is the identifier of opened device.
//! \param I2Cdata is pointer to data that will be read.
//! \param I2CDataCount how many bytes should be read.
//!
//! This function read byte(s) from a ring buffer. Simultaneous access is secured 
//! by mutex. The device has to be opened and registered before using this function.
//! 
//! \return Number of read bytes or -1 if error.
//
//*****************************************************************************
int I2C0ServiceTaskRead(unsigned long I2COpenID,
						unsigned char * I2Cdata,
						const unsigned long I2CDataCount)
{

	if ( (I2COpenID < I2C_MAX_OPENED) && (1
			== HWREGBITW( &I2C0Device[I2COpenID].I2CStatus, I2C_OPENED)) && (1
			== HWREGBITW( &I2C0Device[I2COpenID].I2CStatus, I2C_REGISTERED)))
	{
		// Access to shared resource   				
		xSemaphoreTake(I2C0OAccessMutex, ( portTickType ) portMAX_DELAY );
		
		// Inform interrupt driver for which device is action performed
		I2C0CurrentOpenedDevice = I2COpenID;

		// Sets direction of operation to inform interrupt routine
		I2C0Direction = I2C_READ;

		// Sets device address
		I2CMasterSlaveAddrSet(I2C0_MASTER_BASE, I2C0Device[I2COpenID].I2CAddress, true);

		if (I2CDataCount < 2)
		{
			// Informs I2C conntroller that only bytes will be read
			I2CMasterControl(I2C0_MASTER_BASE, I2C_MASTER_CMD_SINGLE_RECEIVE);

			// Waiting for finishing transaction from interrupt routine 
			xSemaphoreTake(I2C0BinSemaphore, ( portTickType ) portMAX_DELAY);

			// Everything ok, no errors, returns one byte read
			if (0 == HWREGBITW(&I2C0Device[I2COpenID].I2CStatus, I2C_ERROR))
			{

				// Reads one byte from ring buffer
				*I2Cdata = RingBufReadOne(&ringI2C0RxBuff);
				// Release mutex
				xSemaphoreGive(I2C0OAccessMutex);
				return 1;
			}
			else
			{
				// Release mutex
				xSemaphoreGive(I2C0OAccessMutex);
				return -1;
			}
		}
		else
		{
			// reads several bytes 						

			// Informs I2C conntroller that several bytes will be read
			I2CMasterControl(I2C0_MASTER_BASE, 
			I2C_MASTER_CMD_BURST_RECEIVE_START);

			// Waiting for finishing transaction from interrupt routine 
			xSemaphoreTake(I2C0BinSemaphore, ( portTickType ) portMAX_DELAY);

			// Everything ok, no errors
			if (1 == HWREGBITW(&I2C0Device[I2COpenID].I2CStatus, I2C_ERROR))
			{
				// Release mutex
				xSemaphoreGive(I2C0OAccessMutex);
				return -1;
			}

			// Reads one byte from ring buffer
			*I2Cdata = RingBufReadOne(&ringI2C0RxBuff);

			// move pointer to the next item 
			I2Cdata++;

			for (int it = 1; it < (I2CDataCount -1); it++)
			{

				// Informs I2C conntroller that reading several bytes will continue
				I2CMasterControl(I2C0_MASTER_BASE, 
				I2C_MASTER_CMD_BURST_RECEIVE_CONT);

				// Waiting for finishing transaction from interrupt routine 
				xSemaphoreTake(I2C0BinSemaphore, ( portTickType ) portMAX_DELAY);

				// Everything ok, no errors
				if (1 == HWREGBITW(&I2C0Device[I2COpenID].I2CStatus, I2C_ERROR))
				{
					// Release mutex
					xSemaphoreGive(I2C0OAccessMutex);
					return -1;
				}
				// Reads one byte from ring buffer
				*I2Cdata = RingBufReadOne(&ringI2C0RxBuff);

				// move pointer to the next item
				I2Cdata++;
			}

			// Informs I2C conntroller that this was last byte
			I2CMasterControl(I2C0_MASTER_BASE, 
			I2C_MASTER_CMD_BURST_RECEIVE_FINISH);

			// Waiting for finishing transaction from interrupt routine 
			xSemaphoreTake(I2C0BinSemaphore, ( portTickType ) portMAX_DELAY);

			// Everything ok, no errors, returns one byte written			
			if (1 == HWREGBITW(&I2C0Device[I2COpenID].I2CStatus, I2C_ERROR))
			{
				// Release mutex
				xSemaphoreGive(I2C0OAccessMutex);
				return -1;
			}

			// Reads one byte from ring buffer
			*I2Cdata = RingBufReadOne(&ringI2C0RxBuff);

			// Release mutex
			xSemaphoreGive(I2C0OAccessMutex);
			// returns count of written bytes
			return I2CDataCount;
		}//if (I2CDataCount < 2)
	} //if ( (I2COpenID < I2C_MAX_OPENED) && (1 == HWREGBITW(....

	return -1;
}

//*****************************************************************************
//
//! Executes operations on the I2C controller.
//!
//! \param I2COpenID is the identifier of opened device.
//! \param transaction is pointer to array of transactions.
//!
//! This function can process operation on I2C controller defined by user.    
//! Transaction structure is defined in I2CIsr.h. Possible commands I2C_BURST_SEND,
//! I2C_BURST_READ, I2C_FINISH_SEND, I2C_FINISH_READ. Every sequence of commands
//! has to end with I2C_FINISH_READ or I2C_FINISH_SEND and cannot start with them. 
//! E.g. if you want write one byte and read 3 this order must follow:
//! I2C_BURST_SEND(1),I2C_BURST_READ(2),I2C_FINISH_READ(1)
//! 
//! Simultaneous access is secured by mutex. The device has to be opened and registered before using this function.
//! 
//! \return 0 or -1 if error.
//
//*****************************************************************************
int I2C0ServiceTaskTransaction(	unsigned long I2COpenID, I2C_TRANSACTION ** transaction)
{
	unsigned char currentOperation = I2C_NOP;
	unsigned long transactionCount = 0; 

	if ( (I2COpenID < I2C_MAX_OPENED) && (1 == HWREGBITW( &I2C0Device[I2COpenID].I2CStatus, I2C_OPENED)) && (1 == HWREGBITW( &I2C0Device[I2COpenID].I2CStatus, I2C_REGISTERED)))
	{
		// Inform interrupt driver for which device is action performed
		I2C0CurrentOpenedDevice = I2COpenID;

		// Access to shared resource   				
		xSemaphoreTake(I2C0OAccessMutex, ( portTickType ) portMAX_DELAY );
		
		//First operation denotes next behavior, only BURST mode is allowed
		while (transactionCount < I2C_MAX_TRANSACTION_COUNT)
		{
			switch ((*transaction)->cmd)
			{
			case I2C_BURST_READ:
				// if previous operation was BURST_READ, error
				if (I2C_READ == currentOperation)
				{
					// Release mutex
					xSemaphoreGive(I2C0OAccessMutex);
					return -1;
				}
				// Sets device address
				I2CMasterSlaveAddrSet(I2C0_MASTER_BASE, I2C0Device[I2COpenID].I2CAddress, true);
				
				// Sets direction of operation to inform interrupt routine
				I2C0Direction = I2C_READ;
				currentOperation = I2C_READ;
				
				// Informs I2C conntroller that several bytes will be read
				I2CMasterControl(I2C0_MASTER_BASE, I2C_MASTER_CMD_BURST_RECEIVE_START);
				
				// Waiting for finishing transaction from interrupt routine 
				xSemaphoreTake(I2C0BinSemaphore, ( portTickType ) portMAX_DELAY);
				
				// Everything ok?
				if (1 == HWREGBITW(&I2C0Device[I2COpenID].I2CStatus, I2C_ERROR))
				{
					// Release mutex
					xSemaphoreGive(I2C0OAccessMutex);
					return -1;
				}
				
				// Reads one byte from ring buffer and save to user buffer
				// transaction->data is pointer to unsigned char
				*((*transaction)->data) = RingBufReadOne(&ringI2C0RxBuff);
				
				// next reading continues if any
				for (unsigned char it = 1; it < (*transaction)->len; it ++)
				{
					// Informs I2C conntroller that reading several bytes will continue
					I2CMasterControl(I2C0_MASTER_BASE, I2C_MASTER_CMD_BURST_RECEIVE_CONT);
					
					// Waiting for finishing transaction from interrupt routine 
					xSemaphoreTake(I2C0BinSemaphore, ( portTickType ) portMAX_DELAY);
					
					// Everything ok?
					if (1 == HWREGBITW(&I2C0Device[I2COpenID].I2CStatus, I2C_ERROR))
					{
						// Release mutex
						xSemaphoreGive(I2C0OAccessMutex);
						return -1;
					}
					// Reads one byte from ring buffer and save to user buffer
					// transaction->data is pointer to unsigned char
					*((*transaction)->data + it) = RingBufReadOne(&ringI2C0RxBuff);
				}
				break;
			case I2C_FINISH_READ:
				
				// this is first transaction operation? If, this is not allowed, use read instead 
				if(0 == transactionCount)
				{
					// Release mutex
					xSemaphoreGive(I2C0OAccessMutex);
					return -1;
				}
				
				I2C0Direction = I2C_READ;

				if (I2C_WRITE == currentOperation)
				{
					// previous operation was burst send, only one byte is required
					// Sets device address
					I2CMasterSlaveAddrSet(I2C0_MASTER_BASE, I2C0Device[I2COpenID].I2CAddress, true);
					// sends stop command to the i2c controller, no more bytes than one is required
					I2CMasterControl(I2C0_MASTER_BASE, I2C_MASTER_CMD_SINGLE_RECEIVE);
				}
				else
				{
					// previous operation was burst read, only one byte is required					
					// sends finish command to the i2c controller, no more bytes than one is required
					I2CMasterControl(I2C0_MASTER_BASE, I2C_MASTER_CMD_BURST_RECEIVE_FINISH);

				}
				// Waiting for finishing transaction from interrupt routine 
				xSemaphoreTake(I2C0BinSemaphore, ( portTickType ) portMAX_DELAY);
				// Everything ok, no errors, returns one byte read
				if (1 == HWREGBITW(&I2C0Device[I2COpenID].I2CStatus, I2C_ERROR))
				{
					// Release mutex
					xSemaphoreGive(I2C0OAccessMutex);
					return -1;
				}
				// Reads one byte from ring buffer and save to user buffer
				// transaction->data is pointer to unsigned char
				*((*transaction)->data) = RingBufReadOne(&ringI2C0RxBuff);
				
				// Release mutex
				xSemaphoreGive(I2C0OAccessMutex);
				// everything ok?					
				return 0;
				
			case I2C_BURST_SEND:
				// if previous operation was BURST_SEND, error
				if (I2C_WRITE == currentOperation)
				{
					// Release mutex
					xSemaphoreGive(I2C0OAccessMutex);
					return -1;
				}
				// Sets device address
				I2CMasterSlaveAddrSet(I2C0_MASTER_BASE, I2C0Device[I2COpenID].I2CAddress, false);
				
				// Sets direction of operation to inform interrupt routine
				I2C0Direction = I2C_WRITE;
				currentOperation = I2C_WRITE;
				
				// Send data to I2C device
				I2CMasterDataPut(I2C0_MASTER_BASE, *((*transaction)->data));
				
				// Informs I2C conntroller that several bytes will be written
				I2CMasterControl(I2C0_MASTER_BASE, I2C_MASTER_CMD_BURST_SEND_START);
				
				// Waiting for finishing transaction from interrupt routine 
				xSemaphoreTake(I2C0BinSemaphore, ( portTickType ) portMAX_DELAY);
				
				// Everything ok?
				if (1 == HWREGBITW(&I2C0Device[I2COpenID].I2CStatus, I2C_ERROR))
				{
					// Release mutex
					xSemaphoreGive(I2C0OAccessMutex);
					return -1;
				}
				
				// next writing continues if any
				for (unsigned char it = 1; it < (*transaction)->len; it ++)
				{
					// Writes one byte from user buffer to I2C bus
					// transaction->data is pointer to unsigned char
					I2CMasterDataPut(I2C0_MASTER_BASE, *((*transaction)->data + it));
					
					// Informs I2C conntroller that several bytes will be continue
					I2CMasterControl(I2C0_MASTER_BASE, I2C_MASTER_CMD_BURST_SEND_CONT);
					
					// Waiting for finishing transaction from interrupt routine 
					xSemaphoreTake(I2C0BinSemaphore, ( portTickType ) portMAX_DELAY);
					
					// Everything ok?
					if (1 == HWREGBITW(&I2C0Device[I2COpenID].I2CStatus, I2C_ERROR))
					{
						// Release mutex
						xSemaphoreGive(I2C0OAccessMutex);
						return -1;
					}
				}
				break;
				
			case I2C_FINISH_SEND:
				// this is first transaction operation? If, this is not allowed, use write instead
				if(0 == transactionCount)
				{
					// Release mutex
					xSemaphoreGive(I2C0OAccessMutex);
					return -1;
				}

				I2C0Direction = I2C_WRITE;

				// Send data to I2C device
				I2CMasterDataPut(I2C0_MASTER_BASE, *((*transaction)->data));

				if (I2C_READ == currentOperation)
				{
					// previous operation was burst read, only one byte is required
					// Sets device address
					I2CMasterSlaveAddrSet(I2C0_MASTER_BASE, I2C0Device[I2COpenID].I2CAddress, false);
					
					// sends stop command to the i2c controller, no more bytes than one is required
					I2CMasterControl(I2C0_MASTER_BASE, I2C_MASTER_CMD_SINGLE_SEND);
				}
				else
				{
					// sends finish command to the i2c controller, no more bytes than one is required
					I2CMasterControl(I2C0_MASTER_BASE, I2C_MASTER_CMD_BURST_SEND_FINISH);
				}
				// Waiting for finishing transaction from interrupt routine 
				xSemaphoreTake(I2C0BinSemaphore, ( portTickType ) portMAX_DELAY);
				
				// Everything ok?
				if (1 == HWREGBITW(&I2C0Device[I2COpenID].I2CStatus, I2C_ERROR))
				{
					// Release mutex
					xSemaphoreGive(I2C0OAccessMutex);
					return -1;
				}
				// Release mutex
				xSemaphoreGive(I2C0OAccessMutex);
				return 0;
			default:
				// Release mutex
				xSemaphoreGive(I2C0OAccessMutex);
				return -1;
			}//switch (transaction->cmd)
			
			// move to the next transaction
			transaction++;
			
			// one transaction performed, increase count
			transactionCount++;
			
		} //while (transactionCount < I2C_MAX_TRANSACTION_COUNT)
		
		// Release mutex
		xSemaphoreGive(I2C0OAccessMutex);
	}//if ( (I2COpenID < I2C_MAX_OPENED) && (1 == HWREGBITW( &I2C0Device[I2COpenID].I2CStatus, I2C_OPENED)) && (1 == HWREGBITW( &I2C0Device[I2COpenID].I2CStatus, I2C_REGISTERED)))
	return -1;
}


//*****************************************************************************
//
//! Disables the I2C master block.
//!
//! \param None.
//!
//! This function disables operation of the I2C master block. 
//! 
//! \return None.
//
//*****************************************************************************
static void I2C0ServiceTaskDisable(void)
{
	// Disables the I2C master block
	I2CMasterDisable(I2C0_MASTER_BASE);
}

//*****************************************************************************
//
//! Enables operation of I2C0 peripheral.
//!
//! \param None.
//!
//! This function enables operation of the I2C master block and sets up interrupts.   
//! 
//! \return None.
//
//*****************************************************************************
static void I2C0ServiceTaskEnable(void)
{
	// Initialize the I2C master. Default 100KHz
	I2CMasterInitExpClk(I2C0_MASTER_BASE, SysCtlClockGet(), false);

	// Enable the I2C interrupt.
	IntEnable(INT_I2C0);

	//Clear int source to avoid unwanted interrupts
	I2CMasterIntClear(I2C0_MASTER_BASE);

	// Enable the I2C Master interrupt.
	I2CMasterIntEnable(I2C0_MASTER_BASE);
}

//*****************************************************************************
//
//! Opens I2C0 device.
//!
//! \param None.
//!
//! This function manages opened devices.
//!
//! \return Opened device identifier or -1 if error.
//
//*****************************************************************************
int I2C0ServiceTaskOpen(void)
{

	unsigned char I2COpenID;

	if ( pdTRUE == xSemaphoreTake( I2C0OpenCountSemaphore, ( portTickType ) 0))
	{
		// We were able to obtain the semaphore and can now access the shared resource.

		// Access to shared variable   				
		xSemaphoreTake(I2C0OAccessMutex, ( portTickType ) portMAX_DELAY );
		// Iterate through array and search for unopened id
		for (I2COpenID = 0; I2COpenID < I2C_MAX_OPENED; I2COpenID++)
		{
			if (0 == HWREGBITW(&I2C0Device[I2COpenID].I2CStatus, I2C_OPENED))
				break;
		}
		// Enable device if not any was opened before
		if (0 == I2C0OpenedDevice)
		{
			I2C0ServiceTaskEnable();
		}
		// Increase number of opened devices
		I2C0OpenedDevice++;

		// Release mutex
		xSemaphoreGive(I2C0OAccessMutex);

		// Set found id as opened
		HWREGBITW(&I2C0Device[I2COpenID].I2CStatus, I2C_OPENED) = 1;

		// return id to calling function
		return I2COpenID;
	}
	return -1;
}

//*****************************************************************************
//
//! Register I2C0 device.
//!
//! \param I2COpenID is the identifier of opened device.
//! \param I2Caddress is address of a device.
//! \param fastDevice true if device can run at 400KHz.
//!
//! This function registers device's capabilities and address.
//!
//! \return Opened device identifier or -1 if error.
//
//*****************************************************************************
int I2C0ServiceTaskRegister(unsigned long I2COpenID,
							unsigned char I2Caddress,
							unsigned char fastDevice)
{

	unsigned char iterateI2COpenID;

	if ((I2COpenID < I2C_MAX_OPENED) && (1 == HWREGBITW( &I2C0Device[I2COpenID].I2CStatus, I2C_OPENED)))
	{
		// iterate over all devices
		for (iterateI2COpenID = 0; iterateI2COpenID < I2C_MAX_OPENED; iterateI2COpenID++)
		{
			//checks if anothere registered device has not same address
			if ((1 == HWREGBITW(&I2C0Device[iterateI2COpenID].I2CStatus, 
			I2C_REGISTERED)) && (I2Caddress == I2C0Device[iterateI2COpenID].I2CAddress))
			{
				return -1;
			}
		}
		// Assing i2c address to device
		I2C0Device[I2COpenID].I2CAddress = I2Caddress;

		// If device can run at higher speed than standard 100KHz
		if (1 == fastDevice)
		{
			HWREGBITW(&I2C0Device[I2COpenID].I2CStatus, I2C_FASTSPEED_CAP) = 1;
		}

		// Set flag  registered
		HWREGBITW(&I2C0Device[I2COpenID].I2CStatus, I2C_REGISTERED) = 1;

		// Ok
		return 0;
	}
	return -1;
}

//*****************************************************************************
//
//! Closes opened device.
//!
//! \param I2COpenID is the identifier of opened device.
//!
//! This function closes and deregisters opened device.
//!
//! \return 0 or -1 if error.
//
//*****************************************************************************
int I2C0ServiceTaskClose(unsigned long I2COpenID)
{
	// Check if id was opened and is lower then maximum possible opened devices 
	if ((I2COpenID < I2C_MAX_OPENED) && (1 == HWREGBITW( &I2C0Device[I2COpenID].I2CStatus, I2C_OPENED)))
	{
		// set all flags to zero
		I2C0Device[I2COpenID].I2CStatus = 0;

		// Decrease number of opened devices
		I2C0OpenedDevice--;

		// Disable device if no more devices are opened
		if (0 == I2C0OpenedDevice)
		{
			I2C0ServiceTaskDisable();
		}

		// We have finished accessing the shared resource
		// increment number of possible simultaneously opened devices
		xSemaphoreGive( I2C0OpenCountSemaphore );

		// Ok
		return 0;
	}
	else
	{
		return -1;
	}
}

