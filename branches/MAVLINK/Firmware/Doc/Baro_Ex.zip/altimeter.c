#include "..\include\PicPilot.h"
#include <plib.h>


#define I2C_ALT_WRITE 0xEE
#define I2C_ALT_READ 0xEF


/* Altitude Sensor Callibration Data */
volatile short Pressure_Cal_AC1;
volatile short Pressure_Cal_AC2;
volatile short Pressure_Cal_AC3;
volatile unsigned short Pressure_Cal_AC4;
volatile unsigned short Pressure_Cal_AC5;
volatile unsigned short Pressure_Cal_AC6;
volatile short Pressure_Cal_B1;
volatile short Pressure_Cal_B2;
volatile short Pressure_Cal_MB;
volatile short Pressure_Cal_MC;
volatile short Pressure_Cal_MD;

volatile int Baro_X1;
volatile int Baro_X2;
volatile int Baro_X3;
volatile int Baro_B3;
volatile unsigned int Baro_B4;
volatile int Baro_B5;
volatile int Baro_B6;
volatile int Baro_B7;



void Init_Altimeter(void)
 {
    int i;

    // Setup I2C Altimeter
    StartI2C1();	                             // Send the Start Bit
    IdleI2C1();		                             // Wait to complete
    MasterWriteI2C1(I2C_ALT_WRITE);              // Send Device address
    IdleI2C1();		                             // Wait to complete
    while( I2C1STATbits.ACKSTAT);                // Wait for Ack 
    MasterWriteI2C1(0xAA);                       // Send Register Address
    IdleI2C1();	                                 // Wait to complete
    while( I2C1STATbits.ACKSTAT);                // Wait for Ack 
    RestartI2C1();                               // Send the Restart Bit
    IdleI2C1();		                             // Wait to complete
    MasterWriteI2C1(I2C_ALT_READ);               // Send Device address
    IdleI2C1();		                             // Wait to complete
    while (I2C1STATbits.ACKSTAT);                // Wait for ACK=0 meaning slave ack'd
    I2C1CONbits.RCEN = 1;                        // Start Receive Byte
    while(I2C1CONbits.RCEN);                     // Wait for read to finish.
    I2C1STATbits.I2COV = 0;                      // Clear Receive overflow just in case.
    AckI2C1();                                   // Generate Ack.
    Pressure_Cal_AC1 = (I2C1RCV&0xFF);           // Grab Receive Data
    Pressure_Cal_AC1 = Pressure_Cal_AC1<<8;
    IdleI2C1();                                  // Wait for last I2C command to complete
    I2C1CONbits.RCEN = 1;                        // Start Next Receive Byte
    while(I2C1CONbits.RCEN);                     // Wait for read to finish.
    I2C1STATbits.I2COV = 0;                      // Clear Receive overflow just in case.
    AckI2C1();                                   // Generate Ack.
    Pressure_Cal_AC1 |= (I2C1RCV&0xFF);          // Grab Data

    IdleI2C1();                                  // Wait for last I2C command to complete
    I2C1CONbits.RCEN = 1;                        // Start Receive Byte
    while(I2C1CONbits.RCEN);                     // Wait for read to finish.
    I2C1STATbits.I2COV = 0;                      // Clear Receive overflow just in case.
    AckI2C1();                                   // Generate Ack.
    Pressure_Cal_AC2 = (I2C1RCV&0xFF);           // Grab Receive Data
    Pressure_Cal_AC2 = Pressure_Cal_AC2<<8;
    IdleI2C1();                                  // Wait for last I2C command to complete
    I2C1CONbits.RCEN = 1;                        // Start Next Receive Byte
    while(I2C1CONbits.RCEN);                     // Wait for read to finish.
    I2C1STATbits.I2COV = 0;                      // Clear Receive overflow just in case.
    AckI2C1();                                   // Generate Ack.
    Pressure_Cal_AC2 |= (I2C1RCV&0xFF);          // Grab Data

    IdleI2C1();                                  // Wait for last I2C command to complete
    I2C1CONbits.RCEN = 1;                        // Start Receive Byte
    while(I2C1CONbits.RCEN);                     // Wait for read to finish.
    I2C1STATbits.I2COV = 0;                      // Clear Receive overflow just in case.
    AckI2C1();                                   // Generate Ack.
    Pressure_Cal_AC3 = (I2C1RCV&0xFF);           // Grab Receive Data
    Pressure_Cal_AC3 = Pressure_Cal_AC3<<8;
    IdleI2C1();                                  // Wait for last I2C command to complete
    I2C1CONbits.RCEN = 1;                        // Start Next Receive Byte
    while(I2C1CONbits.RCEN);                     // Wait for read to finish.
    I2C1STATbits.I2COV = 0;                      // Clear Receive overflow just in case.
    AckI2C1();                                   // Generate Ack.
    Pressure_Cal_AC3 |= (I2C1RCV&0xFF);          // Grab Data

    IdleI2C1();                                  // Wait for last I2C command to complete
    I2C1CONbits.RCEN = 1;                        // Start Receive Byte
    while(I2C1CONbits.RCEN);                     // Wait for read to finish.
    I2C1STATbits.I2COV = 0;                      // Clear Receive overflow just in case.
    AckI2C1();                                   // Generate Ack.
    Pressure_Cal_AC4 = (I2C1RCV&0xFF);           // Grab Receive Data
    Pressure_Cal_AC4 = Pressure_Cal_AC4<<8;
    IdleI2C1();                                  // Wait for last I2C command to complete
    I2C1CONbits.RCEN = 1;                        // Start Next Receive Byte
    while(I2C1CONbits.RCEN);                     // Wait for read to finish.
    I2C1STATbits.I2COV = 0;                      // Clear Receive overflow just in case.
    AckI2C1();                                   // Generate Ack.
    Pressure_Cal_AC4 |= (I2C1RCV&0xFF);          // Grab Data

    IdleI2C1();                                  // Wait for last I2C command to complete
    I2C1CONbits.RCEN = 1;                        // Start Receive Byte
    while(I2C1CONbits.RCEN);                     // Wait for read to finish.
    I2C1STATbits.I2COV = 0;                      // Clear Receive overflow just in case.
    AckI2C1();                                   // Generate Ack.
    Pressure_Cal_AC5 = (I2C1RCV&0xFF);           // Grab Receive Data
    Pressure_Cal_AC5 = Pressure_Cal_AC5<<8;
    IdleI2C1();                                  // Wait for last I2C command to complete
    I2C1CONbits.RCEN = 1;                        // Start Next Receive Byte
    while(I2C1CONbits.RCEN);                     // Wait for read to finish.
    I2C1STATbits.I2COV = 0;                      // Clear Receive overflow just in case.
    AckI2C1();                                   // Generate Ack.
    Pressure_Cal_AC5 |= (I2C1RCV&0xFF);          // Grab Data

    IdleI2C1();                                  // Wait for last I2C command to complete
    I2C1CONbits.RCEN = 1;                        // Start Receive Byte
    while(I2C1CONbits.RCEN);                     // Wait for read to finish.
    I2C1STATbits.I2COV = 0;                      // Clear Receive overflow just in case.
    AckI2C1();                                   // Generate Ack.
    Pressure_Cal_AC6 = (I2C1RCV&0xFF);           // Grab Receive Data
    Pressure_Cal_AC6 = Pressure_Cal_AC6<<8;
    IdleI2C1();                                  // Wait for last I2C command to complete
    I2C1CONbits.RCEN = 1;                        // Start Next Receive Byte
    while(I2C1CONbits.RCEN);                     // Wait for read to finish.
    I2C1STATbits.I2COV = 0;                      // Clear Receive overflow just in case.
    AckI2C1();                                   // Generate Ack.
    Pressure_Cal_AC6 |= (I2C1RCV&0xFF);          // Grab Data

    IdleI2C1();                                  // Wait for last I2C command to complete
    I2C1CONbits.RCEN = 1;                        // Start Receive Byte
    while(I2C1CONbits.RCEN);                     // Wait for read to finish.
    I2C1STATbits.I2COV = 0;                      // Clear Receive overflow just in case.
    AckI2C1();                                   // Generate Ack.
    Pressure_Cal_B1 = (I2C1RCV&0xFF);            // Grab Receive Data
    Pressure_Cal_B1 = Pressure_Cal_B1<<8;
    IdleI2C1();                                  // Wait for last I2C command to complete
    I2C1CONbits.RCEN = 1;                        // Start Next Receive Byte
    while(I2C1CONbits.RCEN);                     // Wait for read to finish.
    I2C1STATbits.I2COV = 0;                      // Clear Receive overflow just in case.
    AckI2C1();                                   // Generate Ack.
    Pressure_Cal_B1 |= (I2C1RCV&0xFF);           // Grab Data

    IdleI2C1();                                  // Wait for last I2C command to complete
    I2C1CONbits.RCEN = 1;                        // Start Receive Byte
    while(I2C1CONbits.RCEN);                     // Wait for read to finish.
    I2C1STATbits.I2COV = 0;                      // Clear Receive overflow just in case.
    AckI2C1();                                   // Generate Ack.
    Pressure_Cal_B2 = (I2C1RCV&0xFF);            // Grab Receive Data
    Pressure_Cal_B2 = Pressure_Cal_B2<<8;
    IdleI2C1();                                  // Wait for last I2C command to complete
    I2C1CONbits.RCEN = 1;                        // Start Next Receive Byte
    while(I2C1CONbits.RCEN);                     // Wait for read to finish.
    I2C1STATbits.I2COV = 0;                      // Clear Receive overflow just in case.
    AckI2C1();                                   // Generate Ack.
    Pressure_Cal_B2 |= (I2C1RCV&0xFF);           // Grab Data

    IdleI2C1();                                  // Wait for last I2C command to complete
    I2C1CONbits.RCEN = 1;                        // Start Receive Byte
    while(I2C1CONbits.RCEN);                     // Wait for read to finish.
    I2C1STATbits.I2COV = 0;                      // Clear Receive overflow just in case.
    AckI2C1();                                   // Generate Ack.
    Pressure_Cal_MB = (I2C1RCV&0xFF);            // Grab Receive Data
    Pressure_Cal_MB = Pressure_Cal_MB<<8;
    IdleI2C1();                                  // Wait for last I2C command to complete
    I2C1CONbits.RCEN = 1;                        // Start Next Receive Byte
    while(I2C1CONbits.RCEN);                     // Wait for read to finish.
    I2C1STATbits.I2COV = 0;                      // Clear Receive overflow just in case.
    AckI2C1();                                   // Generate Ack.
    Pressure_Cal_MB |= (I2C1RCV&0xFF);           // Grab Data

    IdleI2C1();                                  // Wait for last I2C command to complete
    I2C1CONbits.RCEN = 1;                        // Start Receive Byte
    while(I2C1CONbits.RCEN);                     // Wait for read to finish.
    I2C1STATbits.I2COV = 0;                      // Clear Receive overflow just in case.
    AckI2C1();                                   // Generate Ack.
    Pressure_Cal_MC = (I2C1RCV&0xFF);            // Grab Receive Data
    Pressure_Cal_MC = Pressure_Cal_MC<<8;
    IdleI2C1();                                  // Wait for last I2C command to complete
    I2C1CONbits.RCEN = 1;                        // Start Next Receive Byte
    while(I2C1CONbits.RCEN);                     // Wait for read to finish.
    I2C1STATbits.I2COV = 0;                      // Clear Receive overflow just in case.
    AckI2C1();                                   // Generate Ack.
    Pressure_Cal_MC |= (I2C1RCV&0xFF);           // Grab Data

    IdleI2C1();                                  // Wait for last I2C command to complete
    I2C1CONbits.RCEN = 1;                        // Start Receive Byte
    while(I2C1CONbits.RCEN);                     // Wait for read to finish.
    I2C1STATbits.I2COV = 0;                      // Clear Receive overflow just in case.
    AckI2C1();                                   // Generate Ack.
    Pressure_Cal_MD = (I2C1RCV&0xFF);            // Grab Receive Data
    Pressure_Cal_MD = Pressure_Cal_MD<<8;
    IdleI2C1();                                  // Wait for last I2C command to complete
    I2C1CONbits.RCEN = 1;                        // Start Next Receive Byte
    while(I2C1CONbits.RCEN);                     // Wait for read to finish.
    I2C1STATbits.I2COV = 0;                      // Clear Receive overflow just in case.
    NotAckI2C1();                                // Generate Ack.
    Pressure_Cal_MD |= (I2C1RCV&0xFF);           // Grab Data
    IdleI2C1();                                  // Wait for last I2C command to complete
    StopI2C1();                                  // Send the Stop condition
    for (i=0; i < 550000; i++) Nop();            // Wait a bit 
 }

/***************************************************************************************/
/*        Compute Pressure and Altitude from Baro Data                                 */
/*                    19.8uS                                                           */
/***************************************************************************************/

void Process_Alt_Pressure(void)
 {
   //LATGbits.LATG14 = 0;

   float Temp_Alt_Float;
   Baro_B6 = Baro_B5 - 4000;
   Baro_X1 = Baro_B6 * Baro_B6;
   Baro_X1 = Baro_X1>>12; 
   Baro_X1 *= Pressure_Cal_B2;
   Baro_X1 = Baro_X1>>11;
   Baro_X2 = Pressure_Cal_AC2*Baro_B6;
   Baro_X2 = Baro_X2>>11;
   Baro_X3 = Baro_X1 + Baro_X2;
   Baro_B3 = Pressure_Cal_AC1*4;
   Baro_B3 += Baro_X3;
   Baro_B3 = Baro_B3<<2;
   Baro_B3 += 2;
   Baro_B3 = Baro_B3>>2;
   Baro_X1 = Pressure_Cal_AC3 * Baro_B6;
   Baro_X1 = Baro_X1>>13;
   Baro_X2 = (Baro_B6*Baro_B6)>>12;
   Baro_X2 = (Pressure_Cal_B1*Baro_X2)>>16;
   Baro_X3 = (Baro_X1 + Baro_X2 + 2)>>2;
   Baro_B4 = Pressure_Cal_AC4*(unsigned int)(Baro_X3+32768)>>15;
   Baro_B7 = ((unsigned int)Baro_Pressure_Raw - Baro_B3)*12500;
   if (Baro_B7<0x80000000) Baro_Pressure_Pa = (Baro_B7*2)/Baro_B4;
   else Baro_Pressure_Pa = (Baro_B7/Baro_B4)<<1;
   Baro_X1 = Baro_Pressure_Pa>>8;
   Baro_X2 = Baro_X1*Baro_X1;
   Baro_X1 = (Baro_X2*3038)>>16;
   Baro_X2 = (-7357*Baro_Pressure_Pa)>>16;
   Baro_Pressure_Pa += (Baro_X1 + Baro_X2 + 3791)>>4;

   /* We have Pressure in Pascals, now get altitude */
   Temp_Alt_Float = (float)(Baro_Pressure_Pa)*(1.0/101325.0);
   Temp_Alt_Float = powf(Temp_Alt_Float, 0.19029496);
   Temp_Alt_Float = (1-Temp_Alt_Float)*44330.8; 
   Baro_Altitude_M = (int)(Temp_Alt_Float);

   Baro_Altitude_M += Baro_Altitude_Correction;

   //LATGbits.LATG14 = 1;
 } 

/***************************************************************************************/
/*        Compute Temperature from Baro Data                                           */
/*                   1.5uS                                                             */
/***************************************************************************************/
void Process_Alt_Temp(void)
 {
   //LATGbits.LATG14 = 0;
   Baro_X1 = Baro_Temperature_Raw - Pressure_Cal_AC6;
   Baro_X1 *= Pressure_Cal_AC5;
   Baro_X1 = Baro_X1>>15;
   Baro_X2 = (int)(Pressure_Cal_MC);
   Baro_X2 = Baro_X2<<11;
   Baro_X2 = Baro_X2/(Baro_X1 + (int)(Pressure_Cal_MD));
   Baro_B5 = Baro_X1 + Baro_X2;
   Baro_Temperature_C = (Baro_B5 + 8);
   Baro_Temperature_C = Baro_Temperature_C >> 4;
   //LATGbits.LATG14 = 1;             
 } 

