#ifndef MISC_TEST_TERM_H_
#define MISC_TEST_TERM_H_

#include <stdbool.h>

bool misc_test_term(void);

#endif
