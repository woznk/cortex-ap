#ifndef MAIN_H_
#define MAIN_H_

void main_systick_action(void);

#endif /* MAIN_H_ */
