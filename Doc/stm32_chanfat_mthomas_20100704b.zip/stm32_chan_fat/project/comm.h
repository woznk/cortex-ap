#ifndef COMM_H_
#define COMM_H_

void comm_init(void);
int  comm_test(void);
void comm_put(char);
void comm_puts(const char*);
char comm_get(void);

#endif

